import{aZ as a,a as t,Y as n}from"./index-4faaad37.js";function r(){const{flags:e}=a(),{can:s}=t();return!!e.context_graph_enabled&&s(n.contextView)}export{r as u};
