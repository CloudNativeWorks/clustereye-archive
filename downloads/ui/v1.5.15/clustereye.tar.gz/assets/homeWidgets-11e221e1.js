let e=null;function n(t){e=t}function s(){return e}export{s as r,n as s};
