import{g as Z,am as $t,aB as Be}from"./index-0c6cb722.js";import{r as K,aI as M,ak as B,j as o,aJ as wt,bd as dt,B as le,bC as kt,bL as Qe,ae as At,bI as St,cx as zt,by as Ct,a_ as Je,as as Ke,I as Ge,S as ce,bW as Mt,b2 as Pe,b3 as ue,T as fe,m as Re,br as Xe,aC as Ze,bc as Oe,be as V,b as Ne,cy as jt,P as _t,bD as Pt,bG as Rt}from"./vendor-core-32e3221b.js";import{f as ee,d as F}from"./vendor-utils-25255252.js";import{d as Ue}from"./doctorService-a189f455.js";import et from"./jspdf.es.min-356536ba.js";import tt from"./html2canvas.esm-71958c39.js";const te=Z();class Nt{getAuthToken(){return localStorage.getItem("token")}getAuthHeaders(){return{CEFE:"Yes",Authorization:`Bearer ${this.getAuthToken()}`,"Content-Type":"application/json"}}async fetchAnomalies(e){const r=new URLSearchParams;e.agent_id&&r.append("agent_id",e.agent_id),e.database_type&&r.append("database_type",e.database_type),e.severity&&r.append("severity",e.severity),e.is_active!==void 0&&r.append("is_active",String(e.is_active)),e.limit&&r.append("limit",String(e.limit)),e.offset&&r.append("offset",String(e.offset));const c=await ee.get(`${te}/api/v1/anomalies?${r.toString()}`,{headers:this.getAuthHeaders()});return{anomalies:c.data.anomalies||[],total:c.data.total||0}}async fetchAnomalyStats(e){const r=new URLSearchParams;return e.agent_id&&r.append("agent_id",e.agent_id),e.database_type&&r.append("database_type",e.database_type),(await ee.get(`${te}/api/v1/anomalies/stats?${r.toString()}`,{headers:this.getAuthHeaders()})).data}async resolveAnomaly(e){await ee.post(`${te}/api/v1/anomalies/${e}/resolve`,{},{headers:this.getAuthHeaders()})}async fetchAlarmConfigs(e){const r=new URLSearchParams;return e!=null&&e.agent_id&&r.append("agent_id",e.agent_id),e!=null&&e.database_type&&r.append("database_type",e.database_type),(await ee.get(`${te}/api/v1/alarm-configs?${r.toString()}`,{headers:this.getAuthHeaders()})).data.configs||[]}async createAlarmConfig(e){return(await ee.post(`${te}/api/v1/alarm-configs`,e,{headers:this.getAuthHeaders()})).data}async updateAlarmConfig(e,r){await ee.put(`${te}/api/v1/alarm-configs/${e}`,r,{headers:this.getAuthHeaders()})}async deleteAlarmConfig(e){await ee.delete(`${te}/api/v1/alarm-configs/${e}`,{headers:this.getAuthHeaders()})}async fetchAlarmHistory(e){const r=new URLSearchParams;e!=null&&e.anomaly_id&&r.append("anomaly_id",String(e.anomaly_id)),e!=null&&e.status&&r.append("status",e.status),e!=null&&e.limit&&r.append("limit",String(e.limit)),e!=null&&e.offset&&r.append("offset",String(e.offset));const c=await ee.get(`${te}/api/v1/alarms-history?${r.toString()}`,{headers:this.getAuthHeaders()});return{alarms:c.data.alarms||[],total:c.data.total||0}}async comparePlans(e,r){return(await ee.get(`${te}/api/v1/plans/compare?from_plan_id=${e}&to_plan_id=${r}`,{headers:this.getAuthHeaders()})).data}}const it=new Nt,Te={availability:.4,infrastructure:.25,performance:.2,maintenance:.15},Ae={disk:{warning:80,critical:95},cpu:{warning:70,critical:90},memory:{warning:80,critical:95}};function Tt(t){const e=Math.round(t.availability*Te.availability+t.infrastructure*Te.infrastructure+t.performance*Te.performance+t.maintenance*Te.maintenance);return Math.max(0,Math.min(100,e))}function Lt(t){return t>=80?"healthy":t>=50?"warning":"critical"}function Dt(t,e,r=!0){if(e===0||t===0)return 0;const c=t/e;let b=t===e?100:Math.pow(c,1.5)*100;return r||(b=Math.min(b,20)*.5),b}function Ve(t,e,r){if(t>=r)return 20;if(t>=e){const b=(t-e)/(r-e);return Math.round(60-b*40)}const c=t/e;return Math.round(100-c*40)}function It(t,e,r){const c=Ve(t,Ae.disk.warning,Ae.disk.critical),b=Ve(e,Ae.cpu.warning,Ae.cpu.critical),h=Ve(r,Ae.memory.warning,Ae.memory.critical);return Math.round((c+b+h)/3)}function Et(t){let e=100;return t.query==="critical"?e-=40:t.query==="warning"&&(e-=15),t.cpu==="critical"?e-=20:t.cpu==="warning"&&(e-=10),t.memory==="critical"?e-=20:t.memory==="warning"&&(e-=10),t.hasCriticalQueries?e-=15:t.hasWarningQueries&&(e-=8),Math.max(20,e)}function Ft(t,e){let r=100;return t.vacuum==="critical"||t.oplog==="critical"?r-=35:(t.vacuum==="warning"||t.oplog==="warning")&&(r-=15),e>300?r-=35:e>30&&(r-=15),Math.max(20,r)}function Ht(t,e,r,c,b,h,w=0,l=!0){const k={availability:Dt(t,e,l),infrastructure:It(r,c,b),performance:Et(h),maintenance:Ft(h,w)};let A=Tt(k);l||(A=Math.min(A,30));const T=Lt(A);return{score:A,status:T,categories:k}}function qe(t){const r={critical:40,high:25,medium:15}[t.severity]??10,c=Math.min(20,t.occurrenceCount*2),b=Math.min(20,(t.deviationPct??0)/10),h=Math.min(10,t.affectedNodeCount*5),w=t.isRecurring?10:0;return Math.min(100,r+c+b+h+w)}function ot(t,e){return isNaN(t)||isNaN(e)?"unavailable":t===0&&e===0?"suspect":"valid"}function Yt(t){return t==="critical"?"critical":t==="high"?"high":"medium"}function lt(t){return typeof t=="number"?t>=80?"high":t>=50?"medium":"low":t==="high"?"high":t==="medium"?"medium":"low"}function Bt(t){return t==="minimal"||t==="low"?"5m":t==="medium"?"30m":t==="high"?"1h":"30m"}function ct(t,e){const r=(t+" "+(e||"")).toLowerCase();return r.includes("query")||r.includes("duration")||r.includes("slow")?"latency":r.includes("replication")||r.includes("lag")||r.includes("failover")?"availability":r.includes("cpu")||r.includes("memory")||r.includes("disk")?"resource":r.includes("alarm")||r.includes("alert")||r.includes("noise")?"operational_noise":"stability"}function Qt(t){return t.filter(e=>e.severity==="critical"||e.severity==="high"||e.severity==="medium").map(e=>{const r=Yt(e.severity),c=qe({severity:r,occurrenceCount:1,deviationPct:e.score_impact?Math.abs(e.score_impact)*10:0,affectedNodeCount:1,isRecurring:!1});return{title:e.title,severity:r,affectedNodes:e.object_name?[e.object_name]:[],cause:e.ai_explanation||e.description||"Detected by analysis rules",impactLevel:e.impact==="high"?"high":e.impact==="medium"?"medium":"low",impactType:ct(e.title,e.category),recommendedFix:e.recommendation||"Review finding details",confidenceLevel:lt(e.confidence),riskScore:c,source:"doctor"}}).sort((e,r)=>r.riskScore-e.riskScore).slice(0,5)}function Gt(t,e){const r=[],c=new Map;t.forEach(h=>{const w=`${h.metric_name}-${h.database_type}`;c.has(w)||c.set(w,[]),c.get(w).push(h)}),c.forEach((h,w)=>{var L;const l=h.sort((q,ie)=>Math.abs(ie.deviation_pct)-Math.abs(q.deviation_pct))[0],k=[...new Set(h.map(q=>q.agent_id))],A=l.severity==="critical"?"critical":h.length>2?"high":"medium",T=qe({severity:A,occurrenceCount:h.length,deviationPct:Math.abs(l.deviation_pct),affectedNodeCount:k.length,isRecurring:h.length>1});r.push({title:`${l.metric_name} anomaly on ${l.database_type}`,severity:A,affectedNodes:k,cause:l.primary_cause||`${l.metric_name} deviated ${Math.abs(l.deviation_pct).toFixed(0)}% from baseline`,impactLevel:Math.abs(l.deviation_pct)>100?"high":Math.abs(l.deviation_pct)>50?"medium":"low",impactType:ct(l.metric_name),recommendedFix:((L=l.suggested_actions)==null?void 0:L[0])||"Investigate metric deviation",confidenceLevel:lt(l.confidence),riskScore:T,source:"anomaly"})});const b=new Map;return(e||[]).forEach(h=>{const w=h.agent_id||"unknown";b.has(w)||b.set(w,[]),b.get(w).push(h)}),b.forEach((h,w)=>{h.length>=10&&r.push({title:`Alert storm from ${w.replace("agent_","")}`,severity:"medium",affectedNodes:[w],cause:`${h.length} alarms from a single node — possible noise`,impactLevel:"medium",impactType:"operational_noise",recommendedFix:"Review alert thresholds or enable deduplication",confidenceLevel:"medium",riskScore:qe({severity:"medium",occurrenceCount:h.length,affectedNodeCount:1,isRecurring:!0}),source:"alarm"})}),r.sort((h,w)=>w.riskScore-h.riskScore).slice(0,5)}function Ot(t){return t.filter(e=>e.is_quick_win).map(e=>({title:e.title,description:e.recommendation||e.description||"",effortLevel:Bt(e.effort),expectedImpact:e.impact==="high"?"high":e.impact==="medium"?"medium":"low",source:"doctor"})).slice(0,5)}function Ut(t){const e=[];return t.forEach(r=>{r.suggested_actions&&r.suggested_actions.length>0&&e.push({title:r.suggested_actions[0],description:`Address ${r.metric_name} anomaly on ${r.database_type}`,effortLevel:"30m",expectedImpact:Math.abs(r.deviation_pct)>50?"high":"medium",source:"anomaly"})}),e.slice(0,5)}function Vt(t){const e=t.filter(l=>l.severity==="critical").length,r=t.filter(l=>l.severity==="warning").length,c=new Map;t.forEach(l=>{const k=l.agent_id||"unknown";c.set(k,(c.get(k)||0)+1)});const b=[...c.entries()].filter(([,l])=>l>=10).sort((l,k)=>k[1]-l[1]).map(([l,k])=>({nodeId:l.replace("agent_",""),count:k,suggestion:k>30?"Enable alarm deduplication":"Review alert thresholds"})),h=new Map;t.forEach(l=>{h.set(l.metric_name,(h.get(l.metric_name)||0)+1)});const w=[...h.values()].filter(l=>l>1).reduce((l,k)=>l+k,0);return{totalAlarms:t.length,criticalCount:e,warningCount:r,noisyNodes:b,newVsRecurring:{newCount:t.length-w,recurringCount:w},alertFatigueRisk:t.length>50}}function qt(t){const e=new Map;t.forEach(b=>{e.has(b.database_type)||e.set(b.database_type,[]),e.get(b.database_type).push(b)});const r=[...e.entries()].map(([b,h])=>{var l;const w=h.sort((k,A)=>Math.abs(A.deviation_pct)-Math.abs(k.deviation_pct));return{dbType:b,count:h.length,topMetric:((l=w[0])==null?void 0:l.metric_name)||"—",changePercent:w[0]?Math.abs(w[0].deviation_pct):0}}),c=t.sort((b,h)=>Math.abs(h.deviation_pct)-Math.abs(b.deviation_pct)).slice(0,5).map(b=>{var h;return{metric:b.metric_name,dbType:b.database_type,deviationPct:b.deviation_pct,severity:b.severity,suggestedAction:(h=b.suggested_actions)==null?void 0:h[0]}});return{totalAnomalies:t.length,byDatabase:r,topAnomalies:c}}function Wt(t,e,r,c,b){const h=e>0?(t-e)/e*100:0,w=c>0?(r-c)/c*100:0,l=[],k=[];h>10?l.push({description:"Alarm count increased",changePct:h}):h<-10&&k.push({description:"Alarm count decreased",changePct:h}),w>10?l.push({description:"Anomaly count increased",changePct:w}):w<-10&&k.push({description:"Anomaly count decreased",changePct:w});const A=b.filter(L=>Math.abs(L.deviation_pct)>20).sort((L,q)=>Math.abs(q.deviation_pct)-Math.abs(L.deviation_pct)).slice(0,3).map(L=>({metric:`${L.metric_name} (${L.database_type})`,changePct:L.deviation_pct,direction:L.deviation_pct>0?"up":"down"})),T=[];return l.length>0&&T.push(`Regressions: ${l.map(L=>`${L.description} (${L.changePct>0?"+":""}${L.changePct.toFixed(0)}%)`).join(", ")}.`),k.length>0&&T.push(`Improvements: ${k.map(L=>`${L.description} (${L.changePct.toFixed(0)}%)`).join(", ")}.`),T.length===0&&T.push("No significant changes compared to the previous period."),{topRegressions:l,topImprovements:k,mostChangedMetrics:A,narrative:T.join(" ")}}function Jt(t,e,r,c,b){const h=t.status==="healthy"?"healthy":t.status==="warning"?"degraded":"critical",w=[];if(w.push(`System health is ${h} (score: ${t.overall}/100).`),b.topRegressions.length>0&&w.push(b.topRegressions.map(l=>`${l.description} by ${Math.abs(l.changePct).toFixed(0)}%`).join(". ")+"."),c.totalAnomalies>0&&c.byDatabase.length>0){const l=c.byDatabase.sort((k,A)=>A.count-k.count)[0];w.push(`${c.totalAnomalies} anomalies detected, primarily affecting ${l.dbType} (${l.topMetric} +${l.changePercent.toFixed(0)}%).`)}if(e.length>0){const l=e.filter(k=>k.severity==="critical").length;l>0&&w.push(`${l} critical risk${l>1?"s":""} identified, including ${e[0].title}.`)}return r.alertFatigueRisk&&w.push(`Alert fatigue risk detected with ${r.totalAlarms} alarms in this period.`),w.join(" ")}function Kt(t){const e=(t==null?void 0:t.cpuTrends)||[],r=(t==null?void 0:t.memoryTrends)||[],c=e.map(A=>parseFloat(A._value)).filter(A=>!isNaN(A)),b=r.map(A=>parseFloat(A._value)).filter(A=>!isNaN(A)),h=c.length>0?c.reduce((A,T)=>A+T,0)/c.length:0,w=c.length>0?Math.max(...c):0,l=b.length>0?b.reduce((A,T)=>A+T,0)/b.length:0,k=b.length>0?Math.max(...b):0;return{cpu:{avg:h,max:w,dataQuality:ot(h,w)},memory:{avg:l,max:k,dataQuality:ot(l,k)}}}async function Xt(t,e,r){var Me,je;const c=F().format("YYYY-MM-DD HH:mm:ss"),b=t.clusters.map(Q=>Q.replace("agent_","")),h=t.timeRange.type==="absolute"?((Me=t.timeRange.absolute)==null?void 0:Me.startDate)||c:F().subtract(parseInt(t.timeRange.relative||"24",10),"hour").format("YYYY-MM-DD HH:mm"),w=t.timeRange.type==="absolute"&&((je=t.timeRange.absolute)==null?void 0:je.endDate)||c,l=(e==null?void 0:e.recentAlarms)||[],k=l.filter(Q=>Q.severity==="critical").length,A=Ht(b.length,b.length,50,40,60,{query:k>0?"warning":"ok",hasCriticalQueries:k>0},0);let T=[],L=null;try{T=(await it.fetchAnomalies({is_active:!0,limit:100})).anomalies||[],L=await it.fetchAnomalyStats({})}catch{}let q=[],ie=null;try{const Q=await Ue.getLatestRun({});Q&&Q.status==="completed"&&(q=await Ue.getFindings(Q.id)||[],r&&Q.ai_status==="completed"&&(ie=await Ue.getAISummary(Q.id)))}catch{}const pe=q.length>0?Qt(q):Gt(T,l),Le=q.length>0?Ot(q):Ut(T),ze=Vt(l),Ce=qt(T),ye=Math.max(0,l.length-Math.floor(l.length*.1)),ge=(L==null?void 0:L.resolved_count)||0,oe=Wt(l.length,ye,T.length,ge,T);let Se,me;r&&ie&&ie.executive_summary?(me=ie.executive_summary,Se="doctor_ai"):(me=Jt({overall:A.score,status:A.status},pe,ze,Ce,oe),Se=r?"ai_service":"deterministic");const De=pe.slice(0,3).map(Q=>({text:Q.recommendedFix,source:Q.source})),he=Kt(e==null?void 0:e.capacityPlanning),Ie={totalQueries:0,avgDurationMs:0,p95DurationMs:0,topQueries:[]},Ee=A.status==="healthy"?"HEALTHY":A.status==="warning"?"DEGRADED":"CRITICAL",Fe=ye>0?(l.length-ye)/ye*100:0,He=ge>0?(T.length-ge)/ge*100:0,Ye=pe.filter(Q=>Q.severity==="critical").length>0?"degraded":oe.topImprovements.length>oe.topRegressions.length?"improved":"stable";return{summarySource:Se,aiEnabled:r,clusterNames:b,timeRange:{label:t.timeRangeLabel,start:h,end:w},generatedAt:c,healthScore:{overall:A.score,status:A.status,categories:A.categories},executiveSummary:{statusLabel:Ee,summaryText:me,topRisks:pe.slice(0,3),recommendedActions:De,vsLastPeriod:{alarmCountChange:Fe,anomalyCountChange:He,performanceTrend:Ye}},risks:pe,alarmIntelligence:ze,anomalyAnalysis:Ce,queryPerformance:Ie,resources:he,quickWins:Le,whatChanged:oe,recentAlarms:l,capacityPlanning:e==null?void 0:e.capacityPlanning}}const s={headerGradientFrom:"#1e293b",headerGradientTo:"#334155",healthy:"#22c55e",warning:"#f59e0b",critical:"#ef4444",accent:"#6366f1",text:"#374151",textSecondary:"#6b7280",textMuted:"#9ca3af",bg:"#ffffff",bgCard:"#f8fafc",border:"#e2e8f0",severityCritical:"#ef4444",severityHigh:"#f97316",severityMedium:"#f59e0b",confHigh:"#22c55e",confMedium:"#f59e0b",confLow:"#9ca3af"};function Zt(t){return t==="healthy"||t==="HEALTHY"?s.healthy:t==="warning"||t==="DEGRADED"?s.warning:s.critical}function pt(t){return t==="critical"?s.severityCritical:t==="high"?s.severityHigh:s.severityMedium}function st(t){return t==="high"?s.confHigh:t==="medium"?s.confMedium:s.confLow}function ei(t){return t==="HEALTHY"?"✅":t==="DEGRADED"?"⚠️":"🔥"}function nt(t){return t>5?`↑ +${t.toFixed(0)}%`:t<-5?`↓ ${t.toFixed(0)}%`:`→ ${t.toFixed(0)}%`}function ti(t){const e=t.healthScore.overall>=90?s.healthy:t.healthScore.overall>=70?s.warning:s.critical;return`
    <div style="text-align:center; padding:40px 30px; background:linear-gradient(135deg,${s.headerGradientFrom},${s.headerGradientTo}); border-radius:12px; color:white; margin-bottom:30px;">
      <div style="background:white; display:inline-block; padding:10px 24px; border-radius:40px; margin-bottom:20px;">
        <span style="font-size:28px; font-weight:700; color:${s.accent};">ClusterEye</span>
      </div>
      <h1 style="font-size:24px; font-weight:600; margin:0 0 8px;">Automated Performance Report</h1>
      <p style="font-size:14px; margin:4px 0; opacity:0.85;">${t.clusterNames.join(", ")}</p>
      <p style="font-size:13px; margin:4px 0; opacity:0.7;">${t.timeRange.label} &nbsp;|&nbsp; ${t.generatedAt}</p>
      <div style="margin-top:24px;">
        <div style="display:inline-block; width:90px; height:90px; border-radius:50%; border:4px solid ${e}; line-height:82px; font-size:32px; font-weight:700; color:white; text-align:center;">
          ${t.healthScore.overall}
        </div>
        <div style="margin-top:8px;">
          <span style="background:${e}; color:white; padding:4px 14px; border-radius:20px; font-size:12px; font-weight:600;">
            ${t.executiveSummary.statusLabel}
          </span>
        </div>
      </div>
    </div>`}function ii(t){const e=t.executiveSummary,r=Zt(e.statusLabel);return`
    <div style="margin-bottom:30px;">
      <h2 style="font-size:18px; color:${s.headerGradientFrom}; border-bottom:2px solid ${s.accent}; padding-bottom:8px; margin-bottom:16px;">
        🧠 Executive Summary
      </h2>
      <div style="display:flex; align-items:center; gap:8px; margin-bottom:12px;">
        <span style="font-size:20px;">${ei(e.statusLabel)}</span>
        <span style="font-size:16px; font-weight:700; color:${r};">System Status: ${e.statusLabel}</span>
      </div>
      <p style="font-size:13px; color:${s.text}; line-height:1.7; margin-bottom:16px;">
        ${e.summaryText}
      </p>
      <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px; margin-bottom:16px;">
        <div style="background:${s.bgCard}; border:1px solid ${s.border}; border-radius:8px; padding:14px;">
          <div style="font-size:11px; font-weight:600; color:${s.textSecondary}; text-transform:uppercase; margin-bottom:8px;">Top Risks</div>
          ${e.topRisks.map(c=>`
            <div style="display:flex; align-items:center; gap:6px; margin-bottom:6px; font-size:12px; color:${s.text};">
              <span style="background:${pt(c.severity)}; color:white; padding:1px 6px; border-radius:3px; font-size:10px; font-weight:600;">${c.severity.toUpperCase()}</span>
              ${c.title}
            </div>
          `).join("")}
        </div>
        <div style="background:${s.bgCard}; border:1px solid ${s.border}; border-radius:8px; padding:14px;">
          <div style="font-size:11px; font-weight:600; color:${s.textSecondary}; text-transform:uppercase; margin-bottom:8px;">Recommended Actions</div>
          ${e.recommendedActions.map(c=>`
            <div style="font-size:12px; color:${s.text}; margin-bottom:6px;">• ${c.text}</div>
          `).join("")}
        </div>
      </div>
      <div style="display:flex; gap:12px;">
        <span style="background:${s.bgCard}; border:1px solid ${s.border}; border-radius:6px; padding:6px 12px; font-size:11px; color:${s.text};">
          Alarms: ${nt(e.vsLastPeriod.alarmCountChange)}
        </span>
        <span style="background:${s.bgCard}; border:1px solid ${s.border}; border-radius:6px; padding:6px 12px; font-size:11px; color:${s.text};">
          Anomalies: ${nt(e.vsLastPeriod.anomalyCountChange)}
        </span>
        <span style="background:${s.bgCard}; border:1px solid ${s.border}; border-radius:6px; padding:6px 12px; font-size:11px; color:${s.text};">
          Performance: ${e.vsLastPeriod.performanceTrend==="improved"?"↑ Improved":e.vsLastPeriod.performanceTrend==="degraded"?"↓ Degraded":"→ Stable"}
        </span>
      </div>
    </div>`}function oi(t){const e=[{name:"Availability",weight:"40%",score:t.healthScore.categories.availability},{name:"Infrastructure",weight:"25%",score:t.healthScore.categories.infrastructure},{name:"Performance",weight:"20%",score:t.healthScore.categories.performance},{name:"Maintenance",weight:"15%",score:t.healthScore.categories.maintenance}];return`
    <div style="margin-bottom:30px;">
      <h2 style="font-size:18px; color:${s.headerGradientFrom}; border-bottom:2px solid ${s.accent}; padding-bottom:8px; margin-bottom:16px;">
        📊 Health Score Breakdown
      </h2>
      <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
        ${e.map(r=>{const c=r.score>=80?s.healthy:r.score>=50?s.warning:s.critical;return`
          <div style="background:${s.bgCard}; border:1px solid ${s.border}; border-radius:8px; padding:14px;">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
              <span style="font-size:13px; font-weight:600; color:${s.text};">${r.name}</span>
              <span style="font-size:11px; color:${s.textMuted};">${r.weight}</span>
            </div>
            <div style="font-size:24px; font-weight:700; color:${c}; margin-bottom:6px;">${Math.round(r.score)}%</div>
            <div style="background:${s.border}; height:6px; border-radius:3px; overflow:hidden;">
              <div style="background:${c}; height:100%; width:${Math.round(r.score)}%; border-radius:3px;"></div>
            </div>
          </div>`}).join("")}
      </div>
    </div>`}function si(t){return t.length===0?`<div style="margin-bottom:30px;"><h2 style="font-size:18px; color:${s.headerGradientFrom}; border-bottom:2px solid ${s.accent}; padding-bottom:8px;">🚨 Top Risks</h2><p style="color:${s.textSecondary}; font-size:13px;">No significant risks detected in this period.</p></div>`:`
    <div style="margin-bottom:30px;">
      <h2 style="font-size:18px; color:${s.headerGradientFrom}; border-bottom:2px solid ${s.accent}; padding-bottom:8px; margin-bottom:16px;">
        🚨 Top Risks
      </h2>
      ${t.map(e=>`
        <div style="background:${s.bgCard}; border:1px solid ${s.border}; border-radius:8px; padding:14px; margin-bottom:10px;">
          <div style="display:flex; align-items:center; gap:8px; margin-bottom:8px;">
            <span style="background:${pt(e.severity)}; color:white; padding:2px 8px; border-radius:4px; font-size:10px; font-weight:600;">${e.severity.toUpperCase()}</span>
            <span style="font-size:14px; font-weight:600; color:${s.text};">${e.title}</span>
            <span style="margin-left:auto; font-size:10px; padding:2px 6px; border-radius:3px; background:${st(e.confidenceLevel)}22; color:${st(e.confidenceLevel)}; font-weight:500;">
              ${e.confidenceLevel} confidence
            </span>
          </div>
          <div style="font-size:12px; color:${s.textSecondary}; margin-bottom:4px;">
            <strong>Affected:</strong> ${e.affectedNodes.length>0?e.affectedNodes.join(", "):"Cluster-wide"} &nbsp;|&nbsp;
            <strong>Impact:</strong> ${e.impactLevel.toUpperCase()} ${e.impactType}
          </div>
          <div style="font-size:12px; color:${s.text}; margin-bottom:4px;"><strong>Cause:</strong> ${e.cause}</div>
          <div style="font-size:12px; color:${s.accent}; font-weight:500;">💡 ${e.recommendedFix}</div>
        </div>
      `).join("")}
    </div>`}function ni(t){return`
    <div style="margin-bottom:30px;">
      <h2 style="font-size:18px; color:${s.headerGradientFrom}; border-bottom:2px solid ${s.accent}; padding-bottom:8px; margin-bottom:16px;">
        📈 What Changed
      </h2>
      <p style="font-size:13px; color:${s.text}; line-height:1.6; margin-bottom:14px;">${t.narrative}</p>
      ${t.mostChangedMetrics.length>0?`
        <div style="display:flex; flex-wrap:wrap; gap:8px;">
          ${t.mostChangedMetrics.map(e=>`
            <span style="background:${e.direction==="up"?"#fef2f2":"#f0fdf4"}; border:1px solid ${e.direction==="up"?"#fecaca":"#bbf7d0"}; border-radius:6px; padding:4px 10px; font-size:11px; color:${e.direction==="up"?s.critical:s.healthy}; font-weight:500;">
              ${e.metric}: ${e.direction==="up"?"+":""}${e.changePct.toFixed(0)}%
            </span>
          `).join("")}
        </div>
      `:""}
    </div>`}function ri(t){return`
    <div style="margin-bottom:30px;">
      <h2 style="font-size:18px; color:${s.headerGradientFrom}; border-bottom:2px solid ${s.accent}; padding-bottom:8px; margin-bottom:16px;">
        🚨 Alarm Intelligence
      </h2>
      <div style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:10px; margin-bottom:14px;">
        <div style="text-align:center; background:${s.bgCard}; border:1px solid ${s.border}; border-radius:8px; padding:12px;">
          <div style="font-size:22px; font-weight:700; color:${s.text};">${t.totalAlarms}</div>
          <div style="font-size:11px; color:${s.textSecondary};">Total Alarms</div>
        </div>
        <div style="text-align:center; background:${s.bgCard}; border:1px solid ${s.border}; border-radius:8px; padding:12px;">
          <div style="font-size:22px; font-weight:700; color:${s.critical};">${t.criticalCount}</div>
          <div style="font-size:11px; color:${s.textSecondary};">Critical</div>
        </div>
        <div style="text-align:center; background:${s.bgCard}; border:1px solid ${s.border}; border-radius:8px; padding:12px;">
          <div style="font-size:22px; font-weight:700; color:${s.warning};">${t.warningCount}</div>
          <div style="font-size:11px; color:${s.textSecondary};">Warning</div>
        </div>
      </div>
      ${t.noisyNodes.length>0?`
        <div style="background:#fffbeb; border:1px solid #fde68a; border-radius:8px; padding:12px; margin-bottom:10px;">
          <div style="font-size:12px; font-weight:600; color:#92400e; margin-bottom:6px;">⚠️ Noisy Nodes Detected</div>
          ${t.noisyNodes.map(e=>`
            <div style="font-size:12px; color:${s.text}; margin-bottom:4px;">
              <strong>${e.nodeId}</strong> — ${e.count} alarms → ${e.suggestion}
            </div>
          `).join("")}
        </div>
      `:""}
      ${t.alertFatigueRisk?`
        <div style="background:#fef2f2; border:1px solid #fecaca; border-radius:8px; padding:10px; font-size:12px; color:#991b1b;">
          🔥 Alert fatigue risk: ${t.totalAlarms} alarms may overwhelm the team. Consider consolidation.
        </div>
      `:""}
    </div>`}function ai(t){return t.totalAnomalies===0?`<div style="margin-bottom:30px;"><h2 style="font-size:18px; color:${s.headerGradientFrom}; border-bottom:2px solid ${s.accent}; padding-bottom:8px;">🤖 Anomaly Analysis</h2><p style="color:${s.textSecondary}; font-size:13px;">No anomalies detected in this period.</p></div>`:`
    <div style="margin-bottom:30px;">
      <h2 style="font-size:18px; color:${s.headerGradientFrom}; border-bottom:2px solid ${s.accent}; padding-bottom:8px; margin-bottom:16px;">
        🤖 Anomaly Analysis
      </h2>
      <div style="font-size:13px; color:${s.text}; margin-bottom:12px;">${t.totalAnomalies} anomalies detected.</div>
      ${t.byDatabase.map(e=>`
        <div style="background:${s.bgCard}; border:1px solid ${s.border}; border-radius:8px; padding:12px; margin-bottom:8px;">
          <div style="font-size:13px; font-weight:600; color:${s.text}; margin-bottom:4px;">${e.dbType} — ${e.count} anomalies</div>
          <div style="font-size:12px; color:${s.textSecondary};">Top metric: <strong>${e.topMetric}</strong> (${e.changePercent>0?"+":""}${e.changePercent.toFixed(0)}%)</div>
        </div>
      `).join("")}
    </div>`}function di(t){return`
    <div style="margin-bottom:30px;">
      <h2 style="font-size:18px; color:${s.headerGradientFrom}; border-bottom:2px solid ${s.accent}; padding-bottom:8px; margin-bottom:16px;">
        🐢 Query Performance
      </h2>
      <div style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:10px; margin-bottom:14px;">
        <div style="text-align:center; background:${s.bgCard}; border:1px solid ${s.border}; border-radius:8px; padding:12px;">
          <div style="font-size:20px; font-weight:700; color:${s.text};">${t.totalQueries.toLocaleString()}</div>
          <div style="font-size:11px; color:${s.textSecondary};">Total Queries</div>
        </div>
        <div style="text-align:center; background:${s.bgCard}; border:1px solid ${s.border}; border-radius:8px; padding:12px;">
          <div style="font-size:20px; font-weight:700; color:${s.text};">${t.avgDurationMs.toFixed(1)}ms</div>
          <div style="font-size:11px; color:${s.textSecondary};">Avg Duration</div>
        </div>
        <div style="text-align:center; background:${s.bgCard}; border:1px solid ${s.border}; border-radius:8px; padding:12px;">
          <div style="font-size:20px; font-weight:700; color:${s.text};">${t.p95DurationMs.toFixed(1)}ms</div>
          <div style="font-size:11px; color:${s.textSecondary};">P95 Duration</div>
        </div>
      </div>
      ${t.topQueries.length>0?`
        <table style="width:100%; border-collapse:collapse; font-size:12px;">
          <thead>
            <tr style="background:${s.bgCard};">
              <th style="padding:8px; border:1px solid ${s.border}; text-align:left; font-weight:600; color:${s.text};">Query</th>
              <th style="padding:8px; border:1px solid ${s.border}; text-align:right;">Avg (ms)</th>
              <th style="padding:8px; border:1px solid ${s.border}; text-align:right;">Count</th>
              <th style="padding:8px; border:1px solid ${s.border}; text-align:center;">Impact</th>
              <th style="padding:8px; border:1px solid ${s.border}; text-align:left;">Recommendation</th>
            </tr>
          </thead>
          <tbody>
            ${t.topQueries.map(e=>`
              <tr>
                <td style="padding:8px; border:1px solid ${s.border}; font-family:monospace; font-size:11px; max-width:200px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">${e.fingerprint}</td>
                <td style="padding:8px; border:1px solid ${s.border}; text-align:right;">${e.avgDurationMs.toFixed(1)}</td>
                <td style="padding:8px; border:1px solid ${s.border}; text-align:right;">${e.executionCount.toLocaleString()}</td>
                <td style="padding:8px; border:1px solid ${s.border}; text-align:center;">
                  <span style="padding:2px 6px; border-radius:3px; font-size:10px; font-weight:600; background:${e.impactLevel==="high"?"#fef2f2":e.impactLevel==="medium"?"#fffbeb":"#f0fdf4"}; color:${e.impactLevel==="high"?s.critical:e.impactLevel==="medium"?s.warning:s.healthy};">${e.impactLevel.toUpperCase()}</span>
                </td>
                <td style="padding:8px; border:1px solid ${s.border}; font-size:11px;">${e.recommendation}</td>
              </tr>
            `).join("")}
          </tbody>
        </table>
      `:'<p style="font-size:12px; color:'+s.textSecondary+';">No query data available for this period.</p>'}
    </div>`}function rt(t,e){if(e.dataQuality==="unavailable")return`<div style="background:${s.bgCard}; border:1px solid ${s.border}; border-radius:8px; padding:14px;"><div style="font-size:13px; font-weight:600; color:${s.text}; margin-bottom:6px;">${t}</div><div style="font-size:12px; color:${s.textMuted};">Data unavailable for this period.</div></div>`;if(e.dataQuality==="suspect")return`<div style="background:#fffbeb; border:1px solid #fde68a; border-radius:8px; padding:14px;"><div style="font-size:13px; font-weight:600; color:${s.text}; margin-bottom:6px;">${t}</div><div style="font-size:12px; color:#92400e;">⚠️ Metric collection issue detected — data may be incomplete.</div></div>`;const r=e.max>90?s.critical:e.max>70?s.warning:s.healthy;return`
    <div style="background:${s.bgCard}; border:1px solid ${s.border}; border-radius:8px; padding:14px;">
      <div style="font-size:13px; font-weight:600; color:${s.text}; margin-bottom:8px;">${t}</div>
      <div style="display:flex; justify-content:space-between; font-size:12px; color:${s.textSecondary}; margin-bottom:6px;">
        <span>Avg: <strong style="color:${s.text};">${e.avg.toFixed(1)}%</strong></span>
        <span>Max: <strong style="color:${r};">${e.max.toFixed(1)}%</strong></span>
      </div>
      <div style="background:${s.border}; height:8px; border-radius:4px; overflow:hidden;">
        <div style="background:${r}; height:100%; width:${Math.min(100,e.max).toFixed(0)}%; border-radius:4px;"></div>
      </div>
    </div>`}function li(t){return`
    <div style="margin-bottom:30px;">
      <h2 style="font-size:18px; color:${s.headerGradientFrom}; border-bottom:2px solid ${s.accent}; padding-bottom:8px; margin-bottom:16px;">
        ⚙️ Resource Utilization
      </h2>
      <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
        ${rt("CPU",t.resources.cpu)}
        ${rt("Memory",t.resources.memory)}
      </div>
    </div>`}function ci(t){return t.length===0?`<div style="margin-bottom:30px;"><h2 style="font-size:18px; color:${s.headerGradientFrom}; border-bottom:2px solid ${s.accent}; padding-bottom:8px;">⚡ Quick Wins</h2><p style="color:${s.textSecondary}; font-size:13px;">No quick wins identified in this period.</p></div>`:`
    <div style="margin-bottom:30px;">
      <h2 style="font-size:18px; color:${s.headerGradientFrom}; border-bottom:2px solid ${s.accent}; padding-bottom:8px; margin-bottom:16px;">
        ⚡ Quick Wins
      </h2>
      ${t.map(e=>`
        <div style="background:${s.bgCard}; border:1px solid ${s.border}; border-radius:8px; padding:12px; margin-bottom:8px; display:flex; justify-content:space-between; align-items:center;">
          <div>
            <div style="font-size:13px; font-weight:600; color:${s.text};">${e.title}</div>
            <div style="font-size:12px; color:${s.textSecondary}; margin-top:2px;">${e.description}</div>
          </div>
          <div style="display:flex; gap:6px; flex-shrink:0;">
            <span style="background:#f0fdf4; border:1px solid #bbf7d0; border-radius:4px; padding:2px 8px; font-size:10px; font-weight:500; color:#166534;">~${e.effortLevel}</span>
            <span style="background:${e.expectedImpact==="high"?"#fef2f2":e.expectedImpact==="medium"?"#fffbeb":"#f0fdf4"}; border:1px solid ${e.expectedImpact==="high"?"#fecaca":e.expectedImpact==="medium"?"#fde68a":"#bbf7d0"}; border-radius:4px; padding:2px 8px; font-size:10px; font-weight:500; color:${e.expectedImpact==="high"?"#991b1b":e.expectedImpact==="medium"?"#92400e":"#166534"};">
              ${e.expectedImpact.toUpperCase()} impact
            </span>
          </div>
        </div>
      `).join("")}
    </div>`}function pi(t){const e=`RPT-${t.generatedAt.replace(/[\s:-]/g,"").substring(0,14)}`;return`
    <div style="margin-top:40px; padding:16px; border-top:2px solid ${s.border}; text-align:center;">
      <div style="font-size:11px; color:${s.textMuted};">
        Report ID: ${e} &nbsp;|&nbsp; Period: ${t.timeRange.label} &nbsp;|&nbsp; Generated: ${t.generatedAt}
      </div>
      <div style="font-size:12px; color:${s.textSecondary}; margin-top:4px; font-weight:500;">
        Generated by ClusterEye — Automated Performance Report
      </div>
    </div>`}function gi(t){return`
    <div style="max-width:800px; margin:0 auto; font-family:'Segoe UI',system-ui,-apple-system,sans-serif; line-height:1.6; color:${s.text};">
      ${ti(t)}
      ${ii(t)}
      ${oi(t)}
      ${si(t.risks)}
      ${ni(t.whatChanged)}
      ${ri(t.alarmIntelligence)}
      ${ai(t.anomalyAnalysis)}
      ${di(t.queryPerformance)}
      ${li(t)}
      ${ci(t.quickWins)}
      ${pi(t)}
    </div>`}const{TabPane:at}=dt,{Option:W}=ce,bi=()=>{const[t,e]=K.useState([]),[r,c]=K.useState([]),[b,h]=K.useState(!1),[w,l]=K.useState(!1),[k]=M.useForm(),[A]=M.useForm(),[T,L]=K.useState(null),[q,ie]=K.useState([]),[pe,Le]=K.useState([]),[ze,Ce]=K.useState([]),[ye,ge]=K.useState(!1),[oe,Se]=K.useState(null),[me,De]=K.useState(null);K.useEffect(()=>{he(),Ie(),Ee()},[]);const he=async()=>{try{const i=localStorage.getItem("token"),a=await(await fetch(`${Z()}/api/v1/reports`,{headers:{"Content-Type":"application/json",CEFE:"Yes",...i?{Authorization:`Bearer ${i}`}:{}}})).json();e(a.reports)}catch{B.error("Failed to fetch reports")}},Ie=async()=>{try{const i=localStorage.getItem("token"),a=await(await fetch(`${Z()}/api/v1/reports/history`,{headers:{"Content-Type":"application/json",CEFE:"Yes",...i?{Authorization:`Bearer ${i}`}:{}}})).json();c(a.history)}catch{B.error("Failed to fetch report history")}},Ee=async()=>{try{const i=localStorage.getItem("token"),a=await(await fetch(`${Z()}/api/v1/status/nodeshealth`,{headers:{"Content-Type":"application/json",CEFE:"Yes",...i?{Authorization:`Bearer ${i}`}:{}}})).json(),y=[];a.mongodb&&a.mongodb.forEach(m=>{const S=Object.keys(m)[0],Y=m[S];y.push({id:S,name:S,type:"MongoDB",nodes:Y.length,nodeList:Y.map(P=>({hostname:P.Hostname,agentID:P.AgentID||`agent_${P.Hostname}`,isPrimary:P.IsPrimary,status:P.MongoStatus||"Unknown"}))})}),a.postgresql&&a.postgresql.forEach(m=>{const S=Object.keys(m)[0],Y=m[S];y.push({id:S,name:S,type:"PostgreSQL",nodes:Y.length,nodeList:Y.map(P=>({hostname:P.Hostname,agentID:P.AgentID||`agent_${P.Hostname}`,role:P.Role||"Unknown",status:P.Status||"Unknown"}))})}),a.mssql&&a.mssql.forEach(m=>{const S=Object.keys(m)[0],Y=m[S];y.push({id:S,name:S,type:"MSSQL",nodes:Y.length,nodeList:Y.map(P=>({hostname:P.Hostname,agentID:P.AgentID||`agent_${P.Hostname}`,status:P.Status||"Unknown"}))})}),ie(y)}catch{B.error("Failed to fetch available clusters")}},Fe=()=>{L(null),k.resetFields(),h(!0)},He=i=>{L(i),k.setFieldsValue({...i,time:F(i.schedule.time,"HH:mm")}),h(!0)},Ye=async()=>{try{const i=await k.validateFields(),n={...i,schedule:{...i.schedule,time:i.time.format("HH:mm")}},a=T?`${Z()}/api/v1/reports/${T.id}`:`${Z()}/api/v1/reports`,y=T?"PUT":"POST",m=localStorage.getItem("token");if(!(await fetch(a,{method:y,headers:{"Content-Type":"application/json",CEFE:"Yes",...m?{Authorization:`Bearer ${m}`}:{}},body:JSON.stringify(n)})).ok)throw new Error("Failed to save report");B.success(`Report ${T?"updated":"created"} successfully`),h(!1),he()}catch{B.error("Failed to save report")}},Me=async i=>{try{const a=await(await fetch(i)).blob(),y=window.URL.createObjectURL(a),m=document.createElement("a");m.href=y,m.download="report.pdf",document.body.appendChild(m),m.click(),window.URL.revokeObjectURL(y),document.body.removeChild(m)}catch{B.error("Failed to download PDF")}},je=async i=>{try{const n=i.status==="active"?"paused":"active",a=localStorage.getItem("token");await fetch(`${Z()}/api/v1/reports/${i.id}/status`,{method:"PUT",headers:{"Content-Type":"application/json",CEFE:"Yes",...a?{Authorization:`Bearer ${a}`}:{}},body:JSON.stringify({status:n})}),B.success(`Report ${n}`),he()}catch{B.error("Failed to update report status")}},Q=async i=>{try{const n=localStorage.getItem("token");await fetch(`${Z()}/api/v1/reports/${i}`,{method:"DELETE",headers:{"Content-Type":"application/json",CEFE:"Yes",...n?{Authorization:`Bearer ${n}`}:{}}}),B.success("Report deleted"),he()}catch{B.error("Failed to delete report")}},We=async()=>{var i;try{B.loading({content:"Generating report...",key:"report"});const n=F().format("YYYY-MM-DDTHH:mm:ssZ"),a=F().subtract(24,"hours").format("YYYY-MM-DDTHH:mm:ssZ"),y=localStorage.getItem("token"),S=await(await fetch(`${Z()}/api/v1/status/nodeshealth`,{headers:{"Content-Type":"application/json",CEFE:"Yes",...y?{Authorization:`Bearer ${y}`}:{}}})).json(),Y=S.mongodb||[],_=(((i=(await(await fetch(`${Z()}/api/v1/status/alarms?start_time=${a}&end_time=${n}`,{headers:{"Content-Type":"application/json",CEFE:"Yes",...y?{Authorization:`Bearer ${y}`}:{}}})).json()).data)==null?void 0:i.alarms)||[]).sort((d,u)=>new Date(u.created_at).getTime()-new Date(d.created_at).getTime()).slice(0,5),z=document.createElement("div");z.style.padding="20px",z.style.backgroundColor="white",z.style.width="800px",z.style.position="absolute",z.style.left="-9999px",z.style.top="0",z.style.fontFamily="Arial, sans-serif";const N=d=>{const u=["B","KB","MB","GB","TB"];if(d===0)return"0 B";const j=Math.floor(Math.log(d)/Math.log(1024));return`${(d/Math.pow(1024,j)).toFixed(2)} ${u[j]}`},be=d=>d.map(u=>{var x,D;const j=Object.keys(u)[0],f=u[j];return{name:j,type:"MongoDB",totalNodes:f.length,running:f.filter(g=>g.MongoStatus==="RUNNING").length,version:((x=f[0])==null?void 0:x.MongoVersion)||"N/A",locations:[...new Set(f.map(g=>g.Location))].join(", "),avgDiskFree:(f.reduce((g,E)=>{const U=parseFloat(E.FreeDisk);return g+(isNaN(U)?0:U)},0)/f.length).toFixed(1)+"G",avgMemory:N(f.reduce((g,E)=>g+(E.TotalMemory||0),0)/f.length),primary:((D=f.find(g=>g.NodeStatus==="PRIMARY"))==null?void 0:D.Hostname)||"N/A",secondaries:f.filter(g=>g.NodeStatus==="SECONDARY").length}}),O=d=>d.map(u=>{var x,D;const j=Object.keys(u)[0],f=u[j];return{name:j,type:"PostgreSQL",totalNodes:f.length,running:f.filter(g=>g.PGServiceStatus==="RUNNING").length,version:((x=f[0])==null?void 0:x.PGVersion)||"N/A",locations:[...new Set(f.map(g=>g.Location))].join(", "),avgDiskFree:(f.reduce((g,E)=>{var J;const U=(J=E.FreeDisk)==null?void 0:J.split(" ")[0];return g+(isNaN(U)?0:parseFloat(U))},0)/f.length).toFixed(1)+" GB",avgMemory:N(f.reduce((g,E)=>g+(E.TotalMemory||0),0)/f.length),master:((D=f.find(g=>g.NodeStatus==="MASTER"))==null?void 0:D.Hostname)||"N/A",slaves:f.filter(g=>g.NodeStatus==="SLAVE").length}}),ve=d=>d.map(u=>{var x,D,g,E,U,J,de;const j=Object.keys(u)[0],f=u[j];return{name:j||"Standalone",type:"MSSQL",totalNodes:f.length,running:f.filter(G=>G.Status==="RUNNING").length,version:((D=(x=f[0])==null?void 0:x.Version)==null?void 0:D.split(" ")[0])+" "+(((E=(g=f[0])==null?void 0:g.Version)==null?void 0:E.split(" ")[1])||"")||"N/A",locations:[...new Set(f.map(G=>G.Location))].join(", "),avgDiskFree:(f.reduce((G,C)=>{var _e;const ke=parseFloat((_e=C.FreeDisk)==null?void 0:_e.split(" ")[0]);return G+(isNaN(ke)?0:ke)},0)/f.length).toFixed(1)+" GB",avgMemory:N(f.reduce((G,C)=>G+(C.TotalMemory||0),0)/f.length),primary:((U=f.find(G=>G.HARole==="PRIMARY"||G.NodeStatus==="PRIMARY"))==null?void 0:U.Hostname)||(((J=f[0])==null?void 0:J.HARole)==="STANDALONE"?(de=f[0])==null?void 0:de.Hostname:"N/A"),secondaries:f.filter(G=>G.HARole==="SECONDARY"||G.NodeStatus==="SECONDARY").length}}),$e=be(S.mongodb||[]),se=O(S.postgresql||[]),xe=ve(S.mssql||[]),X=[...$e,...se,...xe],we=d=>d.map(u=>{const j=Object.keys(u)[0],f=u[j];return{clusterName:j,type:"MongoDB",nodes:f.map(x=>({hostname:x.Hostname,status:x.MongoStatus,nodeType:x.NodeStatus,version:x.MongoVersion,location:x.Location,freeDisk:x.FreeDisk,totalMemory:N(x.TotalMemory),vcpu:x.TotalVCPU,replicationLag:x.ReplicationLagSec,ip:x.IP,port:x.Port}))}}),ne=d=>d.map(u=>{const j=Object.keys(u)[0],f=u[j];return{clusterName:j,type:"PostgreSQL",nodes:f.map(x=>({hostname:x.Hostname,status:x.PGServiceStatus,nodeType:x.NodeStatus,version:x.PGVersion,location:x.Location,freeDisk:x.FreeDisk,totalMemory:N(x.TotalMemory),vcpu:x.TotalVCPU,replicationLag:x.ReplicationLagSec,ip:x.IP,bouncer:x.PGBouncerStatus}))}}),re=d=>d.map(u=>{const j=Object.keys(u)[0],f=u[j];return{clusterName:j||"Standalone",type:"MSSQL",nodes:f.map(x=>{var D,g;return{hostname:x.Hostname,status:x.Status,nodeType:x.HARole||x.NodeStatus,version:((D=x.Version)==null?void 0:D.split(" ")[0])+" "+(((g=x.Version)==null?void 0:g.split(" ")[1])||""),location:x.Location,freeDisk:x.FreeDisk,totalMemory:N(x.TotalMemory),vcpu:x.TotalVCPU,replicationLag:"N/A",ip:x.IP,port:x.Port}})}}),ae=we(S.mongodb||[]),p=ne(S.postgresql||[]),v=re(S.mssql||[]),$=[...ae,...p,...v],R=`
                <div style="font-family: Arial, sans-serif !important; color: #000000;">
                    <div style="text-align: center; margin-bottom: 30px; padding: 20px; background-color: #f0f2f5; border-radius: 8px;">
                        <h1 style="color: #1890ff; margin: 0; font-size: 28px; font-weight: bold;">System Health Report</h1>
                        <p style="color: #666; margin: 10px 0 0 0; font-size: 14px;">Generated on: ${F().format("YYYY-MM-DD HH:mm:ss")}</p>
                    </div>
                    
                    <div style="margin-bottom: 40px;">
                        <h2 style="color: #1890ff; font-size: 22px; margin-bottom: 20px; padding-bottom: 10px; border-bottom: 2px solid #1890ff;">
                            Cluster Health Summary
                        </h2>
                        ${X.map(d=>`
                            <div style="background-color: #fafafa; border: 1px solid #e8e8e8; padding: 20px; margin-bottom: 20px; border-radius: 8px;">
                                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                                    <h3 style="margin: 0; color: #333; font-size: 18px;">${d.name}</h3>
                                    <span style="
                                        padding: 4px 8px;
                                        border-radius: 4px;
                                        background-color: ${d.type==="MongoDB"?"#00684A":d.type==="PostgreSQL"?"#336791":"#52c41a"};
                                        color: white;
                                        font-size: 12px;
                                    ">${d.type}</span>
                                </div>
                                <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px; font-size: 14px;">
                                    <div style="background: white; padding: 10px; border-radius: 4px; border: 1px solid #e8e8e8;">
                                        <strong>Nodes:</strong> ${d.totalNodes} (${d.running} running)
                                    </div>
                                    <div style="background: white; padding: 10px; border-radius: 4px; border: 1px solid #e8e8e8;">
                                        <strong>Version:</strong> ${d.version}
                                    </div>
                                    <div style="background: white; padding: 10px; border-radius: 4px; border: 1px solid #e8e8e8;">
                                        <strong>Locations:</strong> ${d.locations}
                                    </div>
                                    <div style="background: white; padding: 10px; border-radius: 4px; border: 1px solid #e8e8e8;">
                                        <strong>Avg Free Disk:</strong> ${d.avgDiskFree}
                                    </div>
                                    <div style="background: white; padding: 10px; border-radius: 4px; border: 1px solid #e8e8e8;">
                                        <strong>Avg Memory:</strong> ${d.avgMemory}
                                    </div>
                                    <div style="background: white; padding: 10px; border-radius: 4px; border: 1px solid #e8e8e8;">
                                        <strong>${d.type==="MongoDB"?"Primary":d.type==="PostgreSQL"?"Master":"Primary"}:</strong> ${d.type==="MongoDB"?d.primary:d.type==="PostgreSQL"?d.master:d.primary}
                                    </div>
                                    <div style="background: white; padding: 10px; border-radius: 4px; border: 1px solid #e8e8e8;">
                                        <strong>${d.type==="MongoDB"?"Secondaries":d.type==="PostgreSQL"?"Slaves":"Secondaries"}:</strong> ${d.type==="MongoDB"?d.secondaries:d.type==="PostgreSQL"?d.slaves:d.secondaries}
                                    </div>
                                </div>
                            </div>
                        `).join("")}
                    </div>

                    <div style="margin-bottom: 40px;">
                        <h2 style="color: #1890ff; font-size: 22px; margin-bottom: 20px; padding-bottom: 10px; border-bottom: 2px solid #1890ff;">
                            Node Status Details
                        </h2>
                        ${$.map(d=>`
                            <div style="margin-bottom: 30px;">
                                <div style="display: flex; align-items: center; margin-bottom: 15px;">
                                    <h3 style="margin: 0; color: #333; font-size: 18px;">${d.clusterName}</h3>
                                    <span style="
                                        margin-left: 10px;
                                        padding: 4px 8px;
                                        border-radius: 4px;
                                        background-color: ${d.type==="MongoDB"?"#00684A":d.type==="PostgreSQL"?"#336791":"#52c41a"};
                                        color: white;
                                        font-size: 12px;
                                    ">${d.type}</span>
                                </div>
                                <div style="overflow-x: auto;">
                                    <table style="width: 100%; border-collapse: collapse; font-size: 13px;">
                                        <thead>
                                            <tr style="background-color: #fafafa;">
                                                <th style="padding: 12px; border: 1px solid #e8e8e8; text-align: left;">Hostname</th>
                                                <th style="padding: 12px; border: 1px solid #e8e8e8; text-align: left;">Status</th>
                                                <th style="padding: 12px; border: 1px solid #e8e8e8; text-align: left;">Role</th>
                                                <th style="padding: 12px; border: 1px solid #e8e8e8; text-align: left;">Version</th>
                                                <th style="padding: 12px; border: 1px solid #e8e8e8; text-align: left;">Location</th>
                                                <th style="padding: 12px; border: 1px solid #e8e8e8; text-align: left;">Free Disk</th>
                                                <th style="padding: 12px; border: 1px solid #e8e8e8; text-align: left;">Memory</th>
                                                <th style="padding: 12px; border: 1px solid #e8e8e8; text-align: left;">vCPU</th>
                                                <th style="padding: 12px; border: 1px solid #e8e8e8; text-align: left;">Replication Lag</th>
                                                ${d.type==="PostgreSQL"?`
                                                    <th style="padding: 12px; border: 1px solid #e8e8e8; text-align: left;">PgBouncer</th>
                                                `:`
                                                    <th style="padding: 12px; border: 1px solid #e8e8e8; text-align: left;">Port</th>
                                                `}
                                            </tr>
                                        </thead>
                                        <tbody>
                                            ${d.nodes.map(u=>`
                                                <tr>
                                                    <td style="padding: 12px; border: 1px solid #e8e8e8;">
                                                        ${u.hostname}
                                                        <div style="font-size: 11px; color: #666;">${u.ip}</div>
                                                    </td>
                                                    <td style="padding: 12px; border: 1px solid #e8e8e8;">
                                                        <span style="
                                                            padding: 4px 8px;
                                                            border-radius: 4px;
                                                            background-color: ${u.status==="RUNNING"?"#52c41a":"#ff4d4f"};
                                                            color: white;
                                                            font-size: 11px;
                                                        ">${u.status}</span>
                                                    </td>
                                                    <td style="padding: 12px; border: 1px solid #e8e8e8;">
                                                        <span style="
                                                            padding: 4px 8px;
                                                            border-radius: 4px;
                                                            background-color: ${u.nodeType==="PRIMARY"||u.nodeType==="MASTER"?"#1890ff":u.nodeType==="SECONDARY"||u.nodeType==="SLAVE"||u.nodeType==="STANDALONE"?"#52c41a":"#faad14"};
                                                            color: white;
                                                            font-size: 11px;
                                                        ">${u.nodeType}</span>
                                                    </td>
                                                    <td style="padding: 12px; border: 1px solid #e8e8e8;">${u.version}</td>
                                                    <td style="padding: 12px; border: 1px solid #e8e8e8;">${u.location}</td>
                                                    <td style="padding: 12px; border: 1px solid #e8e8e8;">${u.freeDisk}</td>
                                                    <td style="padding: 12px; border: 1px solid #e8e8e8;">${u.totalMemory}</td>
                                                    <td style="padding: 12px; border: 1px solid #e8e8e8;">${u.vcpu}</td>
                                                    <td style="padding: 12px; border: 1px solid #e8e8e8;">
                                                        ${u.replicationLag===0?'<span style="color: #52c41a;">No Lag</span>':u.replicationLag==="N/A"?'<span style="color: #666;">N/A</span>':`<span style="color: #ff4d4f;">${u.replicationLag}s</span>`}
                                                    </td>
                                                    ${d.type==="PostgreSQL"?`
                                                        <td style="padding: 12px; border: 1px solid #e8e8e8;">
                                                            ${u.bouncer==="N/A"?'<span style="color: #666;">N/A</span>':`<span style="color: ${u.bouncer==="RUNNING"?"#52c41a":"#ff4d4f"}">${u.bouncer}</span>`}
                                                        </td>
                                                    `:`
                                                        <td style="padding: 12px; border: 1px solid #e8e8e8;">${u.port}</td>
                                                    `}
                                                </tr>
                                            `).join("")}
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        `).join("")}
                    </div>

                </div>
            `;z.innerHTML=R,document.body.appendChild(z),await new Promise(d=>setTimeout(d,2e3));try{const d=new et("p","pt","a4"),u=await tt(z,{scale:1.5,useCORS:!0,logging:!0,backgroundColor:"#ffffff",windowWidth:800,windowHeight:z.offsetHeight,onclone:(G,C)=>{C.style.width="800px",C.style.height="auto",C.style.margin="0",C.style.padding="20px"}}),j=u.toDataURL("image/jpeg",1),f=d.internal.pageSize.getWidth(),x=d.internal.pageSize.getHeight(),D=u.width,g=u.height,E=f/D;let U=g*E,J=0,de=1;for(d.addImage(j,"JPEG",0,J,f,g*E);U>=x;)J=-x*de,d.addPage(),d.addImage(j,"JPEG",0,J,f,g*E),U-=x,de++;d.save("system-health-report.pdf"),document.body.removeChild(z),B.success({content:"Report generated successfully",key:"report"})}catch{B.error({content:"Failed to generate report",key:"report"}),document.body.removeChild(z)}}catch{B.error({content:"Failed to generate report",key:"report"})}},gt=()=>{A.resetFields(),A.setFieldsValue({timeRange:{type:"relative",relative:"1d"},sections:{systemMetrics:!0,diskAnalysis:!0,mongoAnalysis:{enabled:!0,includeCollections:!0,includeIndexes:!0,includePerformance:!0},postgresAnalysis:{enabled:!0,includeBloat:!0,includeSlowQueries:!0,includeConnections:!0},mssqlAnalysis:{enabled:!0,includeCapacityPlanning:!0,includePerformance:!0},alarmsAnalysis:!0,recommendations:!0}}),l(!0)},mt=async()=>{var i,n,a,y;try{const m=await A.validateFields();ge(!0),B.loading({content:"Generating comprehensive report...",key:"comprehensive-report"});const S=localStorage.getItem("token"),Y=m.nodes||[],P={timeRange:m.timeRange,clusters:Y,sections:m.sections},I=await fetch(`${Z()}/api/v1/reports/generate`,{method:"POST",headers:{"Content-Type":"application/json",CEFE:"Yes",...S?{Authorization:`Bearer ${S}`}:{}},body:JSON.stringify(P)});if(!I.ok)throw new Error("Failed to generate report");const H=await I.json();if(Se(H.data),De(m),m.reportVersion==="v2"){const _=((n=(i=$t.getState().license)==null?void 0:i.features)==null?void 0:n.ai)??!1,z={clusters:Y,timeRange:m.timeRange,timeRangeLabel:m.timeRange.type==="relative"?`Last ${m.timeRange.relative}`:`${(a=m.timeRange.absolute)==null?void 0:a.startDate} to ${(y=m.timeRange.absolute)==null?void 0:y.endDate}`},N=await Xt(z,H.data,_),be=gi(N),O=document.createElement("div");O.style.padding="20px",O.style.backgroundColor="white",O.style.width="800px",O.style.position="absolute",O.style.left="-9999px",O.style.top="0",O.style.fontFamily="'Segoe UI', system-ui, -apple-system, sans-serif",O.innerHTML=be,document.body.appendChild(O),await new Promise(R=>setTimeout(R,500));const{default:ve}=await Be(()=>import("./html2canvas.esm-71958c39.js"),[]),{default:$e}=await Be(()=>import("./jspdf.es.min-356536ba.js"),["assets/jspdf.es.min-356536ba.js","assets/index-0c6cb722.js","assets/vendor-core-32e3221b.js","assets/vendor-utils-25255252.js","assets/index-f3a031ec.css"]),se=await ve(O,{scale:1.5,useCORS:!0,backgroundColor:"#ffffff"});document.body.removeChild(O);const xe=se.toDataURL("image/jpeg",.95),X=new $e("p","mm","a4"),we=X.internal.pageSize.getWidth(),ne=X.internal.pageSize.getHeight(),re=we,ae=se.height*re/se.width;let p=ae,v=0;for(X.addImage(xe,"JPEG",0,v,re,ae),p-=ne;p>0;)v-=ne,X.addPage(),X.addImage(xe,"JPEG",0,v,re,ae),p-=ne;const $=`clustereye-report-v2-${new Date().toISOString().slice(0,10)}.pdf`;X.save($)}else await xt(H.data,m);B.success({content:"Comprehensive report generated successfully!",key:"comprehensive-report"}),l(!1)}catch{B.error({content:"Failed to generate comprehensive report",key:"comprehensive-report"})}finally{ge(!1)}},xt=async(i,n)=>{var P,I,H,_,z,N,be,O,ve,$e,se,xe,X,we,ne,re,ae;const a=document.createElement("div");a.style.padding="20px",a.style.backgroundColor="white",a.style.width="800px",a.style.position="absolute",a.style.left="-9999px",a.style.top="0",a.style.fontFamily="Arial, sans-serif";const y=(n.clusters||[]).map(p=>p.replace("agent_","")).join(", "),m=n.timeRange.type==="relative"?`Last ${n.timeRange.relative}`:`${F(n.timeRange.absolute.startDate).format("YYYY-MM-DD HH:mm")} to ${F(n.timeRange.absolute.endDate).format("YYYY-MM-DD HH:mm")}`,S=`
            <div style="margin-bottom: 40px;">
                <h2 style="color: #1890ff; font-size: 22px; margin-bottom: 20px; padding-bottom: 10px; border-bottom: 2px solid #1890ff;">
                    Recent Alarms (Last 24 Hours)
                </h2>
                <table style="width: 100%; border-collapse: collapse; font-size: 14px;">
                    <thead>
                        <tr style="background-color: #fafafa;">
                            <th style="padding: 12px; border: 1px solid #e8e8e8; text-align: left; font-weight: bold;">Severity</th>
                            <th style="padding: 12px; border: 1px solid #e8e8e8; text-align: left; font-weight: bold;">Type</th>
                            <th style="padding: 12px; border: 1px solid #e8e8e8; text-align: left; font-weight: bold;">Host</th>
                            <th style="padding: 12px; border: 1px solid #e8e8e8; text-align: left; font-weight: bold;">Message</th>
                            <th style="padding: 12px; border: 1px solid #e8e8e8; text-align: left; font-weight: bold;">Time</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${(i.recentAlarms||[]).map(p=>`
                            <tr>
                                <td style="padding: 12px; border: 1px solid #e8e8e8;">
                                    <span style="
                                        padding: 4px 8px;
                                        border-radius: 4px;
                                        background-color: ${p.severity==="critical"?"#ff4d4f":p.severity==="warning"?"#faad14":"#1890ff"};
                                        color: white;
                                        font-size: 12px;
                                        display: inline-block;
                                    ">${p.severity.toUpperCase()}</span>
                                </td>
                                <td style="padding: 12px; border: 1px solid #e8e8e8;">${p.metric_name}</td>
                                <td style="padding: 12px; border: 1px solid #e8e8e8;">${p.agent_id.replace("agent_","")}</td>
                                <td style="padding: 12px; border: 1px solid #e8e8e8;">${p.message.length>100?p.message.substring(0,100)+"...":p.message}</td>
                                <td style="padding: 12px; border: 1px solid #e8e8e8;">${F(p.created_at).format("YYYY-MM-DD HH:mm")}</td>
                            </tr>
                        `).join("")}
                    </tbody>
                </table>
                
                <div style="margin-top: 15px; display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                    <div style="background: #fff2e8; padding: 12px; border-radius: 6px; text-align: center;">
                        <strong style="color: #fa8c16;">Total Alarms</strong>
                        <div style="font-size: 24px; font-weight: bold; color: #fa8c16; margin-top: 5px;">
                            ${(i.recentAlarms||[]).length}
                        </div>
                    </div>
                    <div style="background: #fff1f0; padding: 12px; border-radius: 6px; text-align: center;">
                        <strong style="color: #ff4d4f;">Critical Events</strong>
                        <div style="font-size: 24px; font-weight: bold; color: #ff4d4f; margin-top: 5px;">
                            ${(i.recentAlarms||[]).filter(p=>p.severity==="critical").length}
                        </div>
                    </div>
                </div>
            </div>
        `,Y=`
            <div style="max-width: 800px; margin: 0 auto; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; line-height: 1.6;">
                <!-- Header Section -->
                <div style="text-align: center; margin-bottom: 50px; padding: 30px; background: linear-gradient(135deg, #1890ff 0%, #40a9ff 100%); border-radius: 10px; color: white;">
                    <div style="background: white; display: inline-block; padding: 15px 25px; border-radius: 50px; margin-bottom: 20px;">
                        <h1 style="color: #1890ff; font-size: 36px; margin: 0; font-weight: 700;">
                            ClusterEye
                        </h1>
                    </div>
                    <h2 style="font-size: 28px; margin: 0 0 15px 0; font-weight: 600;">
                        Comprehensive Database Report
                    </h2>
                    <div style="background: rgba(255,255,255,0.2); padding: 15px; border-radius: 8px; margin: 20px 0;">
                        <p style="font-size: 16px; margin: 0;">
                            <strong>Generated:</strong> ${F().format("YYYY-MM-DD HH:mm:ss")}
                        </p>
                        <p style="font-size: 16px; margin: 5px 0 0 0;">
                            <strong>Nodes:</strong> ${y}
                        </p>
                        <p style="font-size: 16px; margin: 5px 0 0 0;">
                            <strong>Time Range:</strong> ${m}
                        </p>
                    </div>
                </div>

                <!-- Executive Summary -->
                <div style="margin-bottom: 40px; padding: 25px; background: #f8f9fa; border-radius: 10px; border-left: 5px solid #52c41a;">
                    <h2 style="color: #52c41a; font-size: 22px; margin-bottom: 15px; font-weight: 600;">
                        📊 Executive Summary
                    </h2>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                        <div>
                            <p style="font-size: 14px; color: #666; margin: 0;">Total Clusters Analyzed</p>
                            <p style="font-size: 24px; font-weight: bold; color: #1890ff; margin: 5px 0;">${(n.clusters||[]).length}</p>
                        </div>
                        <div>
                            <p style="font-size: 14px; color: #666; margin: 0;">Analysis Period</p>
                            <p style="font-size: 16px; font-weight: bold; color: #1890ff; margin: 5px 0;">${m}</p>
                        </div>
                    </div>
                    <div style="margin-top: 15px; padding: 15px; background: white; border-radius: 6px;">
                        <h4 style="margin: 0 0 10px 0; color: #262626;">Report Sections Included:</h4>
                        <div style="display: flex; flex-wrap: wrap; gap: 8px;">
                            ${n.sections.systemMetrics?'<span style="background: #e6f7ff; color: #1890ff; padding: 4px 8px; border-radius: 4px; font-size: 12px;">System Metrics</span>':""}
                            ${n.sections.diskAnalysis?'<span style="background: #e6f7ff; color: #1890ff; padding: 4px 8px; border-radius: 4px; font-size: 12px;">Disk Analysis</span>':""}
                            ${(P=n.sections.mongoAnalysis)!=null&&P.enabled?'<span style="background: #e6f7ff; color: #1890ff; padding: 4px 8px; border-radius: 4px; font-size: 12px;">MongoDB</span>':""}
                            ${(I=n.sections.postgresAnalysis)!=null&&I.enabled?'<span style="background: #e6f7ff; color: #1890ff; padding: 4px 8px; border-radius: 4px; font-size: 12px;">PostgreSQL</span>':""}
                            ${(H=n.sections.mssqlAnalysis)!=null&&H.enabled?'<span style="background: #e6f7ff; color: #1890ff; padding: 4px 8px; border-radius: 4px; font-size: 12px;">MSSQL</span>':""}
                            ${n.sections.alarmsAnalysis?'<span style="background: #e6f7ff; color: #1890ff; padding: 4px 8px; border-radius: 4px; font-size: 12px;">Alarms</span>':""}
                            ${n.sections.recommendations?'<span style="background: #e6f7ff; color: #1890ff; padding: 4px 8px; border-radius: 4px; font-size: 12px;">Capacity Planning</span>':""}
                        </div>
                    </div>
                </div>

                ${n.sections.systemMetrics?`
                    <div style="margin-bottom: 50px; padding: 25px; background: white; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); border-left: 5px solid #1890ff;">
                        <div style="display: flex; align-items: center; margin-bottom: 20px;">
                            <div style="background: #1890ff; color: white; width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-right: 15px; font-size: 18px;">
                                📊
                            </div>
                            <h2 style="color: #1890ff; font-size: 24px; margin: 0; font-weight: 600;">
                                CPU & Memory Performance
                            </h2>
                        </div>
                        <p style="margin-bottom: 20px; color: #666; font-size: 16px;">
                            CPU and Memory utilization analysis with min/max/avg statistics and trends
                        </p>
                        <div style="background: linear-gradient(135deg, #f0f9ff 0%, #e6f7ff 100%); padding: 20px; border-radius: 8px; border: 1px solid #d6f7ff;">
                            <!-- CPU Analysis Section -->
                            <div style="margin-bottom: 30px; padding: 20px; background: white; border-radius: 8px; border: 1px solid #e8f4ff;">
                                <h3 style="margin: 0 0 15px 0; color: #1890ff; font-size: 18px; font-weight: 600;">🖥️ CPU Performance</h3>
                                ${(()=>{var f,x,D;const p=((f=i.capacityPlanning)==null?void 0:f.cpuTrends)||[];if(p.length===0)return'<div style="color: #ff4d4f;">❌ No CPU data available</div>';const v=p.map(g=>g._value).filter(g=>g!=null);if(v.length===0)return'<div style="color: #ff4d4f;">❌ No valid CPU data</div>';const $=Math.min(...v),R=Math.max(...v),d=v.reduce((g,E)=>g+E,0)/v.length,u=p.find(g=>g._value===$),j=p.find(g=>g._value===R);return`
                                        <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 15px; margin-bottom: 20px;">
                                            <div style="text-align: center; padding: 12px; background: #f0f9ff; border-radius: 6px;">
                                                <p style="margin: 0; color: #666; font-size: 12px;">Minimum</p>
                                                <p style="margin: 5px 0 0 0; font-size: 20px; font-weight: bold; color: #52c41a;">${$.toFixed(1)}%</p>
                                                <p style="margin: 5px 0 0 0; font-size: 10px; color: #999;">${u?new Date(u._time).toLocaleString():"N/A"}</p>
                                            </div>
                                            <div style="text-align: center; padding: 12px; background: #fff7e6; border-radius: 6px;">
                                                <p style="margin: 0; color: #666; font-size: 12px;">Average</p>
                                                <p style="margin: 5px 0 0 0; font-size: 20px; font-weight: bold; color: #fa8c16;">${d.toFixed(1)}%</p>
                                                <p style="margin: 5px 0 0 0; font-size: 10px; color: #999;">${p.length} data points</p>
                                            </div>
                                            <div style="text-align: center; padding: 12px; background: #fff1f0; border-radius: 6px;">
                                                <p style="margin: 0; color: #666; font-size: 12px;">Maximum</p>
                                                <p style="margin: 5px 0 0 0; font-size: 20px; font-weight: bold; color: #ff4d4f;">${R.toFixed(1)}%</p>
                                                <p style="margin: 5px 0 0 0; font-size: 10px; color: #999;">${j?new Date(j._time).toLocaleString():"N/A"}</p>
                                            </div>
                                        </div>
                                        <div style="height: 100px; background: linear-gradient(135deg, #f0f9ff 0%, #e6f7ff 100%); border-radius: 6px; padding: 15px; position: relative; overflow: hidden;">
                                            ${p.slice(-15).map((g,E)=>{const U=g._value/R*70;return`<div style="position: absolute; bottom: 15px; left: ${15+E*(750/15)}px; width: 4px; height: ${U}px; background: #1890ff; border-radius: 2px;" title="${g._value}% at ${new Date(g._time).toLocaleString()}"></div>`}).join("")}
                                            <div style="position: absolute; bottom: 5px; right: 15px; font-size: 10px; color: #999;">Latest: ${((D=(x=p.slice(-1)[0])==null?void 0:x._value)==null?void 0:D.toFixed(1))||0}%</div>
                                            <div style="position: absolute; bottom: 5px; left: 15px; font-size: 10px; color: #999;">15 points timeline</div>
                                        </div>
                                    `})()}
                            </div>
                            
                            <!-- Memory Analysis Section -->
                            <div style="margin-bottom: 30px; padding: 20px; background: white; border-radius: 8px; border: 1px solid #f6ffed;">
                                <h3 style="margin: 0 0 15px 0; color: #52c41a; font-size: 18px; font-weight: 600;">🧠 Memory Performance</h3>
                                ${(()=>{var E,U,J,de,G;let p=((U=(E=i.capacityPlanning)==null?void 0:E.memoryTrends)==null?void 0:U.filter(C=>C._field==="memory_usage"||C._field==="free_memory"))||[];if(p.length===0&&(p=((J=i.memoryTrends)==null?void 0:J.filter(C=>C._field==="memory_usage"||C._field==="free_memory"))||[]),p.length===0)return'<div style="color: #ff4d4f;">❌ No Memory data available</div>';const v=p.map(C=>C._value).filter(C=>C!=null);if(v.length===0)return'<div style="color: #ff4d4f;">❌ No valid Memory data</div>';const $=Math.min(...v),R=Math.max(...v),d=v.reduce((C,ke)=>C+ke,0)/v.length,u=p.find(C=>C._value===$),j=p.find(C=>C._value===R),f=((de=p[0])==null?void 0:de._field)||"",x=Math.max(...v),D=f==="memory_usage"&&x<=100&&Math.min(...v)>=0,g=C=>D?C.toFixed(1)+"%":C>1024*1024*1024?(C/1024/1024/1024).toFixed(1)+" GB":C>1024*1024?(C/1024/1024).toFixed(1)+" MB":C.toFixed(1)+" MB";return`
                                        <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 15px; margin-bottom: 20px;">
                                            <div style="text-align: center; padding: 12px; background: #f0f9ff; border-radius: 6px;">
                                                <p style="margin: 0; color: #666; font-size: 12px;">Minimum</p>
                                                <p style="margin: 5px 0 0 0; font-size: 20px; font-weight: bold; color: #52c41a;">${g($)}</p>
                                                <p style="margin: 5px 0 0 0; font-size: 10px; color: #999;">${u?new Date(u._time).toLocaleString():"N/A"}</p>
                                            </div>
                                            <div style="text-align: center; padding: 12px; background: #fff7e6; border-radius: 6px;">
                                                <p style="margin: 0; color: #666; font-size: 12px;">Average</p>
                                                <p style="margin: 5px 0 0 0; font-size: 20px; font-weight: bold; color: #fa8c16;">${g(d)}</p>
                                                <p style="margin: 5px 0 0 0; font-size: 10px; color: #999;">${p.length} data points</p>
                                            </div>
                                            <div style="text-align: center; padding: 12px; background: #fff1f0; border-radius: 6px;">
                                                <p style="margin: 0; color: #666; font-size: 12px;">Maximum</p>
                                                <p style="margin: 5px 0 0 0; font-size: 20px; font-weight: bold; color: #ff4d4f;">${g(R)}</p>
                                                <p style="margin: 5px 0 0 0; font-size: 10px; color: #999;">${j?new Date(j._time).toLocaleString():"N/A"}</p>
                                            </div>
                                        </div>
                                        <div style="height: 100px; background: linear-gradient(135deg, #f6ffed 0%, #e6ffe6 100%); border-radius: 6px; padding: 15px; position: relative; overflow: hidden;">
                                            ${p.slice(-15).map((C,ke)=>{const _e=C._value/R*70,bt=15+ke*(750/15),vt=D?C._value.toFixed(1)+"%":(C._value/1024/1024/1024).toFixed(1)+" GB";return`<div style="position: absolute; bottom: 15px; left: ${bt}px; width: 4px; height: ${_e}px; background: #52c41a; border-radius: 2px;" title="${vt} at ${new Date(C._time).toLocaleString()}"></div>`}).join("")}
                                            <div style="position: absolute; bottom: 5px; right: 15px; font-size: 10px; color: #999;">Latest: ${g(((G=p.slice(-1)[0])==null?void 0:G._value)||0)}</div>
                                            <div style="position: absolute; bottom: 5px; left: 15px; font-size: 10px; color: #999;">15 points timeline</div>
                                        </div>
                                    `})()}
                            </div>
                        </div>
                    </div>

                ${i.mongoAnalysis?`
                                <div style="margin-top: 20px; padding: 15px; background: white; border-radius: 6px; border: 1px solid #d9d9d9;">
                                    <h4 style="margin: 0 0 15px 0; color: #333;">MongoDB Analysis Results</h4>
                                    ${Object.entries(i.mongoAnalysis).map(([p,v])=>`
                                        <div style="margin-bottom: 20px; padding: 15px; background: #f8f8f8; border-radius: 4px;">
                                            <strong style="color: #52c41a; font-size: 16px;">${p.replace("agent_","")}:</strong>
                                            
                                            ${v.collections?(()=>{try{const $=JSON.parse(atob(v.collections.value));return $.status==="success"?`
                                                            <div style="margin-top: 12px; padding: 10px; background: white; border-radius: 4px;">
                                                                <strong>🗃️ Databases:</strong>
                                                                <div style="margin-top: 8px; font-size: 11px;">
                                                                    ${($.data||[]).slice(0,5).map(R=>`
                                                                        <span style="display: inline-block; margin: 2px 4px; padding: 2px 6px; background: #e6fffb; border-radius: 2px;">
                                                                            ${R.name}: ${R.sizeOnDisk?Math.round(R.sizeOnDisk/1024/1024)+"MB":"N/A"}
                                                                        </span>
                                                                    `).join("")}
                                                                </div>
                                                            </div>
                                                        `:`<div style="margin-top: 8px; color: #ff4d4f; font-size: 11px;">❌ ${$.message}</div>`}catch{}return'<div style="margin-top: 8px; color: #999;">🗃️ Collections: Processing...</div>'})():'<div style="margin-top: 8px; color: #999;">🗃️ Collections: N/A</div>'}
                                            
                                            ${v.indexUsage?(()=>{try{const $=JSON.parse(atob(v.indexUsage.value));return $.status==="success"?`
                                                            <div style="margin-top: 12px; padding: 10px; background: white; border-radius: 4px;">
                                                                <strong>📇 Index Analysis:</strong>
                                                                <div style="margin-top: 8px; font-size: 11px; color: #52c41a;">
                                                                    ✅ Index usage statistics analyzed
                                                                </div>
                                                            </div>
                                                        `:`<div style="margin-top: 8px; color: #ff4d4f; font-size: 11px;">❌ ${$.message}</div>`}catch{}return'<div style="margin-top: 8px; color: #999;">📇 Indexes: Processing...</div>'})():'<div style="margin-top: 8px; color: #999;">📇 Indexes: N/A</div>'}
                                            
                                            ${v.performance?(()=>{try{const $=JSON.parse(atob(v.performance.value));return $.status==="success"?`
                                                            <div style="margin-top: 12px; padding: 10px; background: white; border-radius: 4px;">
                                                                <strong>⚡ Performance Metrics:</strong>
                                                                <div style="margin-top: 8px; font-size: 11px; color: #52c41a;">
                                                                    ✅ Performance analysis completed
                                                                </div>
                                                            </div>
                                                        `:`<div style="margin-top: 8px; color: #ff4d4f; font-size: 11px;">❌ ${$.message}</div>`}catch{}return'<div style="margin-top: 8px; color: #999;">⚡ Performance: Processing...</div>'})():'<div style="margin-top: 8px; color: #999;">⚡ Performance: N/A</div>'}
                                        </div>
                                    `).join("")}
                                </div>
                            `:""}
                        </div>
                    </div>
                `:""}

                ${n.sections.diskAnalysis?`
                    <div style="margin-bottom: 50px; padding: 25px; background: white; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); border-left: 5px solid #fa8c16;">
                        <div style="display: flex; align-items: center; margin-bottom: 20px;">
                            <div style="background: #fa8c16; color: white; width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-right: 15px; font-size: 18px;">
                                💾
                            </div>
                            <h2 style="color: #fa8c16; font-size: 24px; margin: 0; font-weight: 600;">
                                Disk Analysis & Capacity Planning
                            </h2>
                        </div>
                        <p style="margin-bottom: 20px; color: #666; font-size: 16px;">
                            Storage utilization patterns, growth trends, and filesystem analysis
                        </p>
                        <div style="background: linear-gradient(135deg, #fff7e6 0%, #ffeee6 100%); padding: 20px; border-radius: 8px; border: 1px solid #ffd6b8;">
                            <div style="background: rgba(250, 140, 22, 0.1); padding: 12px; border-radius: 6px;">
                                <p style="margin: 0; font-size: 14px; color: #fa8c16;"><strong>💽 Storage Data:</strong> ${i.diskAnalysis?Object.keys(i.diskAnalysis).length:0} metrics collected</p>
                                <p style="margin: 8px 0 0 0; font-size: 14px; color: #666;"><em>Disk utilization trends, filesystem details, and growth projections analyzed</em></p>
                            </div>
                        </div>
                    </div>
                `:""}

                ${(_=n.sections.mongoAnalysis)!=null&&_.enabled?`
                    <div style="margin-bottom: 50px; padding: 25px; background: white; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); border-left: 5px solid #52c41a;">
                        <div style="display: flex; align-items: center; margin-bottom: 20px;">
                            <div style="background: #52c41a; color: white; width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-right: 15px; font-size: 18px;">
                                🍃
                            </div>
                            <h2 style="color: #52c41a; font-size: 24px; margin: 0; font-weight: 600;">
                                MongoDB Analysis
                            </h2>
                        </div>
                        <p style="margin-bottom: 20px; color: #666; font-size: 16px;">
                            ${n.sections.mongoAnalysis.includeCollections?"Collections, ":""}
                            ${n.sections.mongoAnalysis.includeIndexes?"Indexes, ":""}
                            ${n.sections.mongoAnalysis.includePerformance?"Performance ":""}
                            analysis for MongoDB clusters
                        </p>
                        <div style="background: linear-gradient(135deg, #f6ffed 0%, #e6f7ff 100%); padding: 20px; border-radius: 8px; border: 1px solid #b7eb8f;">
                            <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 15px; margin-bottom: 15px;">
                                ${n.sections.mongoAnalysis.includeCollections?`
                                    <div style="background: white; padding: 15px; border-radius: 6px; text-align: center;">
                                        <p style="margin: 0; color: #666; font-size: 14px;">Collections</p>
                                        <p style="margin: 5px 0 0 0; font-size: 16px; font-weight: bold; color: #52c41a;">
                                            ${i.mongoAnalysis?"✅ Analyzed":"❌ No Data"}
                                        </p>
                                    </div>
                                `:""}
                                ${n.sections.mongoAnalysis.includeIndexes?`
                                    <div style="background: white; padding: 15px; border-radius: 6px; text-align: center;">
                                        <p style="margin: 0; color: #666; font-size: 14px;">Indexes</p>
                                        <p style="margin: 5px 0 0 0; font-size: 16px; font-weight: bold; color: #52c41a;">
                                            ${i.mongoAnalysis?"✅ Analyzed":"❌ No Data"}
                                        </p>
                                    </div>
                                `:""}
                                ${n.sections.mongoAnalysis.includePerformance?`
                                    <div style="background: white; padding: 15px; border-radius: 6px; text-align: center;">
                                        <p style="margin: 0; color: #666; font-size: 14px;">Performance</p>
                                        <p style="margin: 5px 0 0 0; font-size: 16px; font-weight: bold; color: #52c41a;">
                                            ${i.mongoAnalysis?"✅ Analyzed":"❌ No Data"}
                                        </p>
                                    </div>
                                `:""}
                            </div>
                        </div>
                    </div>
                `:""}

                ${(z=n.sections.postgresAnalysis)!=null&&z.enabled?`
                    <div style="margin-bottom: 50px; padding: 25px; background: white; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); border-left: 5px solid #1890ff;">
                        <div style="display: flex; align-items: center; margin-bottom: 20px;">
                            <div style="background: #1890ff; color: white; width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-right: 15px; font-size: 18px;">
                                🐘
                            </div>
                            <h2 style="color: #1890ff; font-size: 24px; margin: 0; font-weight: 600;">
                                PostgreSQL Analysis
                            </h2>
                        </div>
                        <p style="margin-bottom: 20px; color: #666; font-size: 16px;">
                            Bloat analysis, top queries, and connection statistics for PostgreSQL clusters
                        </p>
                        <div style="background: linear-gradient(135deg, #f0f9ff 0%, #e6f7ff 100%); padding: 20px; border-radius: 8px; border: 1px solid #d6f7ff;">
                            
                            ${i.postgresAnalysis?`
                                <div style="margin-top: 20px; padding: 15px; background: white; border-radius: 6px; border: 1px solid #d9d9d9;">
                                    <h4 style="margin: 0 0 15px 0; color: #333;">PostgreSQL Analysis Results</h4>
                                    ${Object.entries(i.postgresAnalysis).map(([p,v])=>`
                                        <div style="margin-bottom: 20px; padding: 15px; background: #f8f8f8; border-radius: 4px;">
                                            <strong style="color: #1890ff; font-size: 16px;">${p.replace("agent_","")}:</strong>
                                            
                                            ${v.connectionStats?(()=>{try{const $=JSON.parse(atob(v.connectionStats.value));if($.status==="success")return`
                                                            <div style="margin-top: 12px; padding: 10px; background: white; border-radius: 4px;">
                                                                <strong>🔗 Connection Analysis:</strong>
                                                                <div style="margin-top: 8px; display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 8px; font-size: 11px;">
                                                                    <span>Idle: ${$.count_0||0}</span>
                                                                    <span>Active: ${$.count_1||0}</span>
                                                                    <span>Total: ${($.count_0||0)+($.count_1||0)}</span>
                                                                </div>
                                                            </div>
                                                        `}catch{}return'<div style="margin-top: 8px; color: #999;">🔗 Connections: Processing...</div>'})():'<div style="margin-top: 8px; color: #999;">🔗 Connections: N/A</div>'}
                                            
                                            ${v.tableBloat?(()=>{try{const $=JSON.parse(atob(v.tableBloat.value));if($.status==="success")return`
                                                            <div style="margin-top: 12px; padding: 10px; background: white; border-radius: 4px;">
                                                                <strong>📊 Table Sizes (Top 5):</strong>
                                                                <div style="margin-top: 8px; font-size: 11px;">
                                                                    ${($.data||[]).slice(0,5).map(R=>`
                                                                        <div style="margin: 2px 0; padding: 2px 0;">
                                                                            ${R.schemaname}.${R.tablename}: ${R.size}
                                                                        </div>
                                                                    `).join("")}
                                                                </div>
                                                            </div>
                                                        `}catch{}return'<div style="margin-top: 8px; color: #999;">📊 Table Analysis: Processing...</div>'})():'<div style="margin-top: 8px; color: #999;">📊 Table Analysis: N/A</div>'}
                                            
                                            ${v.topQueries?(()=>{try{const $=JSON.parse(atob(v.topQueries.value));if($.status==="success")return`
                                                            <div style="margin-top: 12px; padding: 10px; background: white; border-radius: 4px;">
                                                                <strong>🔍 Active Queries:</strong>
                                                                <div style="margin-top: 8px; font-size: 11px;">
                                                                    ${($.data||[]).slice(0,3).map(R=>{var d;return`
                                                                        <div style="margin: 4px 0; padding: 4px; background: #f0f0f0; border-radius: 2px;">
                                                                            <strong>${R.usename}</strong>: ${(R.query||"").substring(0,80)}${((d=R.query)==null?void 0:d.length)>80?"...":""}
                                                                            <br><span style="color: #666;">State: ${R.state}</span>
                                                                        </div>
                                                                    `}).join("")}
                                                                </div>
                                                            </div>
                                                        `}catch{}return'<div style="margin-top: 8px; color: #999;">🔍 Queries: Processing...</div>'})():'<div style="margin-top: 8px; color: #999;">🔍 Queries: N/A</div>'}
                                        </div>
                                    `).join("")}
                                </div>
                            `:""}
                        </div>
                    </div>
                `:""}

                ${(N=n.sections.mssqlAnalysis)!=null&&N.enabled?`
                    <div style="margin-bottom: 50px; padding: 25px; background: white; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); border-left: 5px solid #722ed1;">
                        <div style="display: flex; align-items: center; margin-bottom: 20px;">
                            <div style="background: #722ed1; color: white; width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-right: 15px; font-size: 18px;">
                                🗄️
                            </div>
                            <h2 style="color: #722ed1; font-size: 24px; margin: 0; font-weight: 600;">
                                MSSQL Analysis
                            </h2>
                        </div>
                        <p style="margin-bottom: 20px; color: #666; font-size: 16px;">
                            ${n.sections.mssqlAnalysis.includeCapacityPlanning?"Capacity planning, ":""}
                            ${n.sections.mssqlAnalysis.includePerformance?"Performance ":""}
                            analysis for MSSQL Server clusters
                        </p>
                        <div style="background: linear-gradient(135deg, #f9f0ff 0%, #f0e6ff 100%); padding: 20px; border-radius: 8px; border: 1px solid #d3adf7;">
                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 15px;">
                                ${n.sections.mssqlAnalysis.includeCapacityPlanning?`
                                    <div style="background: white; padding: 15px; border-radius: 6px; text-align: center;">
                                        <p style="margin: 0; color: #666; font-size: 14px;">Capacity Planning</p>
                                        <p style="margin: 5px 0 0 0; font-size: 16px; font-weight: bold; color: #722ed1;">
                                            ${(be=i.mssqlAnalysis)!=null&&be.capacity?"✅ Analyzed":"📊 Ready"}
                                        </p>
                                    </div>
                                `:""}
                                ${n.sections.mssqlAnalysis.includePerformance?`
                                    <div style="background: white; padding: 15px; border-radius: 6px; text-align: center;">
                                        <p style="margin: 0; color: #666; font-size: 14px;">Performance</p>
                                        <p style="margin: 5px 0 0 0; font-size: 16px; font-weight: bold; color: #722ed1;">
                                            ${(O=i.mssqlAnalysis)!=null&&O.performance?"✅ Analyzed":"📊 Ready"}
                                        </p>
                                    </div>
                                `:""}
                            </div>
                            <div style="background: rgba(114, 46, 209, 0.1); padding: 12px; border-radius: 6px;">
                                <p style="margin: 0; font-size: 14px; color: #722ed1;"><strong>🗄️ MSSQL Data:</strong> Connection patterns and performance metrics analyzed</p>
                            </div>
                        </div>
                    </div>
                `:""}

                ${(ve=n.sections.postgresAnalysis)!=null&&ve.enabled?`
                    <div style="margin-bottom: 50px; padding: 25px; background: white; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); border-left: 5px solid #1890ff;">
                        <div style="display: flex; align-items: center; margin-bottom: 20px;">
                            <div style="background: #1890ff; color: white; width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-right: 15px; font-size: 18px;">
                                🐘
                            </div>
                            <h2 style="color: #1890ff; font-size: 24px; margin: 0; font-weight: 600;">
                                PostgreSQL Analysis
                            </h2>
                        </div>
                        <p style="margin-bottom: 20px; color: #666; font-size: 16px;">
                            ${n.sections.postgresAnalysis.includeBloat?"Bloat analysis, ":""}
                            ${n.sections.postgresAnalysis.includeSlowQueries?"Slow queries, ":""}
                            ${n.sections.postgresAnalysis.includeConnections?"Connections ":""}
                            analysis for PostgreSQL clusters
                        </p>
                        <div style="background: linear-gradient(135deg, #e6f7ff 0%, #f0f9ff 100%); padding: 20px; border-radius: 8px; border: 1px solid #91d5ff;">
                            <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 15px; margin-bottom: 15px;">
                                ${n.sections.postgresAnalysis.includeBloat?`
                                    <div style="background: white; padding: 15px; border-radius: 6px; text-align: center;">
                                        <p style="margin: 0; color: #666; font-size: 14px;">Table/Index Bloat</p>
                                        <p style="margin: 5px 0 0 0; font-size: 16px; font-weight: bold; color: #1890ff;">
                                            ${($e=i.postgresAnalysis)!=null&&$e.bloat?"✅ Analyzed":"📊 Ready"}
                                        </p>
                                    </div>
                                `:""}
                                ${n.sections.postgresAnalysis.includeSlowQueries?`
                                    <div style="background: white; padding: 15px; border-radius: 6px; text-align: center;">
                                        <p style="margin: 0; color: #666; font-size: 14px;">Slow Queries</p>
                                        <p style="margin: 5px 0 0 0; font-size: 16px; font-weight: bold; color: #1890ff;">
                                            ${(se=i.postgresAnalysis)!=null&&se.slowQueries?"✅ Analyzed":"📊 Ready"}
                                        </p>
                                    </div>
                                `:""}
                                ${n.sections.postgresAnalysis.includeConnections?`
                                    <div style="background: white; padding: 15px; border-radius: 6px; text-align: center;">
                                        <p style="margin: 0; color: #666; font-size: 14px;">Connections</p>
                                        <p style="margin: 5px 0 0 0; font-size: 16px; font-weight: bold; color: #1890ff;">
                                            ${(xe=i.postgresAnalysis)!=null&&xe.connections?"✅ Analyzed":"📊 Ready"}
                                        </p>
                                    </div>
                                `:""}
                            </div>
                            <div style="background: rgba(24, 144, 255, 0.1); padding: 12px; border-radius: 6px;">
                                <p style="margin: 0; font-size: 14px; color: #1890ff;"><strong>🐘 PostgreSQL Data:</strong> Performance and optimization insights collected</p>
                            </div>
                        </div>
                    </div>
                `:""}

                ${n.sections.alarmsAnalysis?`
                    <div style="margin-bottom: 50px; padding: 25px; background: white; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); border-left: 5px solid #ff4d4f;">
                        <div style="display: flex; align-items: center; margin-bottom: 20px;">
                            <div style="background: #ff4d4f; color: white; width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-right: 15px; font-size: 18px;">
                                🚨
                            </div>
                            <h2 style="color: #ff4d4f; font-size: 24px; margin: 0; font-weight: 600;">
                                Alarms & Monitoring
                            </h2>
                        </div>
                        <p style="margin-bottom: 20px; color: #666; font-size: 16px;">
                            Alarm statistics, trends, and critical events for the selected time period
                        </p>
                        <div style="background: linear-gradient(135deg, #fff1f0 0%, #ffebe6 100%); padding: 20px; border-radius: 8px; border: 1px solid #ffb3b3;">
                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 15px;">
                                <div style="background: white; padding: 15px; border-radius: 6px; text-align: center;">
                                    <p style="margin: 0; color: #666; font-size: 14px;">Total Alarms</p>
                                    <p style="margin: 5px 0 0 0; font-size: 20px; font-weight: bold; color: #ff4d4f;">
                                        ${i.alarmsData?Object.keys(i.alarmsData).length:0}
                                    </p>
                                </div>
                                <div style="background: white; padding: 15px; border-radius: 6px; text-align: center;">
                                    <p style="margin: 0; color: #666; font-size: 14px;">Critical Events</p>
                                    <p style="margin: 5px 0 0 0; font-size: 20px; font-weight: bold; color: #ff4d4f;">
                                        ${i.alarmsData?"📊 Tracked":"⏳ Pending"}
                                    </p>
                                </div>
                            </div>
                            <div style="background: rgba(255, 77, 79, 0.1); padding: 12px; border-radius: 6px;">
                                <p style="margin: 0; font-size: 14px; color: #ff4d4f;"><strong>🚨 Monitoring Data:</strong> Alarm patterns and severity trends analyzed</p>
                            </div>
                            
                            ${S}
                        </div>
                    </div>
                `:""}

                ${n.sections.recommendations?`
                    <div style="margin-bottom: 50px; padding: 25px; background: white; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); border-left: 5px solid #722ed1;">
                        <div style="display: flex; align-items: center; margin-bottom: 20px;">
                            <div style="background: #722ed1; color: white; width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-right: 15px; font-size: 18px;">
                                📈
                            </div>
                            <h2 style="color: #722ed1; font-size: 24px; margin: 0; font-weight: 600;">
                                Capacity Planning & Recommendations
                            </h2>
                        </div>
                        <p style="margin-bottom: 20px; color: #666; font-size: 16px;">
                            Resource utilization trends, growth projections, and optimization recommendations
                        </p>
                        <div style="background: linear-gradient(135deg, #f9f0ff 0%, #f0e6ff 100%); padding: 20px; border-radius: 8px; border: 1px solid #d3adf7;">
                            <div style="display: grid; grid-template-columns: 1fr 1fr 1fr 1fr 1fr; gap: 12px; margin-bottom: 15px;">
                                <div style="background: white; padding: 12px; border-radius: 6px; text-align: center;">
                                    <p style="margin: 0; color: #666; font-size: 12px;">Disk Growth</p>
                                    <p style="margin: 3px 0 0 0; font-size: 14px; font-weight: bold; color: #722ed1;">
                                        ${(X=i.capacityPlanning)!=null&&X.diskTrends?`${i.capacityPlanning.diskTrends.length} trends`:"❌ No Data"}
                                    </p>
                                </div>
                                <div style="background: white; padding: 12px; border-radius: 6px; text-align: center;">
                                    <p style="margin: 0; color: #666; font-size: 12px;">Memory</p>
                                    <p style="margin: 3px 0 0 0; font-size: 14px; font-weight: bold; color: #722ed1;">
                                        ${(we=i.capacityPlanning)!=null&&we.memoryTrends?`${i.capacityPlanning.memoryTrends.length} trends`:"❌ No Data"}
                                    </p>
                                </div>
                                <div style="background: white; padding: 12px; border-radius: 6px; text-align: center;">
                                    <p style="margin: 0; color: #666; font-size: 12px;">CPU</p>
                                    <p style="margin: 3px 0 0 0; font-size: 14px; font-weight: bold; color: #722ed1;">
                                        ${(ne=i.capacityPlanning)!=null&&ne.cpuTrends?`${i.capacityPlanning.cpuTrends.length} trends`:"❌ No Data"}
                                    </p>
                                </div>
                                <div style="background: white; padding: 12px; border-radius: 6px; text-align: center;">
                                    <p style="margin: 0; color: #666; font-size: 12px;">Connections</p>
                                    <p style="margin: 3px 0 0 0; font-size: 14px; font-weight: bold; color: #722ed1;">
                                        ${(re=i.capacityPlanning)!=null&&re.connectionTrends?"📊":"⏳"}
                                    </p>
                                </div>
                                <div style="background: white; padding: 12px; border-radius: 6px; text-align: center;">
                                    <p style="margin: 0; color: #666; font-size: 12px;">DB Size</p>
                                    <p style="margin: 3px 0 0 0; font-size: 14px; font-weight: bold; color: #722ed1;">
                                        ${(ae=i.capacityPlanning)!=null&&ae.databaseSizeTrends?"📊":"⏳"}
                                    </p>
                                </div>
                            </div>
                            <div style="background: rgba(114, 46, 209, 0.1); padding: 12px; border-radius: 6px;">
                                <p style="margin: 0; font-size: 14px; color: #722ed1;"><strong>📈 Forecasting:</strong> Trend analysis and capacity recommendations generated</p>
                            </div>
                            
                            ${i.capacityPlanning?`
                                <div style="margin-top: 20px; padding: 15px; background: white; border-radius: 6px; border: 1px solid #d9d9d9;">
                                    <h4 style="margin: 0 0 15px 0; color: #333;">Capacity Planning Metrics</h4>
                                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                                        ${i.capacityPlanning.diskTrends?`
                                            <div style="padding: 10px; background: #f8f8f8; border-radius: 4px;">
                                                <strong>💾 Disk Trends:</strong> ${i.capacityPlanning.diskTrends.length} data points
                                                ${i.capacityPlanning.diskTrends.slice(0,3).map(p=>{var v,$;return`
                                                    <div style="font-size: 11px; margin-top: 4px; color: #666;">
                                                        ${(v=p.agent_id)==null?void 0:v.replace("agent_","")}: ${($=p._field)!=null&&$.includes("disk")?Math.round((p._value||0)/1024/1024/1024*100)/100+" GB":Math.round(p._value||0)+"%"}
                                                    </div>
                                                `}).join("")}
                                            </div>
                                        `:""}
                                        ${i.capacityPlanning.cpuTrends?`
                                            <div style="padding: 10px; background: #f8f8f8; border-radius: 4px;">
                                                <strong>⚡ CPU Trends:</strong> ${i.capacityPlanning.cpuTrends.length} data points
                                                ${i.capacityPlanning.cpuTrends.slice(0,3).map(p=>{var v;return`
                                                    <div style="font-size: 11px; margin-top: 4px; color: #666;">
                                                        ${(v=p.agent_id)==null?void 0:v.replace("agent_","")}: ${Math.round(p._value||0)}%
                                                    </div>
                                                `}).join("")}
                                            </div>
                                        `:""}
                                        ${i.capacityPlanning.connectionTrends?`
                                            <div style="padding: 10px; background: #f8f8f8; border-radius: 4px;">
                                                <strong>🔗 Connection Analysis:</strong> ${i.capacityPlanning.connectionTrends.length} data points
                                                <div style="margin-top: 8px;">
                                                    ${(()=>{var R,d,u,j,f,x,D;const p=i.capacityPlanning.connectionTrends.filter(g=>g._field==="available"),v=i.capacityPlanning.connectionTrends.filter(g=>g._field==="total"),$=i.capacityPlanning.connectionTrends.filter(g=>g._field==="max_connections");return`
                                                            <div style="font-size: 11px; line-height: 1.4;">
                                                                ${p.length>0?`<div>📊 Available: ${Math.round(((R=p.slice(-1)[0])==null?void 0:R._value)||0)}</div>`:""}
                                                                ${v.length>0?`<div>🔢 Current: ${Math.round(((d=v.slice(-1)[0])==null?void 0:d._value)||0)}</div>`:""}
                                                                ${$.length>0?`<div>🏁 Max: ${Math.round(((u=$.slice(-1)[0])==null?void 0:u._value)||0)}</div>`:""}
                                                                ${v.length>0&&$.length>0?`<div style="color: ${((j=v.slice(-1)[0])==null?void 0:j._value)/((f=$.slice(-1)[0])==null?void 0:f._value)>.8?"#ff4d4f":"#52c41a"};">📈 Usage: ${Math.round(((x=v.slice(-1)[0])==null?void 0:x._value)/((D=$.slice(-1)[0])==null?void 0:D._value)*100)}%</div>`:""}
                                                            </div>
                                                        `})()}
                                                </div>
                                            </div>
                                        `:""}
                                    </div>
                                </div>
                            `:""}
                        </div>
                    </div>
                `:""}
            </div>
        `;a.innerHTML=Y,document.body.appendChild(a),await new Promise(p=>setTimeout(p,1e3));try{const p=new et("p","pt","a4"),v=await tt(a,{scale:1.5,useCORS:!0,backgroundColor:"#ffffff",windowWidth:800}),$=v.toDataURL("image/jpeg",1),R=p.internal.pageSize.getWidth(),d=p.internal.pageSize.getHeight(),u=v.width,j=v.height,f=R/u;let x=j*f,D=0,g=1;for(p.addImage($,"JPEG",0,D,R,j*f);x>=d;)D=-d*g,p.addPage(),p.addImage($,"JPEG",0,D,R,j*f),x-=d,g++;p.save(`comprehensive-report-${F().format("YYYY-MM-DD-HH-mm")}.pdf`)}finally{document.body.removeChild(a)}},ut=(i,n)=>{var H;const a=[],y=F().format("YYYY-MM-DD HH:mm:ss"),m=(n.clusters||[]).map(_=>_.replace("agent_","")).join(", ");a.push(["ClusterEye Comprehensive Report"]),a.push(["Generated",y]),a.push(["Nodes",m]),a.push(["Time Range",n.timeRange.type==="relative"?`Last ${n.timeRange.relative}`:`${F(n.timeRange.absolute.startDate).format("YYYY-MM-DD HH:mm")} to ${F(n.timeRange.absolute.endDate).format("YYYY-MM-DD HH:mm")}`]),a.push([]),n.sections.systemMetrics&&i.systemMetrics&&(a.push(["System Performance Metrics"]),a.push(["Metric Type","Value","Timestamp"]),Object.entries(i.systemMetrics).forEach(([_,z])=>{Array.isArray(z)&&z.forEach(N=>{a.push([_,N.value||"",N.timestamp||""])})}),a.push([])),n.sections.diskAnalysis&&i.diskAnalysis&&(a.push(["Disk Analysis"]),a.push(["Filesystem","Mount Point","Used %","Total GB","Timestamp"]),Object.entries(i.diskAnalysis).forEach(([_,z])=>{Array.isArray(z)&&z.forEach(N=>{a.push([N.filesystem||"",N.mount_point||"",N.used_percent||"",N.total_gb||"",N.timestamp||""])})}),a.push([])),(H=n.sections.mongoAnalysis)!=null&&H.enabled&&i.mongoAnalysis&&(a.push(["MongoDB Analysis"]),i.mongoAnalysis.collections&&(a.push(["Collections","Document Count","Size MB"]),i.mongoAnalysis.collections.forEach(_=>{a.push([_.name||"",_.count||"",_.size||""])}),a.push([])),i.mongoAnalysis.indexes&&(a.push(["Indexes","Size MB","Usage"]),i.mongoAnalysis.indexes.forEach(_=>{a.push([_.name||"",_.size||"",_.accesses||""])}),a.push([]))),n.sections.alarmsAnalysis&&i.alarmsData&&(a.push(["Alarms Analysis"]),a.push(["Alarm Type","Count","Severity"]),Object.entries(i.alarmsData).forEach(([_,z])=>{a.push([_,z.count||"",z.severity||""])}),a.push([]));const S=a.map(_=>_.map(z=>`"${(z||"").toString().replace(/"/g,'""')}"`).join(",")).join(`
`),Y=new Blob([S],{type:"text/csv;charset=utf-8;"}),P=document.createElement("a"),I=URL.createObjectURL(Y);P.setAttribute("href",I),P.setAttribute("download",`comprehensive-report-${F().format("YYYY-MM-DD-HH-mm")}.csv`),P.style.visibility="hidden",document.body.appendChild(P),P.click(),document.body.removeChild(P)},ft=async(i,n)=>{var a;try{const y=await Be(()=>import("./xlsx-fc9dd0d2.js"),[]),m=y.utils.book_new(),S=(n.clusters||[]).map(I=>I.replace("agent_","")).join(", "),Y=[["ClusterEye Comprehensive Report"],["Generated",F().format("YYYY-MM-DD HH:mm:ss")],["Nodes",S],["Time Range",n.timeRange.type==="relative"?`Last ${n.timeRange.relative}`:`${F(n.timeRange.absolute.startDate).format("YYYY-MM-DD HH:mm")} to ${F(n.timeRange.absolute.endDate).format("YYYY-MM-DD HH:mm")}`]],P=y.utils.aoa_to_sheet(Y);if(y.utils.book_append_sheet(m,P,"Summary"),n.sections.systemMetrics&&i.systemMetrics){const I=[["Metric Type","Value","Timestamp"]];Object.entries(i.systemMetrics).forEach(([_,z])=>{Array.isArray(z)&&z.forEach(N=>{I.push([_,N.value||"",N.timestamp||""])})});const H=y.utils.aoa_to_sheet(I);y.utils.book_append_sheet(m,H,"System Metrics")}if(n.sections.diskAnalysis&&i.diskAnalysis){const I=[["Filesystem","Mount Point","Used %","Total GB","Timestamp"]];Object.entries(i.diskAnalysis).forEach(([_,z])=>{Array.isArray(z)&&z.forEach(N=>{I.push([N.filesystem||"",N.mount_point||"",N.used_percent||"",N.total_gb||"",N.timestamp||""])})});const H=y.utils.aoa_to_sheet(I);y.utils.book_append_sheet(m,H,"Disk Analysis")}if((a=n.sections.mongoAnalysis)!=null&&a.enabled&&i.mongoAnalysis){if(i.mongoAnalysis.collections){const I=[["Collection Name","Document Count","Size MB"]];i.mongoAnalysis.collections.forEach(_=>{I.push([_.name||"",_.count||"",_.size||""])});const H=y.utils.aoa_to_sheet(I);y.utils.book_append_sheet(m,H,"MongoDB Collections")}if(i.mongoAnalysis.indexes){const I=[["Index Name","Size MB","Usage Count"]];i.mongoAnalysis.indexes.forEach(_=>{I.push([_.name||"",_.size||"",_.accesses||""])});const H=y.utils.aoa_to_sheet(I);y.utils.book_append_sheet(m,H,"MongoDB Indexes")}}if(n.sections.alarmsAnalysis&&i.alarmsData){const I=[["Alarm Type","Count","Severity"]];Object.entries(i.alarmsData).forEach(([_,z])=>{I.push([_,z.count||"",z.severity||""])});const H=y.utils.aoa_to_sheet(I);y.utils.book_append_sheet(m,H,"Alarms Analysis")}y.writeFile(m,`comprehensive-report-${F().format("YYYY-MM-DD-HH-mm")}.xlsx`)}catch{B.error("Excel export failed. Please try CSV export instead.")}},yt=[{title:"Name",dataIndex:"name",key:"name",width:200},{title:"Description",dataIndex:"description",key:"description",width:300},{title:"Schedule",key:"schedule",width:200,render:(i,n)=>o.jsxs(Re,{children:[o.jsx(fe,{children:n.schedule.frequency}),o.jsx("span",{children:n.schedule.time})]})},{title:"Delivery",key:"delivery",width:200,render:(i,n)=>o.jsxs(Re,{children:[o.jsx(fe,{children:n.delivery.type}),o.jsx("span",{children:n.delivery.destination})]})},{title:"Status",key:"status",width:100,render:(i,n)=>o.jsx(fe,{color:n.status==="active"?"green":"orange",children:n.status})},{title:"Last Generated",dataIndex:"lastGenerated",key:"lastGenerated",width:200,render:i=>i?F(i).format("YYYY-MM-DD HH:mm:ss"):"-"},{title:"Actions",key:"actions",width:200,render:(i,n)=>o.jsxs(Re,{children:[o.jsx(Ne,{title:n.status==="active"?"Pause":"Activate",children:o.jsx(le,{type:"text",icon:n.status==="active"?o.jsx(jt,{}):o.jsx(_t,{}),onClick:()=>je(n)})}),o.jsx(Ne,{title:"Edit",children:o.jsx(le,{type:"text",icon:o.jsx(Pt,{}),onClick:()=>He(n)})}),o.jsx(Ne,{title:"Delete",children:o.jsx(le,{type:"text",danger:!0,icon:o.jsx(Rt,{}),onClick:()=>Q(n.id)})})]})}],ht=[{title:"Report Name",key:"reportName",width:200,render:(i,n)=>{const a=t.find(y=>y.id===n.reportId);return(a==null?void 0:a.name)||"Unknown"}},{title:"Generated At",dataIndex:"generatedAt",key:"generatedAt",width:200,render:i=>F(i).format("YYYY-MM-DD HH:mm:ss")},{title:"Status",dataIndex:"status",key:"status",width:100,render:i=>o.jsx(fe,{color:i==="success"?"green":"red",children:i})},{title:"Actions",key:"actions",width:100,render:(i,n)=>n.fileUrl&&o.jsx(Ne,{title:"Download PDF",children:o.jsx(le,{type:"text",icon:o.jsx(Qe,{}),onClick:()=>Me(n.fileUrl)})})}];return o.jsxs("div",{style:{padding:"24px"},children:[o.jsx(wt,{children:o.jsxs(dt,{defaultActiveKey:"reports",children:[o.jsxs(at,{tab:"Scheduled Reports",children:[o.jsxs("div",{style:{marginBottom:16,display:"flex",gap:"8px"},children:[o.jsx(le,{type:"primary",icon:o.jsx(kt,{}),onClick:Fe,children:"Create Report"}),o.jsx(le,{type:"default",icon:o.jsx(Qe,{}),onClick:We,children:"Test Report"}),o.jsx(le,{type:"primary",icon:o.jsx(Qe,{}),onClick:gt,style:{backgroundColor:"#52c41a",borderColor:"#52c41a"},children:"Comprehensive Report"}),oe&&me&&o.jsx(At,{menu:{items:[{key:"csv",icon:o.jsx(St,{}),label:"Export as CSV",onClick:()=>ut(oe,me)},{key:"excel",icon:o.jsx(zt,{}),label:"Export as Excel",onClick:()=>ft(oe,me)}]},trigger:["click"],children:o.jsx(le,{icon:o.jsx(Ct,{}),children:"Export Data"})})]}),o.jsx(Je,{columns:yt,dataSource:t||[],rowKey:"id",pagination:{pageSize:10}})]},"reports"),o.jsx(at,{tab:"Report History",children:o.jsx(Je,{columns:ht,dataSource:r||[],rowKey:"id",pagination:{pageSize:10}})},"history")]})}),o.jsx(Ke,{title:T?"Edit Report":"Create Report",open:b,onOk:Ye,onCancel:()=>h(!1),width:800,children:o.jsxs(M,{form:k,layout:"vertical",initialValues:{schedule:{frequency:"daily"},delivery:{type:"email"},content:{type:"alarms"},status:"active"},children:[o.jsx(M.Item,{name:"name",label:"Report Name",rules:[{required:!0}],children:o.jsx(Ge,{})}),o.jsx(M.Item,{name:"description",label:"Description",rules:[{required:!0}],children:o.jsx(Ge.TextArea,{})}),o.jsx(M.Item,{name:["schedule","frequency"],label:"Frequency",rules:[{required:!0}],children:o.jsxs(ce,{children:[o.jsx(W,{value:"daily",children:"Daily"}),o.jsx(W,{value:"weekly",children:"Weekly"}),o.jsx(W,{value:"monthly",children:"Monthly"})]})}),o.jsx(M.Item,{name:"time",label:"Time",rules:[{required:!0}],children:o.jsx(Mt,{format:"HH:mm"})}),o.jsx(M.Item,{name:["delivery","type"],label:"Delivery Method",rules:[{required:!0}],children:o.jsxs(ce,{children:[o.jsx(W,{value:"email",children:"Email"}),o.jsx(W,{value:"slack",children:"Slack"})]})}),o.jsx(M.Item,{name:["delivery","destination"],label:"Destination",rules:[{required:!0}],children:o.jsx(Ge,{placeholder:"Email address or Slack channel"})}),o.jsx(M.Item,{name:["content","type"],label:"Report Content",rules:[{required:!0}],children:o.jsx(ce,{children:o.jsx(W,{value:"general_health",children:"General Health"})})})]})}),o.jsx(Ke,{title:"Generate Comprehensive Report",open:w,onOk:mt,onCancel:()=>l(!1),width:900,confirmLoading:ye,children:o.jsxs(M,{form:A,layout:"vertical",initialValues:{timeRange:{type:"relative",relative:"1d"},sections:{systemMetrics:!0,diskAnalysis:!0,alarmsAnalysis:!0}},children:[o.jsxs(Pe,{gutter:16,children:[o.jsx(ue,{span:12,children:o.jsx(M.Item,{name:"clusters",label:"Select Clusters",rules:[{required:!0,message:"Please select at least one cluster"}],children:o.jsx(ce,{mode:"multiple",placeholder:"Select clusters to include in report",optionFilterProp:"children",onChange:i=>{Le(i);const n=i.flatMap(a=>{const y=q.find(m=>m.id===a);return y?y.nodeList.map(m=>({id:m.agentID,name:m.hostname,clusterId:a,clusterName:y.name,type:y.type,role:m.isPrimary?"PRIMARY":m.role||"SECONDARY",status:m.status})):[]});Ce(n)},children:q.map(i=>o.jsxs(W,{value:i.id,children:[o.jsx(fe,{color:i.type==="MongoDB"?"green":i.type==="PostgreSQL"?"blue":"orange",children:i.type}),i.name," (",i.nodes," nodes)"]},i.id))})})}),o.jsx(ue,{span:12,children:o.jsx(M.Item,{name:"nodes",label:"Select Nodes",rules:[{required:!0,message:"Please select at least one node"}],children:o.jsx(ce,{mode:"multiple",placeholder:"Select nodes to include in report",optionFilterProp:"children",disabled:pe.length===0,children:ze.map(i=>o.jsx(W,{value:i.id,children:o.jsxs(Re,{children:[o.jsx(fe,{color:i.type==="MongoDB"?"green":i.type==="PostgreSQL"?"blue":"orange",children:i.type}),o.jsx(fe,{color:i.role==="PRIMARY"||i.role==="Leader"?"blue":"default",children:i.role}),o.jsx("span",{children:i.name}),o.jsxs("span",{style:{color:"var(--text-secondary)"},children:["(",i.clusterName,")"]})]})},i.id))})})})]}),o.jsx(Pe,{gutter:16,children:o.jsx(ue,{span:12,children:o.jsx(M.Item,{name:["timeRange","type"],label:"Time Range Type",children:o.jsxs(ce,{children:[o.jsx(W,{value:"relative",children:"Relative"}),o.jsx(W,{value:"absolute",children:"Absolute"})]})})})}),o.jsx(M.Item,{noStyle:!0,shouldUpdate:(i,n)=>{var a,y;return((a=i.timeRange)==null?void 0:a.type)!==((y=n.timeRange)==null?void 0:y.type)},children:({getFieldValue:i})=>i(["timeRange","type"])==="relative"?o.jsx(M.Item,{name:["timeRange","relative"],label:"Time Period",children:o.jsxs(ce,{children:[o.jsx(W,{value:"1h",children:"Last 1 Hour"}),o.jsx(W,{value:"1d",children:"Last 1 Day"}),o.jsx(W,{value:"7d",children:"Last 7 Days"}),o.jsx(W,{value:"30d",children:"Last 30 Days"})]})}):o.jsxs(Pe,{gutter:16,children:[o.jsx(ue,{span:12,children:o.jsx(M.Item,{name:["timeRange","absolute","startDate"],label:"Start Date",children:o.jsx(Xe,{showTime:!0,style:{width:"100%"}})})}),o.jsx(ue,{span:12,children:o.jsx(M.Item,{name:["timeRange","absolute","endDate"],label:"End Date",children:o.jsx(Xe,{showTime:!0,style:{width:"100%"}})})})]})}),o.jsx(Ze,{children:"Report Format"}),o.jsx(M.Item,{name:"reportVersion",label:"Report Version",initialValue:"v2",children:o.jsxs(Oe.Group,{children:[o.jsx(Oe.Button,{value:"v2",children:"V2 — Intelligence Report"}),o.jsx(Oe.Button,{value:"v1",children:"V1 — Classic Report"})]})}),o.jsx(Ze,{children:"Report Sections"}),o.jsxs(Pe,{gutter:16,children:[o.jsxs(ue,{span:12,children:[o.jsx(M.Item,{name:["sections","systemMetrics"],valuePropName:"checked",children:o.jsx(V,{children:"System Performance Metrics"})}),o.jsx(M.Item,{name:["sections","diskAnalysis"],valuePropName:"checked",children:o.jsx(V,{children:"Disk Analysis & Trends"})}),o.jsx(M.Item,{name:["sections","alarmsAnalysis"],valuePropName:"checked",children:o.jsx(V,{children:"Alarms Analysis"})}),o.jsx(M.Item,{name:["sections","recommendations"],valuePropName:"checked",children:o.jsx(V,{children:"Capacity Planning & Recommendations"})})]}),o.jsxs(ue,{span:12,children:[o.jsx(M.Item,{name:["sections","mongoAnalysis","enabled"],valuePropName:"checked",children:o.jsx(V,{children:"MongoDB Analysis"})}),o.jsx(M.Item,{name:["sections","postgresAnalysis","enabled"],valuePropName:"checked",children:o.jsx(V,{children:"PostgreSQL Analysis"})}),o.jsx(M.Item,{name:["sections","mssqlAnalysis","enabled"],valuePropName:"checked",children:o.jsx(V,{children:"MSSQL Analysis"})})]})]}),o.jsx(M.Item,{noStyle:!0,shouldUpdate:(i,n)=>{var a,y,m,S;return((y=(a=i.sections)==null?void 0:a.mongoAnalysis)==null?void 0:y.enabled)!==((S=(m=n.sections)==null?void 0:m.mongoAnalysis)==null?void 0:S.enabled)},children:({getFieldValue:i})=>i(["sections","mongoAnalysis","enabled"])?o.jsxs("div",{style:{marginLeft:24,marginBottom:16},children:[o.jsx("p",{style:{marginBottom:8,fontWeight:"bold"},children:"MongoDB Analysis Options:"}),o.jsx(M.Item,{name:["sections","mongoAnalysis","includeCollections"],valuePropName:"checked",children:o.jsx(V,{children:"Include Collections Analysis"})}),o.jsx(M.Item,{name:["sections","mongoAnalysis","includeIndexes"],valuePropName:"checked",children:o.jsx(V,{children:"Include Index Analysis"})}),o.jsx(M.Item,{name:["sections","mongoAnalysis","includePerformance"],valuePropName:"checked",children:o.jsx(V,{children:"Include Performance Metrics"})})]}):null}),o.jsx(M.Item,{noStyle:!0,shouldUpdate:(i,n)=>{var a,y,m,S;return((y=(a=i.sections)==null?void 0:a.postgresAnalysis)==null?void 0:y.enabled)!==((S=(m=n.sections)==null?void 0:m.postgresAnalysis)==null?void 0:S.enabled)},children:({getFieldValue:i})=>i(["sections","postgresAnalysis","enabled"])?o.jsxs("div",{style:{marginLeft:24,marginBottom:16},children:[o.jsx("p",{style:{marginBottom:8,fontWeight:"bold"},children:"PostgreSQL Analysis Options:"}),o.jsx(M.Item,{name:["sections","postgresAnalysis","includeBloat"],valuePropName:"checked",children:o.jsx(V,{children:"Include Bloat Analysis"})}),o.jsx(M.Item,{name:["sections","postgresAnalysis","includeSlowQueries"],valuePropName:"checked",children:o.jsx(V,{children:"Include Slow Queries"})}),o.jsx(M.Item,{name:["sections","postgresAnalysis","includeConnections"],valuePropName:"checked",children:o.jsx(V,{children:"Include Connection Statistics"})})]}):null}),o.jsx(M.Item,{noStyle:!0,shouldUpdate:(i,n)=>{var a,y,m,S;return((y=(a=i.sections)==null?void 0:a.mssqlAnalysis)==null?void 0:y.enabled)!==((S=(m=n.sections)==null?void 0:m.mssqlAnalysis)==null?void 0:S.enabled)},children:({getFieldValue:i})=>i(["sections","mssqlAnalysis","enabled"])?o.jsxs("div",{style:{marginLeft:24,marginBottom:16},children:[o.jsx("p",{style:{marginBottom:8,fontWeight:"bold"},children:"MSSQL Analysis Options:"}),o.jsx(M.Item,{name:["sections","mssqlAnalysis","includeCapacityPlanning"],valuePropName:"checked",children:o.jsx(V,{children:"Include Capacity Planning"})}),o.jsx(M.Item,{name:["sections","mssqlAnalysis","includePerformance"],valuePropName:"checked",children:o.jsx(V,{children:"Include Performance Analysis"})})]}):null})]})})]})};export{bi as default};
