import{b6 as a,a as t,a1 as n}from"./index-0857d1db.js";function r(){const{flags:e}=a(),{can:s}=t();return!!e.context_graph_enabled&&s(n.contextView)}export{r as u};
