const e=new Set(["redis","elasticsearch","azuresql"]),n=s=>e.has(s);export{n as i};
