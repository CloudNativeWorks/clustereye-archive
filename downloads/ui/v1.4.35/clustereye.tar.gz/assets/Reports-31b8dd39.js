import{g as X,s as ht,_ as He}from"./index-ceb857ff.js";import{r as K,aw as z,as as B,j as o,av as bt,b4 as nt,B as le,be as vt,br as Ye,a9 as $t,bj as wt,bZ as kt,bI as At,aO as Ve,ak as qe,I as Be,S as pe,bC as St,aT as _e,aU as ue,T as ye,m as Pe,bd as We,aR as Je,b2 as Qe,b5 as V,b as Re,b_ as zt,P as Ct,bf as jt,bh as Mt}from"./vendor-core-b32aba80.js";import{f as ee,d as F}from"./vendor-utils-c44f47c4.js";import{d as Oe}from"./doctorService-d0083143.js";import{c as _t}from"./healthScoreUtils-391a273c.js";import Ke from"./jspdf.es.min-f37510e7.js";import Ze from"./html2canvas.esm-71958c39.js";const te=X();class Pt{getAuthToken(){return localStorage.getItem("token")}getAuthHeaders(){return{CEFE:"Yes",Authorization:`Bearer ${this.getAuthToken()}`,"Content-Type":"application/json"}}async fetchAnomalies(e){const r=new URLSearchParams;e.agent_id&&r.append("agent_id",e.agent_id),e.database_type&&r.append("database_type",e.database_type),e.severity&&r.append("severity",e.severity),e.is_active!==void 0&&r.append("is_active",String(e.is_active)),e.limit&&r.append("limit",String(e.limit)),e.offset&&r.append("offset",String(e.offset));const f=await ee.get(`${te}/api/v1/anomalies?${r.toString()}`,{headers:this.getAuthHeaders()});return{anomalies:f.data.anomalies||[],total:f.data.total||0}}async fetchAnomalyStats(e){const r=new URLSearchParams;return e.agent_id&&r.append("agent_id",e.agent_id),e.database_type&&r.append("database_type",e.database_type),(await ee.get(`${te}/api/v1/anomalies/stats?${r.toString()}`,{headers:this.getAuthHeaders()})).data}async resolveAnomaly(e){await ee.post(`${te}/api/v1/anomalies/${e}/resolve`,{},{headers:this.getAuthHeaders()})}async fetchAlarmConfigs(e){const r=new URLSearchParams;return e!=null&&e.agent_id&&r.append("agent_id",e.agent_id),e!=null&&e.database_type&&r.append("database_type",e.database_type),(await ee.get(`${te}/api/v1/alarm-configs?${r.toString()}`,{headers:this.getAuthHeaders()})).data.configs||[]}async createAlarmConfig(e){return(await ee.post(`${te}/api/v1/alarm-configs`,e,{headers:this.getAuthHeaders()})).data}async updateAlarmConfig(e,r){await ee.put(`${te}/api/v1/alarm-configs/${e}`,r,{headers:this.getAuthHeaders()})}async deleteAlarmConfig(e){await ee.delete(`${te}/api/v1/alarm-configs/${e}`,{headers:this.getAuthHeaders()})}async fetchAlarmHistory(e){const r=new URLSearchParams;e!=null&&e.anomaly_id&&r.append("anomaly_id",String(e.anomaly_id)),e!=null&&e.status&&r.append("status",e.status),e!=null&&e.limit&&r.append("limit",String(e.limit)),e!=null&&e.offset&&r.append("offset",String(e.offset));const f=await ee.get(`${te}/api/v1/alarms-history?${r.toString()}`,{headers:this.getAuthHeaders()});return{alarms:f.data.alarms||[],total:f.data.total||0}}async comparePlans(e,r){return(await ee.get(`${te}/api/v1/plans/compare?from_plan_id=${e}&to_plan_id=${r}`,{headers:this.getAuthHeaders()})).data}}const Xe=new Pt;function Ge(t){const r={critical:40,high:25,medium:15}[t.severity]??10,f=Math.min(20,t.occurrenceCount*2),w=Math.min(20,(t.deviationPct??0)/10),h=Math.min(10,t.affectedNodeCount*5),$=t.isRecurring?10:0;return Math.min(100,r+f+w+h+$)}function et(t,e){return isNaN(t)||isNaN(e)?"unavailable":t===0&&e===0?"suspect":"valid"}function Rt(t){return t==="critical"?"critical":t==="high"?"high":"medium"}function rt(t){return typeof t=="number"?t>=80?"high":t>=50?"medium":"low":t==="high"?"high":t==="medium"?"medium":"low"}function Nt(t){return t==="minimal"||t==="low"?"5m":t==="medium"?"30m":t==="high"?"1h":"30m"}function at(t,e){const r=(t+" "+(e||"")).toLowerCase();return r.includes("query")||r.includes("duration")||r.includes("slow")?"latency":r.includes("replication")||r.includes("lag")||r.includes("failover")?"availability":r.includes("cpu")||r.includes("memory")||r.includes("disk")?"resource":r.includes("alarm")||r.includes("alert")||r.includes("noise")?"operational_noise":"stability"}function Dt(t){return t.filter(e=>e.severity==="critical"||e.severity==="high"||e.severity==="medium").map(e=>{const r=Rt(e.severity),f=Ge({severity:r,occurrenceCount:1,deviationPct:e.score_impact?Math.abs(e.score_impact)*10:0,affectedNodeCount:1,isRecurring:!1});return{title:e.title,severity:r,affectedNodes:e.object_name?[e.object_name]:[],cause:e.ai_explanation||e.description||"Detected by analysis rules",impactLevel:e.impact==="high"?"high":e.impact==="medium"?"medium":"low",impactType:at(e.title,e.category),recommendedFix:e.recommendation||"Review finding details",confidenceLevel:rt(e.confidence),riskScore:f,source:"doctor"}}).sort((e,r)=>r.riskScore-e.riskScore).slice(0,5)}function Tt(t,e){const r=[],f=new Map;t.forEach(h=>{const $=`${h.metric_name}-${h.database_type}`;f.has($)||f.set($,[]),f.get($).push(h)}),f.forEach((h,$)=>{var D;const l=h.sort((q,ie)=>Math.abs(ie.deviation_pct)-Math.abs(q.deviation_pct))[0],j=[...new Set(h.map(q=>q.agent_id))],_=l.severity==="critical"?"critical":h.length>2?"high":"medium",L=Ge({severity:_,occurrenceCount:h.length,deviationPct:Math.abs(l.deviation_pct),affectedNodeCount:j.length,isRecurring:h.length>1});r.push({title:`${l.metric_name} anomaly on ${l.database_type}`,severity:_,affectedNodes:j,cause:l.primary_cause||`${l.metric_name} deviated ${Math.abs(l.deviation_pct).toFixed(0)}% from baseline`,impactLevel:Math.abs(l.deviation_pct)>100?"high":Math.abs(l.deviation_pct)>50?"medium":"low",impactType:at(l.metric_name),recommendedFix:((D=l.suggested_actions)==null?void 0:D[0])||"Investigate metric deviation",confidenceLevel:rt(l.confidence),riskScore:L,source:"anomaly"})});const w=new Map;return(e||[]).forEach(h=>{const $=h.agent_id||"unknown";w.has($)||w.set($,[]),w.get($).push(h)}),w.forEach((h,$)=>{h.length>=10&&r.push({title:`Alert storm from ${$.replace("agent_","")}`,severity:"medium",affectedNodes:[$],cause:`${h.length} alarms from a single node — possible noise`,impactLevel:"medium",impactType:"operational_noise",recommendedFix:"Review alert thresholds or enable deduplication",confidenceLevel:"medium",riskScore:Ge({severity:"medium",occurrenceCount:h.length,affectedNodeCount:1,isRecurring:!0}),source:"alarm"})}),r.sort((h,$)=>$.riskScore-h.riskScore).slice(0,5)}function Lt(t){return t.filter(e=>e.is_quick_win).map(e=>({title:e.title,description:e.recommendation||e.description||"",effortLevel:Nt(e.effort),expectedImpact:e.impact==="high"?"high":e.impact==="medium"?"medium":"low",source:"doctor"})).slice(0,5)}function It(t){const e=[];return t.forEach(r=>{r.suggested_actions&&r.suggested_actions.length>0&&e.push({title:r.suggested_actions[0],description:`Address ${r.metric_name} anomaly on ${r.database_type}`,effortLevel:"30m",expectedImpact:Math.abs(r.deviation_pct)>50?"high":"medium",source:"anomaly"})}),e.slice(0,5)}function Et(t){const e=t.filter(l=>l.severity==="critical").length,r=t.filter(l=>l.severity==="warning").length,f=new Map;t.forEach(l=>{const j=l.agent_id||"unknown";f.set(j,(f.get(j)||0)+1)});const w=[...f.entries()].filter(([,l])=>l>=10).sort((l,j)=>j[1]-l[1]).map(([l,j])=>({nodeId:l.replace("agent_",""),count:j,suggestion:j>30?"Enable alarm deduplication":"Review alert thresholds"})),h=new Map;t.forEach(l=>{h.set(l.metric_name,(h.get(l.metric_name)||0)+1)});const $=[...h.values()].filter(l=>l>1).reduce((l,j)=>l+j,0);return{totalAlarms:t.length,criticalCount:e,warningCount:r,noisyNodes:w,newVsRecurring:{newCount:t.length-$,recurringCount:$},alertFatigueRisk:t.length>50}}function Ft(t){const e=new Map;t.forEach(w=>{e.has(w.database_type)||e.set(w.database_type,[]),e.get(w.database_type).push(w)});const r=[...e.entries()].map(([w,h])=>{var l;const $=h.sort((j,_)=>Math.abs(_.deviation_pct)-Math.abs(j.deviation_pct));return{dbType:w,count:h.length,topMetric:((l=$[0])==null?void 0:l.metric_name)||"—",changePercent:$[0]?Math.abs($[0].deviation_pct):0}}),f=t.sort((w,h)=>Math.abs(h.deviation_pct)-Math.abs(w.deviation_pct)).slice(0,5).map(w=>{var h;return{metric:w.metric_name,dbType:w.database_type,deviationPct:w.deviation_pct,severity:w.severity,suggestedAction:(h=w.suggested_actions)==null?void 0:h[0]}});return{totalAnomalies:t.length,byDatabase:r,topAnomalies:f}}function Ht(t,e,r,f,w){const h=e>0?(t-e)/e*100:0,$=f>0?(r-f)/f*100:0,l=[],j=[];h>10?l.push({description:"Alarm count increased",changePct:h}):h<-10&&j.push({description:"Alarm count decreased",changePct:h}),$>10?l.push({description:"Anomaly count increased",changePct:$}):$<-10&&j.push({description:"Anomaly count decreased",changePct:$});const _=w.filter(D=>Math.abs(D.deviation_pct)>20).sort((D,q)=>Math.abs(q.deviation_pct)-Math.abs(D.deviation_pct)).slice(0,3).map(D=>({metric:`${D.metric_name} (${D.database_type})`,changePct:D.deviation_pct,direction:D.deviation_pct>0?"up":"down"})),L=[];return l.length>0&&L.push(`Regressions: ${l.map(D=>`${D.description} (${D.changePct>0?"+":""}${D.changePct.toFixed(0)}%)`).join(", ")}.`),j.length>0&&L.push(`Improvements: ${j.map(D=>`${D.description} (${D.changePct.toFixed(0)}%)`).join(", ")}.`),L.length===0&&L.push("No significant changes compared to the previous period."),{topRegressions:l,topImprovements:j,mostChangedMetrics:_,narrative:L.join(" ")}}function Yt(t,e,r,f,w){const h=t.status==="healthy"?"healthy":t.status==="warning"?"degraded":"critical",$=[];if($.push(`System health is ${h} (score: ${t.overall}/100).`),w.topRegressions.length>0&&$.push(w.topRegressions.map(l=>`${l.description} by ${Math.abs(l.changePct).toFixed(0)}%`).join(". ")+"."),f.totalAnomalies>0&&f.byDatabase.length>0){const l=f.byDatabase.sort((j,_)=>_.count-j.count)[0];$.push(`${f.totalAnomalies} anomalies detected, primarily affecting ${l.dbType} (${l.topMetric} +${l.changePercent.toFixed(0)}%).`)}if(e.length>0){const l=e.filter(j=>j.severity==="critical").length;l>0&&$.push(`${l} critical risk${l>1?"s":""} identified, including ${e[0].title}.`)}return r.alertFatigueRisk&&$.push(`Alert fatigue risk detected with ${r.totalAlarms} alarms in this period.`),$.join(" ")}function Bt(t){const e=(t==null?void 0:t.cpuTrends)||[],r=(t==null?void 0:t.memoryTrends)||[],f=e.map(_=>parseFloat(_._value)).filter(_=>!isNaN(_)),w=r.map(_=>parseFloat(_._value)).filter(_=>!isNaN(_)),h=f.length>0?f.reduce((_,L)=>_+L,0)/f.length:0,$=f.length>0?Math.max(...f):0,l=w.length>0?w.reduce((_,L)=>_+L,0)/w.length:0,j=w.length>0?Math.max(...w):0;return{cpu:{avg:h,max:$,dataQuality:et(h,$)},memory:{avg:l,max:j,dataQuality:et(l,j)}}}async function Qt(t,e,r){var Ce,je;const f=F().format("YYYY-MM-DD HH:mm:ss"),w=t.clusters.map(Q=>Q.replace("agent_","")),h=t.timeRange.type==="absolute"?((Ce=t.timeRange.absolute)==null?void 0:Ce.startDate)||f:F().subtract(parseInt(t.timeRange.relative||"24",10),"hour").format("YYYY-MM-DD HH:mm"),$=t.timeRange.type==="absolute"&&((je=t.timeRange.absolute)==null?void 0:je.endDate)||f,l=(e==null?void 0:e.recentAlarms)||[],j=l.filter(Q=>Q.severity==="critical").length,_=_t(w.length,w.length,50,40,60,{query:j>0?"warning":"ok",hasCriticalQueries:j>0},0);let L=[],D=null;try{L=(await Xe.fetchAnomalies({is_active:!0,limit:100})).anomalies||[],D=await Xe.fetchAnomalyStats({})}catch{}let q=[],ie=null;try{const Q=await Oe.getLatestRun({});Q&&Q.status==="completed"&&(q=await Oe.getFindings(Q.id)||[],r&&Q.ai_status==="completed"&&(ie=await Oe.getAISummary(Q.id)))}catch{}const ce=q.length>0?Dt(q):Tt(L,l),Ne=q.length>0?Lt(q):It(L),Se=Et(l),ze=Ft(L),fe=Math.max(0,l.length-Math.floor(l.length*.1)),ge=(D==null?void 0:D.resolved_count)||0,oe=Ht(l.length,fe,L.length,ge,L);let Ae,me;r&&ie&&ie.executive_summary?(me=ie.executive_summary,Ae="doctor_ai"):(me=Yt({overall:_.score,status:_.status},ce,Se,ze,oe),Ae=r?"ai_service":"deterministic");const De=ce.slice(0,3).map(Q=>({text:Q.recommendedFix,source:Q.source})),he=Bt(e==null?void 0:e.capacityPlanning),Te={totalQueries:0,avgDurationMs:0,p95DurationMs:0,topQueries:[]},Le=_.status==="healthy"?"HEALTHY":_.status==="warning"?"DEGRADED":"CRITICAL",Ie=fe>0?(l.length-fe)/fe*100:0,Ee=ge>0?(L.length-ge)/ge*100:0,Fe=ce.filter(Q=>Q.severity==="critical").length>0?"degraded":oe.topImprovements.length>oe.topRegressions.length?"improved":"stable";return{summarySource:Ae,aiEnabled:r,clusterNames:w,timeRange:{label:t.timeRangeLabel,start:h,end:$},generatedAt:f,healthScore:{overall:_.score,status:_.status,categories:_.categories},executiveSummary:{statusLabel:Le,summaryText:me,topRisks:ce.slice(0,3),recommendedActions:De,vsLastPeriod:{alarmCountChange:Ie,anomalyCountChange:Ee,performanceTrend:Fe}},risks:ce,alarmIntelligence:Se,anomalyAnalysis:ze,queryPerformance:Te,resources:he,quickWins:Ne,whatChanged:oe,recentAlarms:l,capacityPlanning:e==null?void 0:e.capacityPlanning}}const s={headerGradientFrom:"#1e293b",headerGradientTo:"#334155",healthy:"#22c55e",warning:"#f59e0b",critical:"#ef4444",accent:"#6366f1",text:"#374151",textSecondary:"#6b7280",textMuted:"#9ca3af",bg:"#ffffff",bgCard:"#f8fafc",border:"#e2e8f0",severityCritical:"#ef4444",severityHigh:"#f97316",severityMedium:"#f59e0b",confHigh:"#22c55e",confMedium:"#f59e0b",confLow:"#9ca3af"};function Ot(t){return t==="healthy"||t==="HEALTHY"?s.healthy:t==="warning"||t==="DEGRADED"?s.warning:s.critical}function dt(t){return t==="critical"?s.severityCritical:t==="high"?s.severityHigh:s.severityMedium}function tt(t){return t==="high"?s.confHigh:t==="medium"?s.confMedium:s.confLow}function Gt(t){return t==="HEALTHY"?"✅":t==="DEGRADED"?"⚠️":"🔥"}function it(t){return t>5?`↑ +${t.toFixed(0)}%`:t<-5?`↓ ${t.toFixed(0)}%`:`→ ${t.toFixed(0)}%`}function Ut(t){const e=t.healthScore.overall>=90?s.healthy:t.healthScore.overall>=70?s.warning:s.critical;return`
    <div style="text-align:center; padding:40px 30px; background:linear-gradient(135deg,${s.headerGradientFrom},${s.headerGradientTo}); border-radius:12px; color:white; margin-bottom:30px;">
      <div style="background:white; display:inline-block; padding:10px 24px; border-radius:40px; margin-bottom:20px;">
        <span style="font-size:28px; font-weight:700; color:${s.accent};">ClusterEye</span>
      </div>
      <h1 style="font-size:24px; font-weight:600; margin:0 0 8px;">Automated Performance Report</h1>
      <p style="font-size:14px; margin:4px 0; opacity:0.85;">${t.clusterNames.join(", ")}</p>
      <p style="font-size:13px; margin:4px 0; opacity:0.7;">${t.timeRange.label} &nbsp;|&nbsp; ${t.generatedAt}</p>
      <div style="margin-top:24px;">
        <div style="display:inline-block; width:90px; height:90px; border-radius:50%; border:4px solid ${e}; line-height:82px; font-size:32px; font-weight:700; color:white; text-align:center;">
          ${t.healthScore.overall}
        </div>
        <div style="margin-top:8px;">
          <span style="background:${e}; color:white; padding:4px 14px; border-radius:20px; font-size:12px; font-weight:600;">
            ${t.executiveSummary.statusLabel}
          </span>
        </div>
      </div>
    </div>`}function Vt(t){const e=t.executiveSummary,r=Ot(e.statusLabel);return`
    <div style="margin-bottom:30px;">
      <h2 style="font-size:18px; color:${s.headerGradientFrom}; border-bottom:2px solid ${s.accent}; padding-bottom:8px; margin-bottom:16px;">
        🧠 Executive Summary
      </h2>
      <div style="display:flex; align-items:center; gap:8px; margin-bottom:12px;">
        <span style="font-size:20px;">${Gt(e.statusLabel)}</span>
        <span style="font-size:16px; font-weight:700; color:${r};">System Status: ${e.statusLabel}</span>
      </div>
      <p style="font-size:13px; color:${s.text}; line-height:1.7; margin-bottom:16px;">
        ${e.summaryText}
      </p>
      <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px; margin-bottom:16px;">
        <div style="background:${s.bgCard}; border:1px solid ${s.border}; border-radius:8px; padding:14px;">
          <div style="font-size:11px; font-weight:600; color:${s.textSecondary}; text-transform:uppercase; margin-bottom:8px;">Top Risks</div>
          ${e.topRisks.map(f=>`
            <div style="display:flex; align-items:center; gap:6px; margin-bottom:6px; font-size:12px; color:${s.text};">
              <span style="background:${dt(f.severity)}; color:white; padding:1px 6px; border-radius:3px; font-size:10px; font-weight:600;">${f.severity.toUpperCase()}</span>
              ${f.title}
            </div>
          `).join("")}
        </div>
        <div style="background:${s.bgCard}; border:1px solid ${s.border}; border-radius:8px; padding:14px;">
          <div style="font-size:11px; font-weight:600; color:${s.textSecondary}; text-transform:uppercase; margin-bottom:8px;">Recommended Actions</div>
          ${e.recommendedActions.map(f=>`
            <div style="font-size:12px; color:${s.text}; margin-bottom:6px;">• ${f.text}</div>
          `).join("")}
        </div>
      </div>
      <div style="display:flex; gap:12px;">
        <span style="background:${s.bgCard}; border:1px solid ${s.border}; border-radius:6px; padding:6px 12px; font-size:11px; color:${s.text};">
          Alarms: ${it(e.vsLastPeriod.alarmCountChange)}
        </span>
        <span style="background:${s.bgCard}; border:1px solid ${s.border}; border-radius:6px; padding:6px 12px; font-size:11px; color:${s.text};">
          Anomalies: ${it(e.vsLastPeriod.anomalyCountChange)}
        </span>
        <span style="background:${s.bgCard}; border:1px solid ${s.border}; border-radius:6px; padding:6px 12px; font-size:11px; color:${s.text};">
          Performance: ${e.vsLastPeriod.performanceTrend==="improved"?"↑ Improved":e.vsLastPeriod.performanceTrend==="degraded"?"↓ Degraded":"→ Stable"}
        </span>
      </div>
    </div>`}function qt(t){const e=[{name:"Availability",weight:"40%",score:t.healthScore.categories.availability},{name:"Infrastructure",weight:"25%",score:t.healthScore.categories.infrastructure},{name:"Performance",weight:"20%",score:t.healthScore.categories.performance},{name:"Maintenance",weight:"15%",score:t.healthScore.categories.maintenance}];return`
    <div style="margin-bottom:30px;">
      <h2 style="font-size:18px; color:${s.headerGradientFrom}; border-bottom:2px solid ${s.accent}; padding-bottom:8px; margin-bottom:16px;">
        📊 Health Score Breakdown
      </h2>
      <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
        ${e.map(r=>{const f=r.score>=80?s.healthy:r.score>=50?s.warning:s.critical;return`
          <div style="background:${s.bgCard}; border:1px solid ${s.border}; border-radius:8px; padding:14px;">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
              <span style="font-size:13px; font-weight:600; color:${s.text};">${r.name}</span>
              <span style="font-size:11px; color:${s.textMuted};">${r.weight}</span>
            </div>
            <div style="font-size:24px; font-weight:700; color:${f}; margin-bottom:6px;">${Math.round(r.score)}%</div>
            <div style="background:${s.border}; height:6px; border-radius:3px; overflow:hidden;">
              <div style="background:${f}; height:100%; width:${Math.round(r.score)}%; border-radius:3px;"></div>
            </div>
          </div>`}).join("")}
      </div>
    </div>`}function Wt(t){return t.length===0?`<div style="margin-bottom:30px;"><h2 style="font-size:18px; color:${s.headerGradientFrom}; border-bottom:2px solid ${s.accent}; padding-bottom:8px;">🚨 Top Risks</h2><p style="color:${s.textSecondary}; font-size:13px;">No significant risks detected in this period.</p></div>`:`
    <div style="margin-bottom:30px;">
      <h2 style="font-size:18px; color:${s.headerGradientFrom}; border-bottom:2px solid ${s.accent}; padding-bottom:8px; margin-bottom:16px;">
        🚨 Top Risks
      </h2>
      ${t.map(e=>`
        <div style="background:${s.bgCard}; border:1px solid ${s.border}; border-radius:8px; padding:14px; margin-bottom:10px;">
          <div style="display:flex; align-items:center; gap:8px; margin-bottom:8px;">
            <span style="background:${dt(e.severity)}; color:white; padding:2px 8px; border-radius:4px; font-size:10px; font-weight:600;">${e.severity.toUpperCase()}</span>
            <span style="font-size:14px; font-weight:600; color:${s.text};">${e.title}</span>
            <span style="margin-left:auto; font-size:10px; padding:2px 6px; border-radius:3px; background:${tt(e.confidenceLevel)}22; color:${tt(e.confidenceLevel)}; font-weight:500;">
              ${e.confidenceLevel} confidence
            </span>
          </div>
          <div style="font-size:12px; color:${s.textSecondary}; margin-bottom:4px;">
            <strong>Affected:</strong> ${e.affectedNodes.length>0?e.affectedNodes.join(", "):"Cluster-wide"} &nbsp;|&nbsp;
            <strong>Impact:</strong> ${e.impactLevel.toUpperCase()} ${e.impactType}
          </div>
          <div style="font-size:12px; color:${s.text}; margin-bottom:4px;"><strong>Cause:</strong> ${e.cause}</div>
          <div style="font-size:12px; color:${s.accent}; font-weight:500;">💡 ${e.recommendedFix}</div>
        </div>
      `).join("")}
    </div>`}function Jt(t){return`
    <div style="margin-bottom:30px;">
      <h2 style="font-size:18px; color:${s.headerGradientFrom}; border-bottom:2px solid ${s.accent}; padding-bottom:8px; margin-bottom:16px;">
        📈 What Changed
      </h2>
      <p style="font-size:13px; color:${s.text}; line-height:1.6; margin-bottom:14px;">${t.narrative}</p>
      ${t.mostChangedMetrics.length>0?`
        <div style="display:flex; flex-wrap:wrap; gap:8px;">
          ${t.mostChangedMetrics.map(e=>`
            <span style="background:${e.direction==="up"?"#fef2f2":"#f0fdf4"}; border:1px solid ${e.direction==="up"?"#fecaca":"#bbf7d0"}; border-radius:6px; padding:4px 10px; font-size:11px; color:${e.direction==="up"?s.critical:s.healthy}; font-weight:500;">
              ${e.metric}: ${e.direction==="up"?"+":""}${e.changePct.toFixed(0)}%
            </span>
          `).join("")}
        </div>
      `:""}
    </div>`}function Kt(t){return`
    <div style="margin-bottom:30px;">
      <h2 style="font-size:18px; color:${s.headerGradientFrom}; border-bottom:2px solid ${s.accent}; padding-bottom:8px; margin-bottom:16px;">
        🚨 Alarm Intelligence
      </h2>
      <div style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:10px; margin-bottom:14px;">
        <div style="text-align:center; background:${s.bgCard}; border:1px solid ${s.border}; border-radius:8px; padding:12px;">
          <div style="font-size:22px; font-weight:700; color:${s.text};">${t.totalAlarms}</div>
          <div style="font-size:11px; color:${s.textSecondary};">Total Alarms</div>
        </div>
        <div style="text-align:center; background:${s.bgCard}; border:1px solid ${s.border}; border-radius:8px; padding:12px;">
          <div style="font-size:22px; font-weight:700; color:${s.critical};">${t.criticalCount}</div>
          <div style="font-size:11px; color:${s.textSecondary};">Critical</div>
        </div>
        <div style="text-align:center; background:${s.bgCard}; border:1px solid ${s.border}; border-radius:8px; padding:12px;">
          <div style="font-size:22px; font-weight:700; color:${s.warning};">${t.warningCount}</div>
          <div style="font-size:11px; color:${s.textSecondary};">Warning</div>
        </div>
      </div>
      ${t.noisyNodes.length>0?`
        <div style="background:#fffbeb; border:1px solid #fde68a; border-radius:8px; padding:12px; margin-bottom:10px;">
          <div style="font-size:12px; font-weight:600; color:#92400e; margin-bottom:6px;">⚠️ Noisy Nodes Detected</div>
          ${t.noisyNodes.map(e=>`
            <div style="font-size:12px; color:${s.text}; margin-bottom:4px;">
              <strong>${e.nodeId}</strong> — ${e.count} alarms → ${e.suggestion}
            </div>
          `).join("")}
        </div>
      `:""}
      ${t.alertFatigueRisk?`
        <div style="background:#fef2f2; border:1px solid #fecaca; border-radius:8px; padding:10px; font-size:12px; color:#991b1b;">
          🔥 Alert fatigue risk: ${t.totalAlarms} alarms may overwhelm the team. Consider consolidation.
        </div>
      `:""}
    </div>`}function Zt(t){return t.totalAnomalies===0?`<div style="margin-bottom:30px;"><h2 style="font-size:18px; color:${s.headerGradientFrom}; border-bottom:2px solid ${s.accent}; padding-bottom:8px;">🤖 Anomaly Analysis</h2><p style="color:${s.textSecondary}; font-size:13px;">No anomalies detected in this period.</p></div>`:`
    <div style="margin-bottom:30px;">
      <h2 style="font-size:18px; color:${s.headerGradientFrom}; border-bottom:2px solid ${s.accent}; padding-bottom:8px; margin-bottom:16px;">
        🤖 Anomaly Analysis
      </h2>
      <div style="font-size:13px; color:${s.text}; margin-bottom:12px;">${t.totalAnomalies} anomalies detected.</div>
      ${t.byDatabase.map(e=>`
        <div style="background:${s.bgCard}; border:1px solid ${s.border}; border-radius:8px; padding:12px; margin-bottom:8px;">
          <div style="font-size:13px; font-weight:600; color:${s.text}; margin-bottom:4px;">${e.dbType} — ${e.count} anomalies</div>
          <div style="font-size:12px; color:${s.textSecondary};">Top metric: <strong>${e.topMetric}</strong> (${e.changePercent>0?"+":""}${e.changePercent.toFixed(0)}%)</div>
        </div>
      `).join("")}
    </div>`}function Xt(t){return`
    <div style="margin-bottom:30px;">
      <h2 style="font-size:18px; color:${s.headerGradientFrom}; border-bottom:2px solid ${s.accent}; padding-bottom:8px; margin-bottom:16px;">
        🐢 Query Performance
      </h2>
      <div style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:10px; margin-bottom:14px;">
        <div style="text-align:center; background:${s.bgCard}; border:1px solid ${s.border}; border-radius:8px; padding:12px;">
          <div style="font-size:20px; font-weight:700; color:${s.text};">${t.totalQueries.toLocaleString()}</div>
          <div style="font-size:11px; color:${s.textSecondary};">Total Queries</div>
        </div>
        <div style="text-align:center; background:${s.bgCard}; border:1px solid ${s.border}; border-radius:8px; padding:12px;">
          <div style="font-size:20px; font-weight:700; color:${s.text};">${t.avgDurationMs.toFixed(1)}ms</div>
          <div style="font-size:11px; color:${s.textSecondary};">Avg Duration</div>
        </div>
        <div style="text-align:center; background:${s.bgCard}; border:1px solid ${s.border}; border-radius:8px; padding:12px;">
          <div style="font-size:20px; font-weight:700; color:${s.text};">${t.p95DurationMs.toFixed(1)}ms</div>
          <div style="font-size:11px; color:${s.textSecondary};">P95 Duration</div>
        </div>
      </div>
      ${t.topQueries.length>0?`
        <table style="width:100%; border-collapse:collapse; font-size:12px;">
          <thead>
            <tr style="background:${s.bgCard};">
              <th style="padding:8px; border:1px solid ${s.border}; text-align:left; font-weight:600; color:${s.text};">Query</th>
              <th style="padding:8px; border:1px solid ${s.border}; text-align:right;">Avg (ms)</th>
              <th style="padding:8px; border:1px solid ${s.border}; text-align:right;">Count</th>
              <th style="padding:8px; border:1px solid ${s.border}; text-align:center;">Impact</th>
              <th style="padding:8px; border:1px solid ${s.border}; text-align:left;">Recommendation</th>
            </tr>
          </thead>
          <tbody>
            ${t.topQueries.map(e=>`
              <tr>
                <td style="padding:8px; border:1px solid ${s.border}; font-family:monospace; font-size:11px; max-width:200px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">${e.fingerprint}</td>
                <td style="padding:8px; border:1px solid ${s.border}; text-align:right;">${e.avgDurationMs.toFixed(1)}</td>
                <td style="padding:8px; border:1px solid ${s.border}; text-align:right;">${e.executionCount.toLocaleString()}</td>
                <td style="padding:8px; border:1px solid ${s.border}; text-align:center;">
                  <span style="padding:2px 6px; border-radius:3px; font-size:10px; font-weight:600; background:${e.impactLevel==="high"?"#fef2f2":e.impactLevel==="medium"?"#fffbeb":"#f0fdf4"}; color:${e.impactLevel==="high"?s.critical:e.impactLevel==="medium"?s.warning:s.healthy};">${e.impactLevel.toUpperCase()}</span>
                </td>
                <td style="padding:8px; border:1px solid ${s.border}; font-size:11px;">${e.recommendation}</td>
              </tr>
            `).join("")}
          </tbody>
        </table>
      `:'<p style="font-size:12px; color:'+s.textSecondary+';">No query data available for this period.</p>'}
    </div>`}function ot(t,e){if(e.dataQuality==="unavailable")return`<div style="background:${s.bgCard}; border:1px solid ${s.border}; border-radius:8px; padding:14px;"><div style="font-size:13px; font-weight:600; color:${s.text}; margin-bottom:6px;">${t}</div><div style="font-size:12px; color:${s.textMuted};">Data unavailable for this period.</div></div>`;if(e.dataQuality==="suspect")return`<div style="background:#fffbeb; border:1px solid #fde68a; border-radius:8px; padding:14px;"><div style="font-size:13px; font-weight:600; color:${s.text}; margin-bottom:6px;">${t}</div><div style="font-size:12px; color:#92400e;">⚠️ Metric collection issue detected — data may be incomplete.</div></div>`;const r=e.max>90?s.critical:e.max>70?s.warning:s.healthy;return`
    <div style="background:${s.bgCard}; border:1px solid ${s.border}; border-radius:8px; padding:14px;">
      <div style="font-size:13px; font-weight:600; color:${s.text}; margin-bottom:8px;">${t}</div>
      <div style="display:flex; justify-content:space-between; font-size:12px; color:${s.textSecondary}; margin-bottom:6px;">
        <span>Avg: <strong style="color:${s.text};">${e.avg.toFixed(1)}%</strong></span>
        <span>Max: <strong style="color:${r};">${e.max.toFixed(1)}%</strong></span>
      </div>
      <div style="background:${s.border}; height:8px; border-radius:4px; overflow:hidden;">
        <div style="background:${r}; height:100%; width:${Math.min(100,e.max).toFixed(0)}%; border-radius:4px;"></div>
      </div>
    </div>`}function ei(t){return`
    <div style="margin-bottom:30px;">
      <h2 style="font-size:18px; color:${s.headerGradientFrom}; border-bottom:2px solid ${s.accent}; padding-bottom:8px; margin-bottom:16px;">
        ⚙️ Resource Utilization
      </h2>
      <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
        ${ot("CPU",t.resources.cpu)}
        ${ot("Memory",t.resources.memory)}
      </div>
    </div>`}function ti(t){return t.length===0?`<div style="margin-bottom:30px;"><h2 style="font-size:18px; color:${s.headerGradientFrom}; border-bottom:2px solid ${s.accent}; padding-bottom:8px;">⚡ Quick Wins</h2><p style="color:${s.textSecondary}; font-size:13px;">No quick wins identified in this period.</p></div>`:`
    <div style="margin-bottom:30px;">
      <h2 style="font-size:18px; color:${s.headerGradientFrom}; border-bottom:2px solid ${s.accent}; padding-bottom:8px; margin-bottom:16px;">
        ⚡ Quick Wins
      </h2>
      ${t.map(e=>`
        <div style="background:${s.bgCard}; border:1px solid ${s.border}; border-radius:8px; padding:12px; margin-bottom:8px; display:flex; justify-content:space-between; align-items:center;">
          <div>
            <div style="font-size:13px; font-weight:600; color:${s.text};">${e.title}</div>
            <div style="font-size:12px; color:${s.textSecondary}; margin-top:2px;">${e.description}</div>
          </div>
          <div style="display:flex; gap:6px; flex-shrink:0;">
            <span style="background:#f0fdf4; border:1px solid #bbf7d0; border-radius:4px; padding:2px 8px; font-size:10px; font-weight:500; color:#166534;">~${e.effortLevel}</span>
            <span style="background:${e.expectedImpact==="high"?"#fef2f2":e.expectedImpact==="medium"?"#fffbeb":"#f0fdf4"}; border:1px solid ${e.expectedImpact==="high"?"#fecaca":e.expectedImpact==="medium"?"#fde68a":"#bbf7d0"}; border-radius:4px; padding:2px 8px; font-size:10px; font-weight:500; color:${e.expectedImpact==="high"?"#991b1b":e.expectedImpact==="medium"?"#92400e":"#166534"};">
              ${e.expectedImpact.toUpperCase()} impact
            </span>
          </div>
        </div>
      `).join("")}
    </div>`}function ii(t){const e=`RPT-${t.generatedAt.replace(/[\s:-]/g,"").substring(0,14)}`;return`
    <div style="margin-top:40px; padding:16px; border-top:2px solid ${s.border}; text-align:center;">
      <div style="font-size:11px; color:${s.textMuted};">
        Report ID: ${e} &nbsp;|&nbsp; Period: ${t.timeRange.label} &nbsp;|&nbsp; Generated: ${t.generatedAt}
      </div>
      <div style="font-size:12px; color:${s.textSecondary}; margin-top:4px; font-weight:500;">
        Generated by ClusterEye — Automated Performance Report
      </div>
    </div>`}function oi(t){return`
    <div style="max-width:800px; margin:0 auto; font-family:'Segoe UI',system-ui,-apple-system,sans-serif; line-height:1.6; color:${s.text};">
      ${Ut(t)}
      ${Vt(t)}
      ${qt(t)}
      ${Wt(t.risks)}
      ${Jt(t.whatChanged)}
      ${Kt(t.alarmIntelligence)}
      ${Zt(t.anomalyAnalysis)}
      ${Xt(t.queryPerformance)}
      ${ei(t)}
      ${ti(t.quickWins)}
      ${ii(t)}
    </div>`}const{TabPane:st}=nt,{Option:W}=pe,ci=()=>{const[t,e]=K.useState([]),[r,f]=K.useState([]),[w,h]=K.useState(!1),[$,l]=K.useState(!1),[j]=z.useForm(),[_]=z.useForm(),[L,D]=K.useState(null),[q,ie]=K.useState([]),[ce,Ne]=K.useState([]),[Se,ze]=K.useState([]),[fe,ge]=K.useState(!1),[oe,Ae]=K.useState(null),[me,De]=K.useState(null);K.useEffect(()=>{he(),Te(),Le()},[]);const he=async()=>{try{const i=localStorage.getItem("token"),a=await(await fetch(`${X()}/api/v1/reports`,{headers:{"Content-Type":"application/json",CEFE:"Yes",...i?{Authorization:`Bearer ${i}`}:{}}})).json();e(a.reports)}catch{B.error("Failed to fetch reports")}},Te=async()=>{try{const i=localStorage.getItem("token"),a=await(await fetch(`${X()}/api/v1/reports/history`,{headers:{"Content-Type":"application/json",CEFE:"Yes",...i?{Authorization:`Bearer ${i}`}:{}}})).json();f(a.history)}catch{B.error("Failed to fetch report history")}},Le=async()=>{try{const i=localStorage.getItem("token"),a=await(await fetch(`${X()}/api/v1/status/nodeshealth`,{headers:{"Content-Type":"application/json",CEFE:"Yes",...i?{Authorization:`Bearer ${i}`}:{}}})).json(),y=[];a.mongodb&&a.mongodb.forEach(g=>{const k=Object.keys(g)[0],Y=g[k];y.push({id:k,name:k,type:"MongoDB",nodes:Y.length,nodeList:Y.map(P=>({hostname:P.Hostname,agentID:P.AgentID||`agent_${P.Hostname}`,isPrimary:P.IsPrimary,status:P.MongoStatus||"Unknown"}))})}),a.postgresql&&a.postgresql.forEach(g=>{const k=Object.keys(g)[0],Y=g[k];y.push({id:k,name:k,type:"PostgreSQL",nodes:Y.length,nodeList:Y.map(P=>({hostname:P.Hostname,agentID:P.AgentID||`agent_${P.Hostname}`,role:P.Role||"Unknown",status:P.Status||"Unknown"}))})}),a.mssql&&a.mssql.forEach(g=>{const k=Object.keys(g)[0],Y=g[k];y.push({id:k,name:k,type:"MSSQL",nodes:Y.length,nodeList:Y.map(P=>({hostname:P.Hostname,agentID:P.AgentID||`agent_${P.Hostname}`,status:P.Status||"Unknown"}))})}),ie(y)}catch{B.error("Failed to fetch available clusters")}},Ie=()=>{D(null),j.resetFields(),h(!0)},Ee=i=>{D(i),j.setFieldsValue({...i,time:F(i.schedule.time,"HH:mm")}),h(!0)},Fe=async()=>{try{const i=await j.validateFields(),n={...i,schedule:{...i.schedule,time:i.time.format("HH:mm")}},a=L?`${X()}/api/v1/reports/${L.id}`:`${X()}/api/v1/reports`,y=L?"PUT":"POST",g=localStorage.getItem("token");if(!(await fetch(a,{method:y,headers:{"Content-Type":"application/json",CEFE:"Yes",...g?{Authorization:`Bearer ${g}`}:{}},body:JSON.stringify(n)})).ok)throw new Error("Failed to save report");B.success(`Report ${L?"updated":"created"} successfully`),h(!1),he()}catch{B.error("Failed to save report")}},Ce=async i=>{try{const a=await(await fetch(i)).blob(),y=window.URL.createObjectURL(a),g=document.createElement("a");g.href=y,g.download="report.pdf",document.body.appendChild(g),g.click(),window.URL.revokeObjectURL(y),document.body.removeChild(g)}catch{B.error("Failed to download PDF")}},je=async i=>{try{const n=i.status==="active"?"paused":"active",a=localStorage.getItem("token");await fetch(`${X()}/api/v1/reports/${i.id}/status`,{method:"PUT",headers:{"Content-Type":"application/json",CEFE:"Yes",...a?{Authorization:`Bearer ${a}`}:{}},body:JSON.stringify({status:n})}),B.success(`Report ${n}`),he()}catch{B.error("Failed to update report status")}},Q=async i=>{try{const n=localStorage.getItem("token");await fetch(`${X()}/api/v1/reports/${i}`,{method:"DELETE",headers:{"Content-Type":"application/json",CEFE:"Yes",...n?{Authorization:`Bearer ${n}`}:{}}}),B.success("Report deleted"),he()}catch{B.error("Failed to delete report")}},Ue=async()=>{var i;try{B.loading({content:"Generating report...",key:"report"});const n=F().format("YYYY-MM-DDTHH:mm:ssZ"),a=F().subtract(24,"hours").format("YYYY-MM-DDTHH:mm:ssZ"),y=localStorage.getItem("token"),k=await(await fetch(`${X()}/api/v1/status/nodeshealth`,{headers:{"Content-Type":"application/json",CEFE:"Yes",...y?{Authorization:`Bearer ${y}`}:{}}})).json(),Y=k.mongodb||[],M=(((i=(await(await fetch(`${X()}/api/v1/status/alarms?start_time=${a}&end_time=${n}`,{headers:{"Content-Type":"application/json",CEFE:"Yes",...y?{Authorization:`Bearer ${y}`}:{}}})).json()).data)==null?void 0:i.alarms)||[]).sort((d,x)=>new Date(x.created_at).getTime()-new Date(d.created_at).getTime()).slice(0,5),A=document.createElement("div");A.style.padding="20px",A.style.backgroundColor="white",A.style.width="800px",A.style.position="absolute",A.style.left="-9999px",A.style.top="0",A.style.fontFamily="Arial, sans-serif";const N=d=>{const x=["B","KB","MB","GB","TB"];if(d===0)return"0 B";const C=Math.floor(Math.log(d)/Math.log(1024));return`${(d/Math.pow(1024,C)).toFixed(2)} ${x[C]}`},be=d=>d.map(x=>{var m,T;const C=Object.keys(x)[0],u=x[C];return{name:C,type:"MongoDB",totalNodes:u.length,running:u.filter(c=>c.MongoStatus==="RUNNING").length,version:((m=u[0])==null?void 0:m.MongoVersion)||"N/A",locations:[...new Set(u.map(c=>c.Location))].join(", "),avgDiskFree:(u.reduce((c,E)=>{const U=parseFloat(E.FreeDisk);return c+(isNaN(U)?0:U)},0)/u.length).toFixed(1)+"G",avgMemory:N(u.reduce((c,E)=>c+(E.TotalMemory||0),0)/u.length),primary:((T=u.find(c=>c.NodeStatus==="PRIMARY"))==null?void 0:T.Hostname)||"N/A",secondaries:u.filter(c=>c.NodeStatus==="SECONDARY").length}}),G=d=>d.map(x=>{var m,T;const C=Object.keys(x)[0],u=x[C];return{name:C,type:"PostgreSQL",totalNodes:u.length,running:u.filter(c=>c.PGServiceStatus==="RUNNING").length,version:((m=u[0])==null?void 0:m.PGVersion)||"N/A",locations:[...new Set(u.map(c=>c.Location))].join(", "),avgDiskFree:(u.reduce((c,E)=>{var J;const U=(J=E.FreeDisk)==null?void 0:J.split(" ")[0];return c+(isNaN(U)?0:parseFloat(U))},0)/u.length).toFixed(1)+" GB",avgMemory:N(u.reduce((c,E)=>c+(E.TotalMemory||0),0)/u.length),master:((T=u.find(c=>c.NodeStatus==="MASTER"))==null?void 0:T.Hostname)||"N/A",slaves:u.filter(c=>c.NodeStatus==="SLAVE").length}}),ve=d=>d.map(x=>{var m,T,c,E,U,J,de;const C=Object.keys(x)[0],u=x[C];return{name:C||"Standalone",type:"MSSQL",totalNodes:u.length,running:u.filter(O=>O.Status==="RUNNING").length,version:((T=(m=u[0])==null?void 0:m.Version)==null?void 0:T.split(" ")[0])+" "+(((E=(c=u[0])==null?void 0:c.Version)==null?void 0:E.split(" ")[1])||"")||"N/A",locations:[...new Set(u.map(O=>O.Location))].join(", "),avgDiskFree:(u.reduce((O,S)=>{var Me;const ke=parseFloat((Me=S.FreeDisk)==null?void 0:Me.split(" ")[0]);return O+(isNaN(ke)?0:ke)},0)/u.length).toFixed(1)+" GB",avgMemory:N(u.reduce((O,S)=>O+(S.TotalMemory||0),0)/u.length),primary:((U=u.find(O=>O.HARole==="PRIMARY"||O.NodeStatus==="PRIMARY"))==null?void 0:U.Hostname)||(((J=u[0])==null?void 0:J.HARole)==="STANDALONE"?(de=u[0])==null?void 0:de.Hostname:"N/A"),secondaries:u.filter(O=>O.HARole==="SECONDARY"||O.NodeStatus==="SECONDARY").length}}),$e=be(k.mongodb||[]),se=G(k.postgresql||[]),xe=ve(k.mssql||[]),Z=[...$e,...se,...xe],we=d=>d.map(x=>{const C=Object.keys(x)[0],u=x[C];return{clusterName:C,type:"MongoDB",nodes:u.map(m=>({hostname:m.Hostname,status:m.MongoStatus,nodeType:m.NodeStatus,version:m.MongoVersion,location:m.Location,freeDisk:m.FreeDisk,totalMemory:N(m.TotalMemory),vcpu:m.TotalVCPU,replicationLag:m.ReplicationLagSec,ip:m.IP,port:m.Port}))}}),ne=d=>d.map(x=>{const C=Object.keys(x)[0],u=x[C];return{clusterName:C,type:"PostgreSQL",nodes:u.map(m=>({hostname:m.Hostname,status:m.PGServiceStatus,nodeType:m.NodeStatus,version:m.PGVersion,location:m.Location,freeDisk:m.FreeDisk,totalMemory:N(m.TotalMemory),vcpu:m.TotalVCPU,replicationLag:m.ReplicationLagSec,ip:m.IP,bouncer:m.PGBouncerStatus}))}}),re=d=>d.map(x=>{const C=Object.keys(x)[0],u=x[C];return{clusterName:C||"Standalone",type:"MSSQL",nodes:u.map(m=>{var T,c;return{hostname:m.Hostname,status:m.Status,nodeType:m.HARole||m.NodeStatus,version:((T=m.Version)==null?void 0:T.split(" ")[0])+" "+(((c=m.Version)==null?void 0:c.split(" ")[1])||""),location:m.Location,freeDisk:m.FreeDisk,totalMemory:N(m.TotalMemory),vcpu:m.TotalVCPU,replicationLag:"N/A",ip:m.IP,port:m.Port}})}}),ae=we(k.mongodb||[]),p=ne(k.postgresql||[]),b=re(k.mssql||[]),v=[...ae,...p,...b],R=`
                <div style="font-family: Arial, sans-serif !important; color: #000000;">
                    <div style="text-align: center; margin-bottom: 30px; padding: 20px; background-color: #f0f2f5; border-radius: 8px;">
                        <h1 style="color: #1890ff; margin: 0; font-size: 28px; font-weight: bold;">System Health Report</h1>
                        <p style="color: #666; margin: 10px 0 0 0; font-size: 14px;">Generated on: ${F().format("YYYY-MM-DD HH:mm:ss")}</p>
                    </div>
                    
                    <div style="margin-bottom: 40px;">
                        <h2 style="color: #1890ff; font-size: 22px; margin-bottom: 20px; padding-bottom: 10px; border-bottom: 2px solid #1890ff;">
                            Cluster Health Summary
                        </h2>
                        ${Z.map(d=>`
                            <div style="background-color: #fafafa; border: 1px solid #e8e8e8; padding: 20px; margin-bottom: 20px; border-radius: 8px;">
                                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                                    <h3 style="margin: 0; color: #333; font-size: 18px;">${d.name}</h3>
                                    <span style="
                                        padding: 4px 8px;
                                        border-radius: 4px;
                                        background-color: ${d.type==="MongoDB"?"#00684A":d.type==="PostgreSQL"?"#336791":"#52c41a"};
                                        color: white;
                                        font-size: 12px;
                                    ">${d.type}</span>
                                </div>
                                <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px; font-size: 14px;">
                                    <div style="background: white; padding: 10px; border-radius: 4px; border: 1px solid #e8e8e8;">
                                        <strong>Nodes:</strong> ${d.totalNodes} (${d.running} running)
                                    </div>
                                    <div style="background: white; padding: 10px; border-radius: 4px; border: 1px solid #e8e8e8;">
                                        <strong>Version:</strong> ${d.version}
                                    </div>
                                    <div style="background: white; padding: 10px; border-radius: 4px; border: 1px solid #e8e8e8;">
                                        <strong>Locations:</strong> ${d.locations}
                                    </div>
                                    <div style="background: white; padding: 10px; border-radius: 4px; border: 1px solid #e8e8e8;">
                                        <strong>Avg Free Disk:</strong> ${d.avgDiskFree}
                                    </div>
                                    <div style="background: white; padding: 10px; border-radius: 4px; border: 1px solid #e8e8e8;">
                                        <strong>Avg Memory:</strong> ${d.avgMemory}
                                    </div>
                                    <div style="background: white; padding: 10px; border-radius: 4px; border: 1px solid #e8e8e8;">
                                        <strong>${d.type==="MongoDB"?"Primary":d.type==="PostgreSQL"?"Master":"Primary"}:</strong> ${d.type==="MongoDB"?d.primary:d.type==="PostgreSQL"?d.master:d.primary}
                                    </div>
                                    <div style="background: white; padding: 10px; border-radius: 4px; border: 1px solid #e8e8e8;">
                                        <strong>${d.type==="MongoDB"?"Secondaries":d.type==="PostgreSQL"?"Slaves":"Secondaries"}:</strong> ${d.type==="MongoDB"?d.secondaries:d.type==="PostgreSQL"?d.slaves:d.secondaries}
                                    </div>
                                </div>
                            </div>
                        `).join("")}
                    </div>

                    <div style="margin-bottom: 40px;">
                        <h2 style="color: #1890ff; font-size: 22px; margin-bottom: 20px; padding-bottom: 10px; border-bottom: 2px solid #1890ff;">
                            Node Status Details
                        </h2>
                        ${v.map(d=>`
                            <div style="margin-bottom: 30px;">
                                <div style="display: flex; align-items: center; margin-bottom: 15px;">
                                    <h3 style="margin: 0; color: #333; font-size: 18px;">${d.clusterName}</h3>
                                    <span style="
                                        margin-left: 10px;
                                        padding: 4px 8px;
                                        border-radius: 4px;
                                        background-color: ${d.type==="MongoDB"?"#00684A":d.type==="PostgreSQL"?"#336791":"#52c41a"};
                                        color: white;
                                        font-size: 12px;
                                    ">${d.type}</span>
                                </div>
                                <div style="overflow-x: auto;">
                                    <table style="width: 100%; border-collapse: collapse; font-size: 13px;">
                                        <thead>
                                            <tr style="background-color: #fafafa;">
                                                <th style="padding: 12px; border: 1px solid #e8e8e8; text-align: left;">Hostname</th>
                                                <th style="padding: 12px; border: 1px solid #e8e8e8; text-align: left;">Status</th>
                                                <th style="padding: 12px; border: 1px solid #e8e8e8; text-align: left;">Role</th>
                                                <th style="padding: 12px; border: 1px solid #e8e8e8; text-align: left;">Version</th>
                                                <th style="padding: 12px; border: 1px solid #e8e8e8; text-align: left;">Location</th>
                                                <th style="padding: 12px; border: 1px solid #e8e8e8; text-align: left;">Free Disk</th>
                                                <th style="padding: 12px; border: 1px solid #e8e8e8; text-align: left;">Memory</th>
                                                <th style="padding: 12px; border: 1px solid #e8e8e8; text-align: left;">vCPU</th>
                                                <th style="padding: 12px; border: 1px solid #e8e8e8; text-align: left;">Replication Lag</th>
                                                ${d.type==="PostgreSQL"?`
                                                    <th style="padding: 12px; border: 1px solid #e8e8e8; text-align: left;">PgBouncer</th>
                                                `:`
                                                    <th style="padding: 12px; border: 1px solid #e8e8e8; text-align: left;">Port</th>
                                                `}
                                            </tr>
                                        </thead>
                                        <tbody>
                                            ${d.nodes.map(x=>`
                                                <tr>
                                                    <td style="padding: 12px; border: 1px solid #e8e8e8;">
                                                        ${x.hostname}
                                                        <div style="font-size: 11px; color: #666;">${x.ip}</div>
                                                    </td>
                                                    <td style="padding: 12px; border: 1px solid #e8e8e8;">
                                                        <span style="
                                                            padding: 4px 8px;
                                                            border-radius: 4px;
                                                            background-color: ${x.status==="RUNNING"?"#52c41a":"#ff4d4f"};
                                                            color: white;
                                                            font-size: 11px;
                                                        ">${x.status}</span>
                                                    </td>
                                                    <td style="padding: 12px; border: 1px solid #e8e8e8;">
                                                        <span style="
                                                            padding: 4px 8px;
                                                            border-radius: 4px;
                                                            background-color: ${x.nodeType==="PRIMARY"||x.nodeType==="MASTER"?"#1890ff":x.nodeType==="SECONDARY"||x.nodeType==="SLAVE"||x.nodeType==="STANDALONE"?"#52c41a":"#faad14"};
                                                            color: white;
                                                            font-size: 11px;
                                                        ">${x.nodeType}</span>
                                                    </td>
                                                    <td style="padding: 12px; border: 1px solid #e8e8e8;">${x.version}</td>
                                                    <td style="padding: 12px; border: 1px solid #e8e8e8;">${x.location}</td>
                                                    <td style="padding: 12px; border: 1px solid #e8e8e8;">${x.freeDisk}</td>
                                                    <td style="padding: 12px; border: 1px solid #e8e8e8;">${x.totalMemory}</td>
                                                    <td style="padding: 12px; border: 1px solid #e8e8e8;">${x.vcpu}</td>
                                                    <td style="padding: 12px; border: 1px solid #e8e8e8;">
                                                        ${x.replicationLag===0?'<span style="color: #52c41a;">No Lag</span>':x.replicationLag==="N/A"?'<span style="color: #666;">N/A</span>':`<span style="color: #ff4d4f;">${x.replicationLag}s</span>`}
                                                    </td>
                                                    ${d.type==="PostgreSQL"?`
                                                        <td style="padding: 12px; border: 1px solid #e8e8e8;">
                                                            ${x.bouncer==="N/A"?'<span style="color: #666;">N/A</span>':`<span style="color: ${x.bouncer==="RUNNING"?"#52c41a":"#ff4d4f"}">${x.bouncer}</span>`}
                                                        </td>
                                                    `:`
                                                        <td style="padding: 12px; border: 1px solid #e8e8e8;">${x.port}</td>
                                                    `}
                                                </tr>
                                            `).join("")}
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        `).join("")}
                    </div>

                </div>
            `;A.innerHTML=R,document.body.appendChild(A),await new Promise(d=>setTimeout(d,2e3));try{const d=new Ke("p","pt","a4"),x=await Ze(A,{scale:1.5,useCORS:!0,logging:!0,backgroundColor:"#ffffff",windowWidth:800,windowHeight:A.offsetHeight,onclone:(O,S)=>{S.style.width="800px",S.style.height="auto",S.style.margin="0",S.style.padding="20px"}}),C=x.toDataURL("image/jpeg",1),u=d.internal.pageSize.getWidth(),m=d.internal.pageSize.getHeight(),T=x.width,c=x.height,E=u/T;let U=c*E,J=0,de=1;for(d.addImage(C,"JPEG",0,J,u,c*E);U>=m;)J=-m*de,d.addPage(),d.addImage(C,"JPEG",0,J,u,c*E),U-=m,de++;d.save("system-health-report.pdf"),document.body.removeChild(A),B.success({content:"Report generated successfully",key:"report"})}catch{B.error({content:"Failed to generate report",key:"report"}),document.body.removeChild(A)}}catch{B.error({content:"Failed to generate report",key:"report"})}},lt=()=>{_.resetFields(),_.setFieldsValue({timeRange:{type:"relative",relative:"1d"},sections:{systemMetrics:!0,diskAnalysis:!0,mongoAnalysis:{enabled:!0,includeCollections:!0,includeIndexes:!0,includePerformance:!0},postgresAnalysis:{enabled:!0,includeBloat:!0,includeSlowQueries:!0,includeConnections:!0},mssqlAnalysis:{enabled:!0,includeCapacityPlanning:!0,includePerformance:!0},alarmsAnalysis:!0,recommendations:!0}}),l(!0)},pt=async()=>{var i,n,a,y;try{const g=await _.validateFields();ge(!0),B.loading({content:"Generating comprehensive report...",key:"comprehensive-report"});const k=localStorage.getItem("token"),Y=g.nodes||[],P={timeRange:g.timeRange,clusters:Y,sections:g.sections},I=await fetch(`${X()}/api/v1/reports/generate`,{method:"POST",headers:{"Content-Type":"application/json",CEFE:"Yes",...k?{Authorization:`Bearer ${k}`}:{}},body:JSON.stringify(P)});if(!I.ok)throw new Error("Failed to generate report");const H=await I.json();if(Ae(H.data),De(g),g.reportVersion==="v2"){const M=((n=(i=ht.getState().license)==null?void 0:i.features)==null?void 0:n.ai)??!1,A={clusters:Y,timeRange:g.timeRange,timeRangeLabel:g.timeRange.type==="relative"?`Last ${g.timeRange.relative}`:`${(a=g.timeRange.absolute)==null?void 0:a.startDate} to ${(y=g.timeRange.absolute)==null?void 0:y.endDate}`},N=await Qt(A,H.data,M),be=oi(N),G=document.createElement("div");G.style.padding="20px",G.style.backgroundColor="white",G.style.width="800px",G.style.position="absolute",G.style.left="-9999px",G.style.top="0",G.style.fontFamily="'Segoe UI', system-ui, -apple-system, sans-serif",G.innerHTML=be,document.body.appendChild(G),await new Promise(R=>setTimeout(R,500));const{default:ve}=await He(()=>import("./html2canvas.esm-71958c39.js"),[]),{default:$e}=await He(()=>import("./jspdf.es.min-f37510e7.js"),["assets/jspdf.es.min-f37510e7.js","assets/index-ceb857ff.js","assets/vendor-core-b32aba80.js","assets/vendor-utils-c44f47c4.js","assets/index-07869736.css"]),se=await ve(G,{scale:1.5,useCORS:!0,backgroundColor:"#ffffff"});document.body.removeChild(G);const xe=se.toDataURL("image/jpeg",.95),Z=new $e("p","mm","a4"),we=Z.internal.pageSize.getWidth(),ne=Z.internal.pageSize.getHeight(),re=we,ae=se.height*re/se.width;let p=ae,b=0;for(Z.addImage(xe,"JPEG",0,b,re,ae),p-=ne;p>0;)b-=ne,Z.addPage(),Z.addImage(xe,"JPEG",0,b,re,ae),p-=ne;const v=`clustereye-report-v2-${new Date().toISOString().slice(0,10)}.pdf`;Z.save(v)}else await ct(H.data,g);B.success({content:"Comprehensive report generated successfully!",key:"comprehensive-report"}),l(!1)}catch{B.error({content:"Failed to generate comprehensive report",key:"comprehensive-report"})}finally{ge(!1)}},ct=async(i,n)=>{var P,I,H,M,A,N,be,G,ve,$e,se,xe,Z,we,ne,re,ae;const a=document.createElement("div");a.style.padding="20px",a.style.backgroundColor="white",a.style.width="800px",a.style.position="absolute",a.style.left="-9999px",a.style.top="0",a.style.fontFamily="Arial, sans-serif";const y=(n.clusters||[]).map(p=>p.replace("agent_","")).join(", "),g=n.timeRange.type==="relative"?`Last ${n.timeRange.relative}`:`${F(n.timeRange.absolute.startDate).format("YYYY-MM-DD HH:mm")} to ${F(n.timeRange.absolute.endDate).format("YYYY-MM-DD HH:mm")}`,k=`
            <div style="margin-bottom: 40px;">
                <h2 style="color: #1890ff; font-size: 22px; margin-bottom: 20px; padding-bottom: 10px; border-bottom: 2px solid #1890ff;">
                    Recent Alarms (Last 24 Hours)
                </h2>
                <table style="width: 100%; border-collapse: collapse; font-size: 14px;">
                    <thead>
                        <tr style="background-color: #fafafa;">
                            <th style="padding: 12px; border: 1px solid #e8e8e8; text-align: left; font-weight: bold;">Severity</th>
                            <th style="padding: 12px; border: 1px solid #e8e8e8; text-align: left; font-weight: bold;">Type</th>
                            <th style="padding: 12px; border: 1px solid #e8e8e8; text-align: left; font-weight: bold;">Host</th>
                            <th style="padding: 12px; border: 1px solid #e8e8e8; text-align: left; font-weight: bold;">Message</th>
                            <th style="padding: 12px; border: 1px solid #e8e8e8; text-align: left; font-weight: bold;">Time</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${(i.recentAlarms||[]).map(p=>`
                            <tr>
                                <td style="padding: 12px; border: 1px solid #e8e8e8;">
                                    <span style="
                                        padding: 4px 8px;
                                        border-radius: 4px;
                                        background-color: ${p.severity==="critical"?"#ff4d4f":p.severity==="warning"?"#faad14":"#1890ff"};
                                        color: white;
                                        font-size: 12px;
                                        display: inline-block;
                                    ">${p.severity.toUpperCase()}</span>
                                </td>
                                <td style="padding: 12px; border: 1px solid #e8e8e8;">${p.metric_name}</td>
                                <td style="padding: 12px; border: 1px solid #e8e8e8;">${p.agent_id.replace("agent_","")}</td>
                                <td style="padding: 12px; border: 1px solid #e8e8e8;">${p.message.length>100?p.message.substring(0,100)+"...":p.message}</td>
                                <td style="padding: 12px; border: 1px solid #e8e8e8;">${F(p.created_at).format("YYYY-MM-DD HH:mm")}</td>
                            </tr>
                        `).join("")}
                    </tbody>
                </table>
                
                <div style="margin-top: 15px; display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                    <div style="background: #fff2e8; padding: 12px; border-radius: 6px; text-align: center;">
                        <strong style="color: #fa8c16;">Total Alarms</strong>
                        <div style="font-size: 24px; font-weight: bold; color: #fa8c16; margin-top: 5px;">
                            ${(i.recentAlarms||[]).length}
                        </div>
                    </div>
                    <div style="background: #fff1f0; padding: 12px; border-radius: 6px; text-align: center;">
                        <strong style="color: #ff4d4f;">Critical Events</strong>
                        <div style="font-size: 24px; font-weight: bold; color: #ff4d4f; margin-top: 5px;">
                            ${(i.recentAlarms||[]).filter(p=>p.severity==="critical").length}
                        </div>
                    </div>
                </div>
            </div>
        `,Y=`
            <div style="max-width: 800px; margin: 0 auto; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; line-height: 1.6;">
                <!-- Header Section -->
                <div style="text-align: center; margin-bottom: 50px; padding: 30px; background: linear-gradient(135deg, #1890ff 0%, #40a9ff 100%); border-radius: 10px; color: white;">
                    <div style="background: white; display: inline-block; padding: 15px 25px; border-radius: 50px; margin-bottom: 20px;">
                        <h1 style="color: #1890ff; font-size: 36px; margin: 0; font-weight: 700;">
                            ClusterEye
                        </h1>
                    </div>
                    <h2 style="font-size: 28px; margin: 0 0 15px 0; font-weight: 600;">
                        Comprehensive Database Report
                    </h2>
                    <div style="background: rgba(255,255,255,0.2); padding: 15px; border-radius: 8px; margin: 20px 0;">
                        <p style="font-size: 16px; margin: 0;">
                            <strong>Generated:</strong> ${F().format("YYYY-MM-DD HH:mm:ss")}
                        </p>
                        <p style="font-size: 16px; margin: 5px 0 0 0;">
                            <strong>Nodes:</strong> ${y}
                        </p>
                        <p style="font-size: 16px; margin: 5px 0 0 0;">
                            <strong>Time Range:</strong> ${g}
                        </p>
                    </div>
                </div>

                <!-- Executive Summary -->
                <div style="margin-bottom: 40px; padding: 25px; background: #f8f9fa; border-radius: 10px; border-left: 5px solid #52c41a;">
                    <h2 style="color: #52c41a; font-size: 22px; margin-bottom: 15px; font-weight: 600;">
                        📊 Executive Summary
                    </h2>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                        <div>
                            <p style="font-size: 14px; color: #666; margin: 0;">Total Clusters Analyzed</p>
                            <p style="font-size: 24px; font-weight: bold; color: #1890ff; margin: 5px 0;">${(n.clusters||[]).length}</p>
                        </div>
                        <div>
                            <p style="font-size: 14px; color: #666; margin: 0;">Analysis Period</p>
                            <p style="font-size: 16px; font-weight: bold; color: #1890ff; margin: 5px 0;">${g}</p>
                        </div>
                    </div>
                    <div style="margin-top: 15px; padding: 15px; background: white; border-radius: 6px;">
                        <h4 style="margin: 0 0 10px 0; color: #262626;">Report Sections Included:</h4>
                        <div style="display: flex; flex-wrap: wrap; gap: 8px;">
                            ${n.sections.systemMetrics?'<span style="background: #e6f7ff; color: #1890ff; padding: 4px 8px; border-radius: 4px; font-size: 12px;">System Metrics</span>':""}
                            ${n.sections.diskAnalysis?'<span style="background: #e6f7ff; color: #1890ff; padding: 4px 8px; border-radius: 4px; font-size: 12px;">Disk Analysis</span>':""}
                            ${(P=n.sections.mongoAnalysis)!=null&&P.enabled?'<span style="background: #e6f7ff; color: #1890ff; padding: 4px 8px; border-radius: 4px; font-size: 12px;">MongoDB</span>':""}
                            ${(I=n.sections.postgresAnalysis)!=null&&I.enabled?'<span style="background: #e6f7ff; color: #1890ff; padding: 4px 8px; border-radius: 4px; font-size: 12px;">PostgreSQL</span>':""}
                            ${(H=n.sections.mssqlAnalysis)!=null&&H.enabled?'<span style="background: #e6f7ff; color: #1890ff; padding: 4px 8px; border-radius: 4px; font-size: 12px;">MSSQL</span>':""}
                            ${n.sections.alarmsAnalysis?'<span style="background: #e6f7ff; color: #1890ff; padding: 4px 8px; border-radius: 4px; font-size: 12px;">Alarms</span>':""}
                            ${n.sections.recommendations?'<span style="background: #e6f7ff; color: #1890ff; padding: 4px 8px; border-radius: 4px; font-size: 12px;">Capacity Planning</span>':""}
                        </div>
                    </div>
                </div>

                ${n.sections.systemMetrics?`
                    <div style="margin-bottom: 50px; padding: 25px; background: white; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); border-left: 5px solid #1890ff;">
                        <div style="display: flex; align-items: center; margin-bottom: 20px;">
                            <div style="background: #1890ff; color: white; width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-right: 15px; font-size: 18px;">
                                📊
                            </div>
                            <h2 style="color: #1890ff; font-size: 24px; margin: 0; font-weight: 600;">
                                CPU & Memory Performance
                            </h2>
                        </div>
                        <p style="margin-bottom: 20px; color: #666; font-size: 16px;">
                            CPU and Memory utilization analysis with min/max/avg statistics and trends
                        </p>
                        <div style="background: linear-gradient(135deg, #f0f9ff 0%, #e6f7ff 100%); padding: 20px; border-radius: 8px; border: 1px solid #d6f7ff;">
                            <!-- CPU Analysis Section -->
                            <div style="margin-bottom: 30px; padding: 20px; background: white; border-radius: 8px; border: 1px solid #e8f4ff;">
                                <h3 style="margin: 0 0 15px 0; color: #1890ff; font-size: 18px; font-weight: 600;">🖥️ CPU Performance</h3>
                                ${(()=>{var u,m,T;const p=((u=i.capacityPlanning)==null?void 0:u.cpuTrends)||[];if(p.length===0)return'<div style="color: #ff4d4f;">❌ No CPU data available</div>';const b=p.map(c=>c._value).filter(c=>c!=null);if(b.length===0)return'<div style="color: #ff4d4f;">❌ No valid CPU data</div>';const v=Math.min(...b),R=Math.max(...b),d=b.reduce((c,E)=>c+E,0)/b.length,x=p.find(c=>c._value===v),C=p.find(c=>c._value===R);return`
                                        <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 15px; margin-bottom: 20px;">
                                            <div style="text-align: center; padding: 12px; background: #f0f9ff; border-radius: 6px;">
                                                <p style="margin: 0; color: #666; font-size: 12px;">Minimum</p>
                                                <p style="margin: 5px 0 0 0; font-size: 20px; font-weight: bold; color: #52c41a;">${v.toFixed(1)}%</p>
                                                <p style="margin: 5px 0 0 0; font-size: 10px; color: #999;">${x?new Date(x._time).toLocaleString():"N/A"}</p>
                                            </div>
                                            <div style="text-align: center; padding: 12px; background: #fff7e6; border-radius: 6px;">
                                                <p style="margin: 0; color: #666; font-size: 12px;">Average</p>
                                                <p style="margin: 5px 0 0 0; font-size: 20px; font-weight: bold; color: #fa8c16;">${d.toFixed(1)}%</p>
                                                <p style="margin: 5px 0 0 0; font-size: 10px; color: #999;">${p.length} data points</p>
                                            </div>
                                            <div style="text-align: center; padding: 12px; background: #fff1f0; border-radius: 6px;">
                                                <p style="margin: 0; color: #666; font-size: 12px;">Maximum</p>
                                                <p style="margin: 5px 0 0 0; font-size: 20px; font-weight: bold; color: #ff4d4f;">${R.toFixed(1)}%</p>
                                                <p style="margin: 5px 0 0 0; font-size: 10px; color: #999;">${C?new Date(C._time).toLocaleString():"N/A"}</p>
                                            </div>
                                        </div>
                                        <div style="height: 100px; background: linear-gradient(135deg, #f0f9ff 0%, #e6f7ff 100%); border-radius: 6px; padding: 15px; position: relative; overflow: hidden;">
                                            ${p.slice(-15).map((c,E)=>{const U=c._value/R*70;return`<div style="position: absolute; bottom: 15px; left: ${15+E*(750/15)}px; width: 4px; height: ${U}px; background: #1890ff; border-radius: 2px;" title="${c._value}% at ${new Date(c._time).toLocaleString()}"></div>`}).join("")}
                                            <div style="position: absolute; bottom: 5px; right: 15px; font-size: 10px; color: #999;">Latest: ${((T=(m=p.slice(-1)[0])==null?void 0:m._value)==null?void 0:T.toFixed(1))||0}%</div>
                                            <div style="position: absolute; bottom: 5px; left: 15px; font-size: 10px; color: #999;">15 points timeline</div>
                                        </div>
                                    `})()}
                            </div>
                            
                            <!-- Memory Analysis Section -->
                            <div style="margin-bottom: 30px; padding: 20px; background: white; border-radius: 8px; border: 1px solid #f6ffed;">
                                <h3 style="margin: 0 0 15px 0; color: #52c41a; font-size: 18px; font-weight: 600;">🧠 Memory Performance</h3>
                                ${(()=>{var E,U,J,de,O;let p=((U=(E=i.capacityPlanning)==null?void 0:E.memoryTrends)==null?void 0:U.filter(S=>S._field==="memory_usage"||S._field==="free_memory"))||[];if(p.length===0&&(p=((J=i.memoryTrends)==null?void 0:J.filter(S=>S._field==="memory_usage"||S._field==="free_memory"))||[]),p.length===0)return'<div style="color: #ff4d4f;">❌ No Memory data available</div>';const b=p.map(S=>S._value).filter(S=>S!=null);if(b.length===0)return'<div style="color: #ff4d4f;">❌ No valid Memory data</div>';const v=Math.min(...b),R=Math.max(...b),d=b.reduce((S,ke)=>S+ke,0)/b.length,x=p.find(S=>S._value===v),C=p.find(S=>S._value===R),u=((de=p[0])==null?void 0:de._field)||"",m=Math.max(...b),T=u==="memory_usage"&&m<=100&&Math.min(...b)>=0,c=S=>T?S.toFixed(1)+"%":S>1024*1024*1024?(S/1024/1024/1024).toFixed(1)+" GB":S>1024*1024?(S/1024/1024).toFixed(1)+" MB":S.toFixed(1)+" MB";return`
                                        <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 15px; margin-bottom: 20px;">
                                            <div style="text-align: center; padding: 12px; background: #f0f9ff; border-radius: 6px;">
                                                <p style="margin: 0; color: #666; font-size: 12px;">Minimum</p>
                                                <p style="margin: 5px 0 0 0; font-size: 20px; font-weight: bold; color: #52c41a;">${c(v)}</p>
                                                <p style="margin: 5px 0 0 0; font-size: 10px; color: #999;">${x?new Date(x._time).toLocaleString():"N/A"}</p>
                                            </div>
                                            <div style="text-align: center; padding: 12px; background: #fff7e6; border-radius: 6px;">
                                                <p style="margin: 0; color: #666; font-size: 12px;">Average</p>
                                                <p style="margin: 5px 0 0 0; font-size: 20px; font-weight: bold; color: #fa8c16;">${c(d)}</p>
                                                <p style="margin: 5px 0 0 0; font-size: 10px; color: #999;">${p.length} data points</p>
                                            </div>
                                            <div style="text-align: center; padding: 12px; background: #fff1f0; border-radius: 6px;">
                                                <p style="margin: 0; color: #666; font-size: 12px;">Maximum</p>
                                                <p style="margin: 5px 0 0 0; font-size: 20px; font-weight: bold; color: #ff4d4f;">${c(R)}</p>
                                                <p style="margin: 5px 0 0 0; font-size: 10px; color: #999;">${C?new Date(C._time).toLocaleString():"N/A"}</p>
                                            </div>
                                        </div>
                                        <div style="height: 100px; background: linear-gradient(135deg, #f6ffed 0%, #e6ffe6 100%); border-radius: 6px; padding: 15px; position: relative; overflow: hidden;">
                                            ${p.slice(-15).map((S,ke)=>{const Me=S._value/R*70,yt=15+ke*(750/15),ft=T?S._value.toFixed(1)+"%":(S._value/1024/1024/1024).toFixed(1)+" GB";return`<div style="position: absolute; bottom: 15px; left: ${yt}px; width: 4px; height: ${Me}px; background: #52c41a; border-radius: 2px;" title="${ft} at ${new Date(S._time).toLocaleString()}"></div>`}).join("")}
                                            <div style="position: absolute; bottom: 5px; right: 15px; font-size: 10px; color: #999;">Latest: ${c(((O=p.slice(-1)[0])==null?void 0:O._value)||0)}</div>
                                            <div style="position: absolute; bottom: 5px; left: 15px; font-size: 10px; color: #999;">15 points timeline</div>
                                        </div>
                                    `})()}
                            </div>
                        </div>
                    </div>

                ${i.mongoAnalysis?`
                                <div style="margin-top: 20px; padding: 15px; background: white; border-radius: 6px; border: 1px solid #d9d9d9;">
                                    <h4 style="margin: 0 0 15px 0; color: #333;">MongoDB Analysis Results</h4>
                                    ${Object.entries(i.mongoAnalysis).map(([p,b])=>`
                                        <div style="margin-bottom: 20px; padding: 15px; background: #f8f8f8; border-radius: 4px;">
                                            <strong style="color: #52c41a; font-size: 16px;">${p.replace("agent_","")}:</strong>
                                            
                                            ${b.collections?(()=>{try{const v=JSON.parse(atob(b.collections.value));return v.status==="success"?`
                                                            <div style="margin-top: 12px; padding: 10px; background: white; border-radius: 4px;">
                                                                <strong>🗃️ Databases:</strong>
                                                                <div style="margin-top: 8px; font-size: 11px;">
                                                                    ${(v.data||[]).slice(0,5).map(R=>`
                                                                        <span style="display: inline-block; margin: 2px 4px; padding: 2px 6px; background: #e6fffb; border-radius: 2px;">
                                                                            ${R.name}: ${R.sizeOnDisk?Math.round(R.sizeOnDisk/1024/1024)+"MB":"N/A"}
                                                                        </span>
                                                                    `).join("")}
                                                                </div>
                                                            </div>
                                                        `:`<div style="margin-top: 8px; color: #ff4d4f; font-size: 11px;">❌ ${v.message}</div>`}catch{}return'<div style="margin-top: 8px; color: #999;">🗃️ Collections: Processing...</div>'})():'<div style="margin-top: 8px; color: #999;">🗃️ Collections: N/A</div>'}
                                            
                                            ${b.indexUsage?(()=>{try{const v=JSON.parse(atob(b.indexUsage.value));return v.status==="success"?`
                                                            <div style="margin-top: 12px; padding: 10px; background: white; border-radius: 4px;">
                                                                <strong>📇 Index Analysis:</strong>
                                                                <div style="margin-top: 8px; font-size: 11px; color: #52c41a;">
                                                                    ✅ Index usage statistics analyzed
                                                                </div>
                                                            </div>
                                                        `:`<div style="margin-top: 8px; color: #ff4d4f; font-size: 11px;">❌ ${v.message}</div>`}catch{}return'<div style="margin-top: 8px; color: #999;">📇 Indexes: Processing...</div>'})():'<div style="margin-top: 8px; color: #999;">📇 Indexes: N/A</div>'}
                                            
                                            ${b.performance?(()=>{try{const v=JSON.parse(atob(b.performance.value));return v.status==="success"?`
                                                            <div style="margin-top: 12px; padding: 10px; background: white; border-radius: 4px;">
                                                                <strong>⚡ Performance Metrics:</strong>
                                                                <div style="margin-top: 8px; font-size: 11px; color: #52c41a;">
                                                                    ✅ Performance analysis completed
                                                                </div>
                                                            </div>
                                                        `:`<div style="margin-top: 8px; color: #ff4d4f; font-size: 11px;">❌ ${v.message}</div>`}catch{}return'<div style="margin-top: 8px; color: #999;">⚡ Performance: Processing...</div>'})():'<div style="margin-top: 8px; color: #999;">⚡ Performance: N/A</div>'}
                                        </div>
                                    `).join("")}
                                </div>
                            `:""}
                        </div>
                    </div>
                `:""}

                ${n.sections.diskAnalysis?`
                    <div style="margin-bottom: 50px; padding: 25px; background: white; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); border-left: 5px solid #fa8c16;">
                        <div style="display: flex; align-items: center; margin-bottom: 20px;">
                            <div style="background: #fa8c16; color: white; width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-right: 15px; font-size: 18px;">
                                💾
                            </div>
                            <h2 style="color: #fa8c16; font-size: 24px; margin: 0; font-weight: 600;">
                                Disk Analysis & Capacity Planning
                            </h2>
                        </div>
                        <p style="margin-bottom: 20px; color: #666; font-size: 16px;">
                            Storage utilization patterns, growth trends, and filesystem analysis
                        </p>
                        <div style="background: linear-gradient(135deg, #fff7e6 0%, #ffeee6 100%); padding: 20px; border-radius: 8px; border: 1px solid #ffd6b8;">
                            <div style="background: rgba(250, 140, 22, 0.1); padding: 12px; border-radius: 6px;">
                                <p style="margin: 0; font-size: 14px; color: #fa8c16;"><strong>💽 Storage Data:</strong> ${i.diskAnalysis?Object.keys(i.diskAnalysis).length:0} metrics collected</p>
                                <p style="margin: 8px 0 0 0; font-size: 14px; color: #666;"><em>Disk utilization trends, filesystem details, and growth projections analyzed</em></p>
                            </div>
                        </div>
                    </div>
                `:""}

                ${(M=n.sections.mongoAnalysis)!=null&&M.enabled?`
                    <div style="margin-bottom: 50px; padding: 25px; background: white; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); border-left: 5px solid #52c41a;">
                        <div style="display: flex; align-items: center; margin-bottom: 20px;">
                            <div style="background: #52c41a; color: white; width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-right: 15px; font-size: 18px;">
                                🍃
                            </div>
                            <h2 style="color: #52c41a; font-size: 24px; margin: 0; font-weight: 600;">
                                MongoDB Analysis
                            </h2>
                        </div>
                        <p style="margin-bottom: 20px; color: #666; font-size: 16px;">
                            ${n.sections.mongoAnalysis.includeCollections?"Collections, ":""}
                            ${n.sections.mongoAnalysis.includeIndexes?"Indexes, ":""}
                            ${n.sections.mongoAnalysis.includePerformance?"Performance ":""}
                            analysis for MongoDB clusters
                        </p>
                        <div style="background: linear-gradient(135deg, #f6ffed 0%, #e6f7ff 100%); padding: 20px; border-radius: 8px; border: 1px solid #b7eb8f;">
                            <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 15px; margin-bottom: 15px;">
                                ${n.sections.mongoAnalysis.includeCollections?`
                                    <div style="background: white; padding: 15px; border-radius: 6px; text-align: center;">
                                        <p style="margin: 0; color: #666; font-size: 14px;">Collections</p>
                                        <p style="margin: 5px 0 0 0; font-size: 16px; font-weight: bold; color: #52c41a;">
                                            ${i.mongoAnalysis?"✅ Analyzed":"❌ No Data"}
                                        </p>
                                    </div>
                                `:""}
                                ${n.sections.mongoAnalysis.includeIndexes?`
                                    <div style="background: white; padding: 15px; border-radius: 6px; text-align: center;">
                                        <p style="margin: 0; color: #666; font-size: 14px;">Indexes</p>
                                        <p style="margin: 5px 0 0 0; font-size: 16px; font-weight: bold; color: #52c41a;">
                                            ${i.mongoAnalysis?"✅ Analyzed":"❌ No Data"}
                                        </p>
                                    </div>
                                `:""}
                                ${n.sections.mongoAnalysis.includePerformance?`
                                    <div style="background: white; padding: 15px; border-radius: 6px; text-align: center;">
                                        <p style="margin: 0; color: #666; font-size: 14px;">Performance</p>
                                        <p style="margin: 5px 0 0 0; font-size: 16px; font-weight: bold; color: #52c41a;">
                                            ${i.mongoAnalysis?"✅ Analyzed":"❌ No Data"}
                                        </p>
                                    </div>
                                `:""}
                            </div>
                        </div>
                    </div>
                `:""}

                ${(A=n.sections.postgresAnalysis)!=null&&A.enabled?`
                    <div style="margin-bottom: 50px; padding: 25px; background: white; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); border-left: 5px solid #1890ff;">
                        <div style="display: flex; align-items: center; margin-bottom: 20px;">
                            <div style="background: #1890ff; color: white; width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-right: 15px; font-size: 18px;">
                                🐘
                            </div>
                            <h2 style="color: #1890ff; font-size: 24px; margin: 0; font-weight: 600;">
                                PostgreSQL Analysis
                            </h2>
                        </div>
                        <p style="margin-bottom: 20px; color: #666; font-size: 16px;">
                            Bloat analysis, top queries, and connection statistics for PostgreSQL clusters
                        </p>
                        <div style="background: linear-gradient(135deg, #f0f9ff 0%, #e6f7ff 100%); padding: 20px; border-radius: 8px; border: 1px solid #d6f7ff;">
                            
                            ${i.postgresAnalysis?`
                                <div style="margin-top: 20px; padding: 15px; background: white; border-radius: 6px; border: 1px solid #d9d9d9;">
                                    <h4 style="margin: 0 0 15px 0; color: #333;">PostgreSQL Analysis Results</h4>
                                    ${Object.entries(i.postgresAnalysis).map(([p,b])=>`
                                        <div style="margin-bottom: 20px; padding: 15px; background: #f8f8f8; border-radius: 4px;">
                                            <strong style="color: #1890ff; font-size: 16px;">${p.replace("agent_","")}:</strong>
                                            
                                            ${b.connectionStats?(()=>{try{const v=JSON.parse(atob(b.connectionStats.value));if(v.status==="success")return`
                                                            <div style="margin-top: 12px; padding: 10px; background: white; border-radius: 4px;">
                                                                <strong>🔗 Connection Analysis:</strong>
                                                                <div style="margin-top: 8px; display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 8px; font-size: 11px;">
                                                                    <span>Idle: ${v.count_0||0}</span>
                                                                    <span>Active: ${v.count_1||0}</span>
                                                                    <span>Total: ${(v.count_0||0)+(v.count_1||0)}</span>
                                                                </div>
                                                            </div>
                                                        `}catch{}return'<div style="margin-top: 8px; color: #999;">🔗 Connections: Processing...</div>'})():'<div style="margin-top: 8px; color: #999;">🔗 Connections: N/A</div>'}
                                            
                                            ${b.tableBloat?(()=>{try{const v=JSON.parse(atob(b.tableBloat.value));if(v.status==="success")return`
                                                            <div style="margin-top: 12px; padding: 10px; background: white; border-radius: 4px;">
                                                                <strong>📊 Table Sizes (Top 5):</strong>
                                                                <div style="margin-top: 8px; font-size: 11px;">
                                                                    ${(v.data||[]).slice(0,5).map(R=>`
                                                                        <div style="margin: 2px 0; padding: 2px 0;">
                                                                            ${R.schemaname}.${R.tablename}: ${R.size}
                                                                        </div>
                                                                    `).join("")}
                                                                </div>
                                                            </div>
                                                        `}catch{}return'<div style="margin-top: 8px; color: #999;">📊 Table Analysis: Processing...</div>'})():'<div style="margin-top: 8px; color: #999;">📊 Table Analysis: N/A</div>'}
                                            
                                            ${b.topQueries?(()=>{try{const v=JSON.parse(atob(b.topQueries.value));if(v.status==="success")return`
                                                            <div style="margin-top: 12px; padding: 10px; background: white; border-radius: 4px;">
                                                                <strong>🔍 Active Queries:</strong>
                                                                <div style="margin-top: 8px; font-size: 11px;">
                                                                    ${(v.data||[]).slice(0,3).map(R=>{var d;return`
                                                                        <div style="margin: 4px 0; padding: 4px; background: #f0f0f0; border-radius: 2px;">
                                                                            <strong>${R.usename}</strong>: ${(R.query||"").substring(0,80)}${((d=R.query)==null?void 0:d.length)>80?"...":""}
                                                                            <br><span style="color: #666;">State: ${R.state}</span>
                                                                        </div>
                                                                    `}).join("")}
                                                                </div>
                                                            </div>
                                                        `}catch{}return'<div style="margin-top: 8px; color: #999;">🔍 Queries: Processing...</div>'})():'<div style="margin-top: 8px; color: #999;">🔍 Queries: N/A</div>'}
                                        </div>
                                    `).join("")}
                                </div>
                            `:""}
                        </div>
                    </div>
                `:""}

                ${(N=n.sections.mssqlAnalysis)!=null&&N.enabled?`
                    <div style="margin-bottom: 50px; padding: 25px; background: white; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); border-left: 5px solid #722ed1;">
                        <div style="display: flex; align-items: center; margin-bottom: 20px;">
                            <div style="background: #722ed1; color: white; width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-right: 15px; font-size: 18px;">
                                🗄️
                            </div>
                            <h2 style="color: #722ed1; font-size: 24px; margin: 0; font-weight: 600;">
                                MSSQL Analysis
                            </h2>
                        </div>
                        <p style="margin-bottom: 20px; color: #666; font-size: 16px;">
                            ${n.sections.mssqlAnalysis.includeCapacityPlanning?"Capacity planning, ":""}
                            ${n.sections.mssqlAnalysis.includePerformance?"Performance ":""}
                            analysis for MSSQL Server clusters
                        </p>
                        <div style="background: linear-gradient(135deg, #f9f0ff 0%, #f0e6ff 100%); padding: 20px; border-radius: 8px; border: 1px solid #d3adf7;">
                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 15px;">
                                ${n.sections.mssqlAnalysis.includeCapacityPlanning?`
                                    <div style="background: white; padding: 15px; border-radius: 6px; text-align: center;">
                                        <p style="margin: 0; color: #666; font-size: 14px;">Capacity Planning</p>
                                        <p style="margin: 5px 0 0 0; font-size: 16px; font-weight: bold; color: #722ed1;">
                                            ${(be=i.mssqlAnalysis)!=null&&be.capacity?"✅ Analyzed":"📊 Ready"}
                                        </p>
                                    </div>
                                `:""}
                                ${n.sections.mssqlAnalysis.includePerformance?`
                                    <div style="background: white; padding: 15px; border-radius: 6px; text-align: center;">
                                        <p style="margin: 0; color: #666; font-size: 14px;">Performance</p>
                                        <p style="margin: 5px 0 0 0; font-size: 16px; font-weight: bold; color: #722ed1;">
                                            ${(G=i.mssqlAnalysis)!=null&&G.performance?"✅ Analyzed":"📊 Ready"}
                                        </p>
                                    </div>
                                `:""}
                            </div>
                            <div style="background: rgba(114, 46, 209, 0.1); padding: 12px; border-radius: 6px;">
                                <p style="margin: 0; font-size: 14px; color: #722ed1;"><strong>🗄️ MSSQL Data:</strong> Connection patterns and performance metrics analyzed</p>
                            </div>
                        </div>
                    </div>
                `:""}

                ${(ve=n.sections.postgresAnalysis)!=null&&ve.enabled?`
                    <div style="margin-bottom: 50px; padding: 25px; background: white; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); border-left: 5px solid #1890ff;">
                        <div style="display: flex; align-items: center; margin-bottom: 20px;">
                            <div style="background: #1890ff; color: white; width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-right: 15px; font-size: 18px;">
                                🐘
                            </div>
                            <h2 style="color: #1890ff; font-size: 24px; margin: 0; font-weight: 600;">
                                PostgreSQL Analysis
                            </h2>
                        </div>
                        <p style="margin-bottom: 20px; color: #666; font-size: 16px;">
                            ${n.sections.postgresAnalysis.includeBloat?"Bloat analysis, ":""}
                            ${n.sections.postgresAnalysis.includeSlowQueries?"Slow queries, ":""}
                            ${n.sections.postgresAnalysis.includeConnections?"Connections ":""}
                            analysis for PostgreSQL clusters
                        </p>
                        <div style="background: linear-gradient(135deg, #e6f7ff 0%, #f0f9ff 100%); padding: 20px; border-radius: 8px; border: 1px solid #91d5ff;">
                            <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 15px; margin-bottom: 15px;">
                                ${n.sections.postgresAnalysis.includeBloat?`
                                    <div style="background: white; padding: 15px; border-radius: 6px; text-align: center;">
                                        <p style="margin: 0; color: #666; font-size: 14px;">Table/Index Bloat</p>
                                        <p style="margin: 5px 0 0 0; font-size: 16px; font-weight: bold; color: #1890ff;">
                                            ${($e=i.postgresAnalysis)!=null&&$e.bloat?"✅ Analyzed":"📊 Ready"}
                                        </p>
                                    </div>
                                `:""}
                                ${n.sections.postgresAnalysis.includeSlowQueries?`
                                    <div style="background: white; padding: 15px; border-radius: 6px; text-align: center;">
                                        <p style="margin: 0; color: #666; font-size: 14px;">Slow Queries</p>
                                        <p style="margin: 5px 0 0 0; font-size: 16px; font-weight: bold; color: #1890ff;">
                                            ${(se=i.postgresAnalysis)!=null&&se.slowQueries?"✅ Analyzed":"📊 Ready"}
                                        </p>
                                    </div>
                                `:""}
                                ${n.sections.postgresAnalysis.includeConnections?`
                                    <div style="background: white; padding: 15px; border-radius: 6px; text-align: center;">
                                        <p style="margin: 0; color: #666; font-size: 14px;">Connections</p>
                                        <p style="margin: 5px 0 0 0; font-size: 16px; font-weight: bold; color: #1890ff;">
                                            ${(xe=i.postgresAnalysis)!=null&&xe.connections?"✅ Analyzed":"📊 Ready"}
                                        </p>
                                    </div>
                                `:""}
                            </div>
                            <div style="background: rgba(24, 144, 255, 0.1); padding: 12px; border-radius: 6px;">
                                <p style="margin: 0; font-size: 14px; color: #1890ff;"><strong>🐘 PostgreSQL Data:</strong> Performance and optimization insights collected</p>
                            </div>
                        </div>
                    </div>
                `:""}

                ${n.sections.alarmsAnalysis?`
                    <div style="margin-bottom: 50px; padding: 25px; background: white; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); border-left: 5px solid #ff4d4f;">
                        <div style="display: flex; align-items: center; margin-bottom: 20px;">
                            <div style="background: #ff4d4f; color: white; width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-right: 15px; font-size: 18px;">
                                🚨
                            </div>
                            <h2 style="color: #ff4d4f; font-size: 24px; margin: 0; font-weight: 600;">
                                Alarms & Monitoring
                            </h2>
                        </div>
                        <p style="margin-bottom: 20px; color: #666; font-size: 16px;">
                            Alarm statistics, trends, and critical events for the selected time period
                        </p>
                        <div style="background: linear-gradient(135deg, #fff1f0 0%, #ffebe6 100%); padding: 20px; border-radius: 8px; border: 1px solid #ffb3b3;">
                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 15px;">
                                <div style="background: white; padding: 15px; border-radius: 6px; text-align: center;">
                                    <p style="margin: 0; color: #666; font-size: 14px;">Total Alarms</p>
                                    <p style="margin: 5px 0 0 0; font-size: 20px; font-weight: bold; color: #ff4d4f;">
                                        ${i.alarmsData?Object.keys(i.alarmsData).length:0}
                                    </p>
                                </div>
                                <div style="background: white; padding: 15px; border-radius: 6px; text-align: center;">
                                    <p style="margin: 0; color: #666; font-size: 14px;">Critical Events</p>
                                    <p style="margin: 5px 0 0 0; font-size: 20px; font-weight: bold; color: #ff4d4f;">
                                        ${i.alarmsData?"📊 Tracked":"⏳ Pending"}
                                    </p>
                                </div>
                            </div>
                            <div style="background: rgba(255, 77, 79, 0.1); padding: 12px; border-radius: 6px;">
                                <p style="margin: 0; font-size: 14px; color: #ff4d4f;"><strong>🚨 Monitoring Data:</strong> Alarm patterns and severity trends analyzed</p>
                            </div>
                            
                            ${k}
                        </div>
                    </div>
                `:""}

                ${n.sections.recommendations?`
                    <div style="margin-bottom: 50px; padding: 25px; background: white; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); border-left: 5px solid #722ed1;">
                        <div style="display: flex; align-items: center; margin-bottom: 20px;">
                            <div style="background: #722ed1; color: white; width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-right: 15px; font-size: 18px;">
                                📈
                            </div>
                            <h2 style="color: #722ed1; font-size: 24px; margin: 0; font-weight: 600;">
                                Capacity Planning & Recommendations
                            </h2>
                        </div>
                        <p style="margin-bottom: 20px; color: #666; font-size: 16px;">
                            Resource utilization trends, growth projections, and optimization recommendations
                        </p>
                        <div style="background: linear-gradient(135deg, #f9f0ff 0%, #f0e6ff 100%); padding: 20px; border-radius: 8px; border: 1px solid #d3adf7;">
                            <div style="display: grid; grid-template-columns: 1fr 1fr 1fr 1fr 1fr; gap: 12px; margin-bottom: 15px;">
                                <div style="background: white; padding: 12px; border-radius: 6px; text-align: center;">
                                    <p style="margin: 0; color: #666; font-size: 12px;">Disk Growth</p>
                                    <p style="margin: 3px 0 0 0; font-size: 14px; font-weight: bold; color: #722ed1;">
                                        ${(Z=i.capacityPlanning)!=null&&Z.diskTrends?`${i.capacityPlanning.diskTrends.length} trends`:"❌ No Data"}
                                    </p>
                                </div>
                                <div style="background: white; padding: 12px; border-radius: 6px; text-align: center;">
                                    <p style="margin: 0; color: #666; font-size: 12px;">Memory</p>
                                    <p style="margin: 3px 0 0 0; font-size: 14px; font-weight: bold; color: #722ed1;">
                                        ${(we=i.capacityPlanning)!=null&&we.memoryTrends?`${i.capacityPlanning.memoryTrends.length} trends`:"❌ No Data"}
                                    </p>
                                </div>
                                <div style="background: white; padding: 12px; border-radius: 6px; text-align: center;">
                                    <p style="margin: 0; color: #666; font-size: 12px;">CPU</p>
                                    <p style="margin: 3px 0 0 0; font-size: 14px; font-weight: bold; color: #722ed1;">
                                        ${(ne=i.capacityPlanning)!=null&&ne.cpuTrends?`${i.capacityPlanning.cpuTrends.length} trends`:"❌ No Data"}
                                    </p>
                                </div>
                                <div style="background: white; padding: 12px; border-radius: 6px; text-align: center;">
                                    <p style="margin: 0; color: #666; font-size: 12px;">Connections</p>
                                    <p style="margin: 3px 0 0 0; font-size: 14px; font-weight: bold; color: #722ed1;">
                                        ${(re=i.capacityPlanning)!=null&&re.connectionTrends?"📊":"⏳"}
                                    </p>
                                </div>
                                <div style="background: white; padding: 12px; border-radius: 6px; text-align: center;">
                                    <p style="margin: 0; color: #666; font-size: 12px;">DB Size</p>
                                    <p style="margin: 3px 0 0 0; font-size: 14px; font-weight: bold; color: #722ed1;">
                                        ${(ae=i.capacityPlanning)!=null&&ae.databaseSizeTrends?"📊":"⏳"}
                                    </p>
                                </div>
                            </div>
                            <div style="background: rgba(114, 46, 209, 0.1); padding: 12px; border-radius: 6px;">
                                <p style="margin: 0; font-size: 14px; color: #722ed1;"><strong>📈 Forecasting:</strong> Trend analysis and capacity recommendations generated</p>
                            </div>
                            
                            ${i.capacityPlanning?`
                                <div style="margin-top: 20px; padding: 15px; background: white; border-radius: 6px; border: 1px solid #d9d9d9;">
                                    <h4 style="margin: 0 0 15px 0; color: #333;">Capacity Planning Metrics</h4>
                                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                                        ${i.capacityPlanning.diskTrends?`
                                            <div style="padding: 10px; background: #f8f8f8; border-radius: 4px;">
                                                <strong>💾 Disk Trends:</strong> ${i.capacityPlanning.diskTrends.length} data points
                                                ${i.capacityPlanning.diskTrends.slice(0,3).map(p=>{var b,v;return`
                                                    <div style="font-size: 11px; margin-top: 4px; color: #666;">
                                                        ${(b=p.agent_id)==null?void 0:b.replace("agent_","")}: ${(v=p._field)!=null&&v.includes("disk")?Math.round((p._value||0)/1024/1024/1024*100)/100+" GB":Math.round(p._value||0)+"%"}
                                                    </div>
                                                `}).join("")}
                                            </div>
                                        `:""}
                                        ${i.capacityPlanning.cpuTrends?`
                                            <div style="padding: 10px; background: #f8f8f8; border-radius: 4px;">
                                                <strong>⚡ CPU Trends:</strong> ${i.capacityPlanning.cpuTrends.length} data points
                                                ${i.capacityPlanning.cpuTrends.slice(0,3).map(p=>{var b;return`
                                                    <div style="font-size: 11px; margin-top: 4px; color: #666;">
                                                        ${(b=p.agent_id)==null?void 0:b.replace("agent_","")}: ${Math.round(p._value||0)}%
                                                    </div>
                                                `}).join("")}
                                            </div>
                                        `:""}
                                        ${i.capacityPlanning.connectionTrends?`
                                            <div style="padding: 10px; background: #f8f8f8; border-radius: 4px;">
                                                <strong>🔗 Connection Analysis:</strong> ${i.capacityPlanning.connectionTrends.length} data points
                                                <div style="margin-top: 8px;">
                                                    ${(()=>{var R,d,x,C,u,m,T;const p=i.capacityPlanning.connectionTrends.filter(c=>c._field==="available"),b=i.capacityPlanning.connectionTrends.filter(c=>c._field==="total"),v=i.capacityPlanning.connectionTrends.filter(c=>c._field==="max_connections");return`
                                                            <div style="font-size: 11px; line-height: 1.4;">
                                                                ${p.length>0?`<div>📊 Available: ${Math.round(((R=p.slice(-1)[0])==null?void 0:R._value)||0)}</div>`:""}
                                                                ${b.length>0?`<div>🔢 Current: ${Math.round(((d=b.slice(-1)[0])==null?void 0:d._value)||0)}</div>`:""}
                                                                ${v.length>0?`<div>🏁 Max: ${Math.round(((x=v.slice(-1)[0])==null?void 0:x._value)||0)}</div>`:""}
                                                                ${b.length>0&&v.length>0?`<div style="color: ${((C=b.slice(-1)[0])==null?void 0:C._value)/((u=v.slice(-1)[0])==null?void 0:u._value)>.8?"#ff4d4f":"#52c41a"};">📈 Usage: ${Math.round(((m=b.slice(-1)[0])==null?void 0:m._value)/((T=v.slice(-1)[0])==null?void 0:T._value)*100)}%</div>`:""}
                                                            </div>
                                                        `})()}
                                                </div>
                                            </div>
                                        `:""}
                                    </div>
                                </div>
                            `:""}
                        </div>
                    </div>
                `:""}
            </div>
        `;a.innerHTML=Y,document.body.appendChild(a),await new Promise(p=>setTimeout(p,1e3));try{const p=new Ke("p","pt","a4"),b=await Ze(a,{scale:1.5,useCORS:!0,backgroundColor:"#ffffff",windowWidth:800}),v=b.toDataURL("image/jpeg",1),R=p.internal.pageSize.getWidth(),d=p.internal.pageSize.getHeight(),x=b.width,C=b.height,u=R/x;let m=C*u,T=0,c=1;for(p.addImage(v,"JPEG",0,T,R,C*u);m>=d;)T=-d*c,p.addPage(),p.addImage(v,"JPEG",0,T,R,C*u),m-=d,c++;p.save(`comprehensive-report-${F().format("YYYY-MM-DD-HH-mm")}.pdf`)}finally{document.body.removeChild(a)}},gt=(i,n)=>{var H;const a=[],y=F().format("YYYY-MM-DD HH:mm:ss"),g=(n.clusters||[]).map(M=>M.replace("agent_","")).join(", ");a.push(["ClusterEye Comprehensive Report"]),a.push(["Generated",y]),a.push(["Nodes",g]),a.push(["Time Range",n.timeRange.type==="relative"?`Last ${n.timeRange.relative}`:`${F(n.timeRange.absolute.startDate).format("YYYY-MM-DD HH:mm")} to ${F(n.timeRange.absolute.endDate).format("YYYY-MM-DD HH:mm")}`]),a.push([]),n.sections.systemMetrics&&i.systemMetrics&&(a.push(["System Performance Metrics"]),a.push(["Metric Type","Value","Timestamp"]),Object.entries(i.systemMetrics).forEach(([M,A])=>{Array.isArray(A)&&A.forEach(N=>{a.push([M,N.value||"",N.timestamp||""])})}),a.push([])),n.sections.diskAnalysis&&i.diskAnalysis&&(a.push(["Disk Analysis"]),a.push(["Filesystem","Mount Point","Used %","Total GB","Timestamp"]),Object.entries(i.diskAnalysis).forEach(([M,A])=>{Array.isArray(A)&&A.forEach(N=>{a.push([N.filesystem||"",N.mount_point||"",N.used_percent||"",N.total_gb||"",N.timestamp||""])})}),a.push([])),(H=n.sections.mongoAnalysis)!=null&&H.enabled&&i.mongoAnalysis&&(a.push(["MongoDB Analysis"]),i.mongoAnalysis.collections&&(a.push(["Collections","Document Count","Size MB"]),i.mongoAnalysis.collections.forEach(M=>{a.push([M.name||"",M.count||"",M.size||""])}),a.push([])),i.mongoAnalysis.indexes&&(a.push(["Indexes","Size MB","Usage"]),i.mongoAnalysis.indexes.forEach(M=>{a.push([M.name||"",M.size||"",M.accesses||""])}),a.push([]))),n.sections.alarmsAnalysis&&i.alarmsData&&(a.push(["Alarms Analysis"]),a.push(["Alarm Type","Count","Severity"]),Object.entries(i.alarmsData).forEach(([M,A])=>{a.push([M,A.count||"",A.severity||""])}),a.push([]));const k=a.map(M=>M.map(A=>`"${(A||"").toString().replace(/"/g,'""')}"`).join(",")).join(`
`),Y=new Blob([k],{type:"text/csv;charset=utf-8;"}),P=document.createElement("a"),I=URL.createObjectURL(Y);P.setAttribute("href",I),P.setAttribute("download",`comprehensive-report-${F().format("YYYY-MM-DD-HH-mm")}.csv`),P.style.visibility="hidden",document.body.appendChild(P),P.click(),document.body.removeChild(P)},mt=async(i,n)=>{var a;try{const y=await He(()=>import("./xlsx-fc9dd0d2.js"),[]),g=y.utils.book_new(),k=(n.clusters||[]).map(I=>I.replace("agent_","")).join(", "),Y=[["ClusterEye Comprehensive Report"],["Generated",F().format("YYYY-MM-DD HH:mm:ss")],["Nodes",k],["Time Range",n.timeRange.type==="relative"?`Last ${n.timeRange.relative}`:`${F(n.timeRange.absolute.startDate).format("YYYY-MM-DD HH:mm")} to ${F(n.timeRange.absolute.endDate).format("YYYY-MM-DD HH:mm")}`]],P=y.utils.aoa_to_sheet(Y);if(y.utils.book_append_sheet(g,P,"Summary"),n.sections.systemMetrics&&i.systemMetrics){const I=[["Metric Type","Value","Timestamp"]];Object.entries(i.systemMetrics).forEach(([M,A])=>{Array.isArray(A)&&A.forEach(N=>{I.push([M,N.value||"",N.timestamp||""])})});const H=y.utils.aoa_to_sheet(I);y.utils.book_append_sheet(g,H,"System Metrics")}if(n.sections.diskAnalysis&&i.diskAnalysis){const I=[["Filesystem","Mount Point","Used %","Total GB","Timestamp"]];Object.entries(i.diskAnalysis).forEach(([M,A])=>{Array.isArray(A)&&A.forEach(N=>{I.push([N.filesystem||"",N.mount_point||"",N.used_percent||"",N.total_gb||"",N.timestamp||""])})});const H=y.utils.aoa_to_sheet(I);y.utils.book_append_sheet(g,H,"Disk Analysis")}if((a=n.sections.mongoAnalysis)!=null&&a.enabled&&i.mongoAnalysis){if(i.mongoAnalysis.collections){const I=[["Collection Name","Document Count","Size MB"]];i.mongoAnalysis.collections.forEach(M=>{I.push([M.name||"",M.count||"",M.size||""])});const H=y.utils.aoa_to_sheet(I);y.utils.book_append_sheet(g,H,"MongoDB Collections")}if(i.mongoAnalysis.indexes){const I=[["Index Name","Size MB","Usage Count"]];i.mongoAnalysis.indexes.forEach(M=>{I.push([M.name||"",M.size||"",M.accesses||""])});const H=y.utils.aoa_to_sheet(I);y.utils.book_append_sheet(g,H,"MongoDB Indexes")}}if(n.sections.alarmsAnalysis&&i.alarmsData){const I=[["Alarm Type","Count","Severity"]];Object.entries(i.alarmsData).forEach(([M,A])=>{I.push([M,A.count||"",A.severity||""])});const H=y.utils.aoa_to_sheet(I);y.utils.book_append_sheet(g,H,"Alarms Analysis")}y.writeFile(g,`comprehensive-report-${F().format("YYYY-MM-DD-HH-mm")}.xlsx`)}catch{B.error("Excel export failed. Please try CSV export instead.")}},xt=[{title:"Name",dataIndex:"name",key:"name",width:200},{title:"Description",dataIndex:"description",key:"description",width:300},{title:"Schedule",key:"schedule",width:200,render:(i,n)=>o.jsxs(Pe,{children:[o.jsx(ye,{children:n.schedule.frequency}),o.jsx("span",{children:n.schedule.time})]})},{title:"Delivery",key:"delivery",width:200,render:(i,n)=>o.jsxs(Pe,{children:[o.jsx(ye,{children:n.delivery.type}),o.jsx("span",{children:n.delivery.destination})]})},{title:"Status",key:"status",width:100,render:(i,n)=>o.jsx(ye,{color:n.status==="active"?"green":"orange",children:n.status})},{title:"Last Generated",dataIndex:"lastGenerated",key:"lastGenerated",width:200,render:i=>i?F(i).format("YYYY-MM-DD HH:mm:ss"):"-"},{title:"Actions",key:"actions",width:200,render:(i,n)=>o.jsxs(Pe,{children:[o.jsx(Re,{title:n.status==="active"?"Pause":"Activate",children:o.jsx(le,{type:"text",icon:n.status==="active"?o.jsx(zt,{}):o.jsx(Ct,{}),onClick:()=>je(n)})}),o.jsx(Re,{title:"Edit",children:o.jsx(le,{type:"text",icon:o.jsx(jt,{}),onClick:()=>Ee(n)})}),o.jsx(Re,{title:"Delete",children:o.jsx(le,{type:"text",danger:!0,icon:o.jsx(Mt,{}),onClick:()=>Q(n.id)})})]})}],ut=[{title:"Report Name",key:"reportName",width:200,render:(i,n)=>{const a=t.find(y=>y.id===n.reportId);return(a==null?void 0:a.name)||"Unknown"}},{title:"Generated At",dataIndex:"generatedAt",key:"generatedAt",width:200,render:i=>F(i).format("YYYY-MM-DD HH:mm:ss")},{title:"Status",dataIndex:"status",key:"status",width:100,render:i=>o.jsx(ye,{color:i==="success"?"green":"red",children:i})},{title:"Actions",key:"actions",width:100,render:(i,n)=>n.fileUrl&&o.jsx(Re,{title:"Download PDF",children:o.jsx(le,{type:"text",icon:o.jsx(Ye,{}),onClick:()=>Ce(n.fileUrl)})})}];return o.jsxs("div",{style:{padding:"24px"},children:[o.jsx(bt,{children:o.jsxs(nt,{defaultActiveKey:"reports",children:[o.jsxs(st,{tab:"Scheduled Reports",children:[o.jsxs("div",{style:{marginBottom:16,display:"flex",gap:"8px"},children:[o.jsx(le,{type:"primary",icon:o.jsx(vt,{}),onClick:Ie,children:"Create Report"}),o.jsx(le,{type:"default",icon:o.jsx(Ye,{}),onClick:Ue,children:"Test Report"}),o.jsx(le,{type:"primary",icon:o.jsx(Ye,{}),onClick:lt,style:{backgroundColor:"#52c41a",borderColor:"#52c41a"},children:"Comprehensive Report"}),oe&&me&&o.jsx($t,{menu:{items:[{key:"csv",icon:o.jsx(wt,{}),label:"Export as CSV",onClick:()=>gt(oe,me)},{key:"excel",icon:o.jsx(kt,{}),label:"Export as Excel",onClick:()=>mt(oe,me)}]},trigger:["click"],children:o.jsx(le,{icon:o.jsx(At,{}),children:"Export Data"})})]}),o.jsx(Ve,{columns:xt,dataSource:t||[],rowKey:"id",pagination:{pageSize:10}})]},"reports"),o.jsx(st,{tab:"Report History",children:o.jsx(Ve,{columns:ut,dataSource:r||[],rowKey:"id",pagination:{pageSize:10}})},"history")]})}),o.jsx(qe,{title:L?"Edit Report":"Create Report",open:w,onOk:Fe,onCancel:()=>h(!1),width:800,children:o.jsxs(z,{form:j,layout:"vertical",initialValues:{schedule:{frequency:"daily"},delivery:{type:"email"},content:{type:"alarms"},status:"active"},children:[o.jsx(z.Item,{name:"name",label:"Report Name",rules:[{required:!0}],children:o.jsx(Be,{})}),o.jsx(z.Item,{name:"description",label:"Description",rules:[{required:!0}],children:o.jsx(Be.TextArea,{})}),o.jsx(z.Item,{name:["schedule","frequency"],label:"Frequency",rules:[{required:!0}],children:o.jsxs(pe,{children:[o.jsx(W,{value:"daily",children:"Daily"}),o.jsx(W,{value:"weekly",children:"Weekly"}),o.jsx(W,{value:"monthly",children:"Monthly"})]})}),o.jsx(z.Item,{name:"time",label:"Time",rules:[{required:!0}],children:o.jsx(St,{format:"HH:mm"})}),o.jsx(z.Item,{name:["delivery","type"],label:"Delivery Method",rules:[{required:!0}],children:o.jsxs(pe,{children:[o.jsx(W,{value:"email",children:"Email"}),o.jsx(W,{value:"slack",children:"Slack"})]})}),o.jsx(z.Item,{name:["delivery","destination"],label:"Destination",rules:[{required:!0}],children:o.jsx(Be,{placeholder:"Email address or Slack channel"})}),o.jsx(z.Item,{name:["content","type"],label:"Report Content",rules:[{required:!0}],children:o.jsx(pe,{children:o.jsx(W,{value:"general_health",children:"General Health"})})})]})}),o.jsx(qe,{title:"Generate Comprehensive Report",open:$,onOk:pt,onCancel:()=>l(!1),width:900,confirmLoading:fe,children:o.jsxs(z,{form:_,layout:"vertical",initialValues:{timeRange:{type:"relative",relative:"1d"},sections:{systemMetrics:!0,diskAnalysis:!0,alarmsAnalysis:!0}},children:[o.jsxs(_e,{gutter:16,children:[o.jsx(ue,{span:12,children:o.jsx(z.Item,{name:"clusters",label:"Select Clusters",rules:[{required:!0,message:"Please select at least one cluster"}],children:o.jsx(pe,{mode:"multiple",placeholder:"Select clusters to include in report",optionFilterProp:"children",onChange:i=>{Ne(i);const n=i.flatMap(a=>{const y=q.find(g=>g.id===a);return y?y.nodeList.map(g=>({id:g.agentID,name:g.hostname,clusterId:a,clusterName:y.name,type:y.type,role:g.isPrimary?"PRIMARY":g.role||"SECONDARY",status:g.status})):[]});ze(n)},children:q.map(i=>o.jsxs(W,{value:i.id,children:[o.jsx(ye,{color:i.type==="MongoDB"?"green":i.type==="PostgreSQL"?"blue":"orange",children:i.type}),i.name," (",i.nodes," nodes)"]},i.id))})})}),o.jsx(ue,{span:12,children:o.jsx(z.Item,{name:"nodes",label:"Select Nodes",rules:[{required:!0,message:"Please select at least one node"}],children:o.jsx(pe,{mode:"multiple",placeholder:"Select nodes to include in report",optionFilterProp:"children",disabled:ce.length===0,children:Se.map(i=>o.jsx(W,{value:i.id,children:o.jsxs(Pe,{children:[o.jsx(ye,{color:i.type==="MongoDB"?"green":i.type==="PostgreSQL"?"blue":"orange",children:i.type}),o.jsx(ye,{color:i.role==="PRIMARY"||i.role==="Leader"?"blue":"default",children:i.role}),o.jsx("span",{children:i.name}),o.jsxs("span",{style:{color:"var(--text-secondary)"},children:["(",i.clusterName,")"]})]})},i.id))})})})]}),o.jsx(_e,{gutter:16,children:o.jsx(ue,{span:12,children:o.jsx(z.Item,{name:["timeRange","type"],label:"Time Range Type",children:o.jsxs(pe,{children:[o.jsx(W,{value:"relative",children:"Relative"}),o.jsx(W,{value:"absolute",children:"Absolute"})]})})})}),o.jsx(z.Item,{noStyle:!0,shouldUpdate:(i,n)=>{var a,y;return((a=i.timeRange)==null?void 0:a.type)!==((y=n.timeRange)==null?void 0:y.type)},children:({getFieldValue:i})=>i(["timeRange","type"])==="relative"?o.jsx(z.Item,{name:["timeRange","relative"],label:"Time Period",children:o.jsxs(pe,{children:[o.jsx(W,{value:"1h",children:"Last 1 Hour"}),o.jsx(W,{value:"1d",children:"Last 1 Day"}),o.jsx(W,{value:"7d",children:"Last 7 Days"}),o.jsx(W,{value:"30d",children:"Last 30 Days"})]})}):o.jsxs(_e,{gutter:16,children:[o.jsx(ue,{span:12,children:o.jsx(z.Item,{name:["timeRange","absolute","startDate"],label:"Start Date",children:o.jsx(We,{showTime:!0,style:{width:"100%"}})})}),o.jsx(ue,{span:12,children:o.jsx(z.Item,{name:["timeRange","absolute","endDate"],label:"End Date",children:o.jsx(We,{showTime:!0,style:{width:"100%"}})})})]})}),o.jsx(Je,{children:"Report Format"}),o.jsx(z.Item,{name:"reportVersion",label:"Report Version",initialValue:"v2",children:o.jsxs(Qe.Group,{children:[o.jsx(Qe.Button,{value:"v2",children:"V2 — Intelligence Report"}),o.jsx(Qe.Button,{value:"v1",children:"V1 — Classic Report"})]})}),o.jsx(Je,{children:"Report Sections"}),o.jsxs(_e,{gutter:16,children:[o.jsxs(ue,{span:12,children:[o.jsx(z.Item,{name:["sections","systemMetrics"],valuePropName:"checked",children:o.jsx(V,{children:"System Performance Metrics"})}),o.jsx(z.Item,{name:["sections","diskAnalysis"],valuePropName:"checked",children:o.jsx(V,{children:"Disk Analysis & Trends"})}),o.jsx(z.Item,{name:["sections","alarmsAnalysis"],valuePropName:"checked",children:o.jsx(V,{children:"Alarms Analysis"})}),o.jsx(z.Item,{name:["sections","recommendations"],valuePropName:"checked",children:o.jsx(V,{children:"Capacity Planning & Recommendations"})})]}),o.jsxs(ue,{span:12,children:[o.jsx(z.Item,{name:["sections","mongoAnalysis","enabled"],valuePropName:"checked",children:o.jsx(V,{children:"MongoDB Analysis"})}),o.jsx(z.Item,{name:["sections","postgresAnalysis","enabled"],valuePropName:"checked",children:o.jsx(V,{children:"PostgreSQL Analysis"})}),o.jsx(z.Item,{name:["sections","mssqlAnalysis","enabled"],valuePropName:"checked",children:o.jsx(V,{children:"MSSQL Analysis"})})]})]}),o.jsx(z.Item,{noStyle:!0,shouldUpdate:(i,n)=>{var a,y,g,k;return((y=(a=i.sections)==null?void 0:a.mongoAnalysis)==null?void 0:y.enabled)!==((k=(g=n.sections)==null?void 0:g.mongoAnalysis)==null?void 0:k.enabled)},children:({getFieldValue:i})=>i(["sections","mongoAnalysis","enabled"])?o.jsxs("div",{style:{marginLeft:24,marginBottom:16},children:[o.jsx("p",{style:{marginBottom:8,fontWeight:"bold"},children:"MongoDB Analysis Options:"}),o.jsx(z.Item,{name:["sections","mongoAnalysis","includeCollections"],valuePropName:"checked",children:o.jsx(V,{children:"Include Collections Analysis"})}),o.jsx(z.Item,{name:["sections","mongoAnalysis","includeIndexes"],valuePropName:"checked",children:o.jsx(V,{children:"Include Index Analysis"})}),o.jsx(z.Item,{name:["sections","mongoAnalysis","includePerformance"],valuePropName:"checked",children:o.jsx(V,{children:"Include Performance Metrics"})})]}):null}),o.jsx(z.Item,{noStyle:!0,shouldUpdate:(i,n)=>{var a,y,g,k;return((y=(a=i.sections)==null?void 0:a.postgresAnalysis)==null?void 0:y.enabled)!==((k=(g=n.sections)==null?void 0:g.postgresAnalysis)==null?void 0:k.enabled)},children:({getFieldValue:i})=>i(["sections","postgresAnalysis","enabled"])?o.jsxs("div",{style:{marginLeft:24,marginBottom:16},children:[o.jsx("p",{style:{marginBottom:8,fontWeight:"bold"},children:"PostgreSQL Analysis Options:"}),o.jsx(z.Item,{name:["sections","postgresAnalysis","includeBloat"],valuePropName:"checked",children:o.jsx(V,{children:"Include Bloat Analysis"})}),o.jsx(z.Item,{name:["sections","postgresAnalysis","includeSlowQueries"],valuePropName:"checked",children:o.jsx(V,{children:"Include Slow Queries"})}),o.jsx(z.Item,{name:["sections","postgresAnalysis","includeConnections"],valuePropName:"checked",children:o.jsx(V,{children:"Include Connection Statistics"})})]}):null}),o.jsx(z.Item,{noStyle:!0,shouldUpdate:(i,n)=>{var a,y,g,k;return((y=(a=i.sections)==null?void 0:a.mssqlAnalysis)==null?void 0:y.enabled)!==((k=(g=n.sections)==null?void 0:g.mssqlAnalysis)==null?void 0:k.enabled)},children:({getFieldValue:i})=>i(["sections","mssqlAnalysis","enabled"])?o.jsxs("div",{style:{marginLeft:24,marginBottom:16},children:[o.jsx("p",{style:{marginBottom:8,fontWeight:"bold"},children:"MSSQL Analysis Options:"}),o.jsx(z.Item,{name:["sections","mssqlAnalysis","includeCapacityPlanning"],valuePropName:"checked",children:o.jsx(V,{children:"Include Capacity Planning"})}),o.jsx(z.Item,{name:["sections","mssqlAnalysis","includePerformance"],valuePropName:"checked",children:o.jsx(V,{children:"Include Performance Analysis"})})]}):null})]})})]})};export{ci as default};
