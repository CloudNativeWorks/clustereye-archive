import{a_ as s,a as t,a0 as n}from"./index-4b154444.js";function r(){const{flags:e}=s(),{can:a}=t();return!!e.context_graph_enabled&&a(n.contextView)}export{r as u};
