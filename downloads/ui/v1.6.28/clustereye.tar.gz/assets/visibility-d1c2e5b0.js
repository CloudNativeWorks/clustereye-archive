const d=e=>(...n)=>{typeof document<"u"&&document.hidden||e(...n)};export{d as w};
