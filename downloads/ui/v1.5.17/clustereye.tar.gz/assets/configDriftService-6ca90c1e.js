import{g as S,aA as w}from"./index-3382ae22.js";import{f as a}from"./vendor-utils-04488df1.js";import"./vendor-core-007a4f56.js";const f=[{id:"pg-prod-cluster",name:"pg-prod-cluster",database_type:"PostgreSQL",location:"us-east-1",nodes:[{id:"pg-prod-01",name:"pg-prod-01",hostname:"pg-prod-01.example.com",role:"PRIMARY",status:"healthy",agent_id:"agent-pg-prod-01"},{id:"pg-prod-02",name:"pg-prod-02",hostname:"pg-prod-02.example.com",role:"SECONDARY",status:"healthy",agent_id:"agent-pg-prod-02"},{id:"pg-prod-03",name:"pg-prod-03",hostname:"pg-prod-03.example.com",role:"SECONDARY",status:"healthy",agent_id:"agent-pg-prod-03"}]},{id:"pg-staging-cluster",name:"pg-staging-cluster",database_type:"PostgreSQL",location:"us-west-2",nodes:[{id:"pg-staging-01",name:"pg-staging-01",hostname:"pg-staging-01.example.com",role:"PRIMARY",status:"healthy",agent_id:"agent-pg-staging-01"},{id:"pg-staging-02",name:"pg-staging-02",hostname:"pg-staging-02.example.com",role:"SECONDARY",status:"warning",agent_id:"agent-pg-staging-02"},{id:"pg-staging-03",name:"pg-staging-03",hostname:"pg-staging-03.example.com",role:"SECONDARY",status:"healthy",agent_id:"agent-pg-staging-03"}]},{id:"pg-analytics-cluster",name:"pg-analytics-cluster",database_type:"PostgreSQL",location:"eu-west-1",nodes:[{id:"pg-analytics-01",name:"pg-analytics-01",hostname:"pg-analytics-01.example.com",role:"PRIMARY",status:"healthy",agent_id:"agent-pg-analytics-01"},{id:"pg-analytics-02",name:"pg-analytics-02",hostname:"pg-analytics-02.example.com",role:"SECONDARY",status:"healthy",agent_id:"agent-pg-analytics-02"},{id:"pg-analytics-03",name:"pg-analytics-03",hostname:"pg-analytics-03.example.com",role:"SECONDARY",status:"healthy",agent_id:"agent-pg-analytics-03"}]},{id:"mongo-prod-rs",name:"mongo-prod-rs",database_type:"MongoDB",location:"us-east-1",nodes:[{id:"mongo-prod-01",name:"mongo-prod-01",hostname:"mongo-prod-01.example.com",role:"PRIMARY",status:"healthy",agent_id:"agent-mongo-prod-01"},{id:"mongo-prod-02",name:"mongo-prod-02",hostname:"mongo-prod-02.example.com",role:"SECONDARY",status:"healthy",agent_id:"agent-mongo-prod-02"},{id:"mongo-prod-03",name:"mongo-prod-03",hostname:"mongo-prod-03.example.com",role:"SECONDARY",status:"critical",agent_id:"agent-mongo-prod-03"}]},{id:"mongo-logs-rs",name:"mongo-logs-rs",database_type:"MongoDB",location:"us-west-2",nodes:[{id:"mongo-logs-01",name:"mongo-logs-01",hostname:"mongo-logs-01.example.com",role:"PRIMARY",status:"healthy",agent_id:"agent-mongo-logs-01"},{id:"mongo-logs-02",name:"mongo-logs-02",hostname:"mongo-logs-02.example.com",role:"SECONDARY",status:"healthy",agent_id:"agent-mongo-logs-02"},{id:"mongo-logs-03",name:"mongo-logs-03",hostname:"mongo-logs-03.example.com",role:"ARBITER",status:"healthy",agent_id:"agent-mongo-logs-03"}]},{id:"mssql-prod-ag",name:"mssql-prod-ag",database_type:"MSSQL",location:"us-east-1",nodes:[{id:"mssql-prod-01",name:"mssql-prod-01",hostname:"mssql-prod-01.example.com",role:"PRIMARY",status:"healthy",agent_id:"agent-mssql-prod-01"},{id:"mssql-prod-02",name:"mssql-prod-02",hostname:"mssql-prod-02.example.com",role:"SECONDARY",status:"healthy",agent_id:"agent-mssql-prod-02"},{id:"mssql-prod-03",name:"mssql-prod-03",hostname:"mssql-prod-03.example.com",role:"SECONDARY",status:"warning",agent_id:"agent-mssql-prod-03"}]},{id:"mssql-reporting-ag",name:"mssql-reporting-ag",database_type:"MSSQL",location:"eu-central-1",nodes:[{id:"mssql-reporting-01",name:"mssql-reporting-01",hostname:"mssql-reporting-01.example.com",role:"PRIMARY",status:"healthy",agent_id:"agent-mssql-reporting-01"},{id:"mssql-reporting-02",name:"mssql-reporting-02",hostname:"mssql-reporting-02.example.com",role:"SECONDARY",status:"healthy",agent_id:"agent-mssql-reporting-02"},{id:"mssql-reporting-03",name:"mssql-reporting-03",hostname:"mssql-reporting-03.example.com",role:"SECONDARY",status:"healthy",agent_id:"agent-mssql-reporting-03"}]}],b=`# PostgreSQL Configuration File
# -----------------------------

# Connection Settings
listen_addresses = 'localhost'
port = 5432
max_connections = 100

# Memory Settings
shared_buffers = 256MB
effective_cache_size = 768MB
work_mem = 4MB
maintenance_work_mem = 64MB

# WAL Settings
wal_level = replica
max_wal_senders = 3
synchronous_commit = on

# Logging
log_statement = 'none'
log_duration = off
log_min_duration_statement = -1

# SSL
ssl = off
`,v=`# PostgreSQL Configuration File
# -----------------------------

# Connection Settings
listen_addresses = '*'
port = 5432
max_connections = 200

# Memory Settings
shared_buffers = 512MB
effective_cache_size = 1536MB
work_mem = 8MB
maintenance_work_mem = 128MB

# WAL Settings
wal_level = replica
max_wal_senders = 5
synchronous_commit = remote_apply

# Logging
log_statement = 'all'
log_duration = on
log_min_duration_statement = 1000

# SSL
ssl = on
`,I=`# PostgreSQL Client Authentication Configuration File
# TYPE  DATABASE        USER            ADDRESS                 METHOD
local   all             all                                     peer
host    all             all             127.0.0.1/32            md5
host    all             all             ::1/128                 md5
`,A=`# PostgreSQL Client Authentication Configuration File
# TYPE  DATABASE        USER            ADDRESS                 METHOD
local   all             all                                     peer
host    all             all             127.0.0.1/32            md5
host    all             all             ::1/128                 md5
host    all             all             0.0.0.0/0               md5
host    replication     replicator      10.0.0.0/8              md5
`,k=`# MongoDB Configuration File
storage:
  dbPath: /var/lib/mongodb
  journal:
    enabled: true
  wiredTiger:
    engineConfig:
      cacheSizeGB: 1

systemLog:
  destination: file
  path: /var/log/mongodb/mongod.log
  logAppend: true

net:
  port: 27017
  bindIp: 127.0.0.1

security:
  authorization: disabled

replication:
  replSetName: rs0

operationProfiling:
  slowOpThresholdMs: 100
`,C=`# MongoDB Configuration File
storage:
  dbPath: /var/lib/mongodb
  journal:
    enabled: true
  wiredTiger:
    engineConfig:
      cacheSizeGB: 4

systemLog:
  destination: file
  path: /var/log/mongodb/mongod.log
  logAppend: true

net:
  port: 27017
  bindIp: 0.0.0.0
  maxIncomingConnections: 65536

security:
  authorization: enabled
  keyFile: /etc/mongodb/keyfile

replication:
  replSetName: rs0

operationProfiling:
  slowOpThresholdMs: 50
  mode: slowOp
`,M=`Configuration Option                    Minimum  Maximum  Config Value  Run Value
---------------------------------------- -------- -------- ------------- ----------
max server memory (MB)                   16       2147483647  2147483647  2147483647
min server memory (MB)                   0        2147483647  0           0
max degree of parallelism                0        32767       0           0
cost threshold for parallelism           0        32767       5           5
clr enabled                              0        1           0           0
xp_cmdshell                              0        1           0           0
remote access                            0        1           1           1
backup compression default               0        1           0           0
optimize for ad hoc workloads            0        1           0           0
`,O=`Configuration Option                    Minimum  Maximum  Config Value  Run Value
---------------------------------------- -------- -------- ------------- ----------
max server memory (MB)                   16       2147483647  8192        8192
min server memory (MB)                   0        2147483647  4096        4096
max degree of parallelism                0        32767       4           4
cost threshold for parallelism           0        32767       50          50
clr enabled                              0        1           1           1
xp_cmdshell                              0        1           0           0
remote access                            0        1           1           1
backup compression default               0        1           1           1
optimize for ad hoc workloads            0        1           1           1
`;let P=1,B=1,R=1;function l(){return P++}function c(){return B++}function g(){return R++}const _=new Date,n=new Date(_.getTime()-60*60*1e3),r=new Date(_.getTime()-2*60*60*1e3),p=new Date(_.getTime()-24*60*60*1e3),m=new Date(_.getTime()-2*24*60*60*1e3),h=new Date(_.getTime()-7*24*60*60*1e3);l(),h.toISOString(),h.toISOString(),l(),n.toISOString(),n.toISOString(),l(),h.toISOString(),h.toISOString(),l(),r.toISOString(),r.toISOString(),l(),m.toISOString(),m.toISOString(),l(),n.toISOString(),n.toISOString(),l(),p.toISOString(),p.toISOString(),l(),r.toISOString(),r.toISOString();c(),n.toISOString(),n.toISOString(),c(),r.toISOString(),r.toISOString(),c(),new Date(n.getTime()+30*60*1e3).toISOString(),n.toISOString(),n.toISOString(),c(),r.toISOString(),r.toISOString(),c(),p.toISOString(),p.toISOString(),p.toISOString(),c(),m.toISOString(),m.toISOString(),m.toISOString();g(),n.toISOString(),g(),n.toISOString(),g(),r.toISOString(),g(),new Date(n.getTime()+30*60*1e3).toISOString(),n.toISOString(),g(),r.toISOString();const o=S();class D{getAuthToken(){return localStorage.getItem("token")}getAuthHeaders(){return{CEFE:"Yes",Authorization:`Bearer ${this.getAuthToken()}`,"Content-Type":"application/json"}}async fetchHistory(e){const t=new URLSearchParams;e.agent_id&&t.append("agent_id",e.agent_id),e.database_type&&t.append("database_type",e.database_type),e.impact_level&&t.append("impact_level",e.impact_level),e.is_acknowledged!==void 0&&t.append("is_acknowledged",String(e.is_acknowledged)),e.cluster_name&&t.append("cluster_name",e.cluster_name),e.changed_by&&t.append("changed_by",e.changed_by),e.from&&t.append("from",e.from),e.to&&t.append("to",e.to),e.limit&&t.append("limit",String(e.limit)),e.offset&&t.append("offset",String(e.offset));const s=await a.get(`${o}/api/v1/config-drift/history?${t.toString()}`,{headers:this.getAuthHeaders()});return{changes:s.data.changes||[],total:s.data.total||0}}async fetchSnapshots(e){const t=new URLSearchParams;e.agent_id&&t.append("agent_id",e.agent_id),e.database_type&&t.append("database_type",e.database_type),e.is_baseline!==void 0&&t.append("is_baseline",String(e.is_baseline)),e.limit&&t.append("limit",String(e.limit)),e.offset&&t.append("offset",String(e.offset));const s=await a.get(`${o}/api/v1/config-drift/snapshots?${t.toString()}`,{headers:this.getAuthHeaders()});return{snapshots:s.data.snapshots||[],total:s.data.total||0}}async getSnapshotById(e){return(await a.get(`${o}/api/v1/config-drift/snapshots/${e}`,{headers:this.getAuthHeaders()})).data}async getDiff(e,t){return(await a.get(`${o}/api/v1/config-drift/diff?snapshot1=${e}&snapshot2=${t}`,{headers:this.getAuthHeaders()})).data}async fetchAlerts(e){const t=new URLSearchParams;e.change_id&&t.append("change_id",String(e.change_id)),e.severity&&t.append("severity",e.severity),e.is_resolved!==void 0&&t.append("is_resolved",String(e.is_resolved)),e.limit&&t.append("limit",String(e.limit)),e.offset&&t.append("offset",String(e.offset));const s=await a.get(`${o}/api/v1/config-drift/alerts?${t.toString()}`,{headers:this.getAuthHeaders()});return{alerts:s.data.alerts||[],total:s.data.total||0}}async acknowledgeChange(e){await a.post(`${o}/api/v1/config-drift/changes/${e}/acknowledge`,{},{headers:this.getAuthHeaders()})}async resolveAlert(e){await a.post(`${o}/api/v1/config-drift/alerts/${e}/resolve`,{},{headers:this.getAuthHeaders()})}async getBaseline(e,t){return(await a.get(`${o}/api/v1/config-drift/baseline?agent_id=${e}&database_type=${t}`,{headers:this.getAuthHeaders()})).data}async setBaseline(e){await a.post(`${o}/api/v1/config-drift/baseline`,{snapshot_id:e},{headers:this.getAuthHeaders()})}async compareWithBaseline(e,t){return(await a.get(`${o}/api/v1/config-drift/compare-baseline?agent_id=${e}&database_type=${t}`,{headers:this.getAuthHeaders()})).data}async triggerAIAnalysis(e){return(await a.post(`${o}/api/v1/config-drift/analyze`,{change_id:e},{headers:this.getAuthHeaders()})).data}async getStats(){return(await a.get(`${o}/api/v1/config-drift/stats`,{headers:this.getAuthHeaders()})).data}getClusters(){return f}async getClustersWithRedis(){const e=[...f];try{const{listRedisClusters:t}=await w(()=>import("./redisService-bfa827f0.js"),["assets/redisService-bfa827f0.js","assets/vendor-utils-04488df1.js","assets/vendor-core-007a4f56.js","assets/index-3382ae22.js","assets/index-b45fbfd7.css"]);(await t()||[]).forEach(d=>{var u;const y=(u=d.discovered_nodes)!=null&&u.length?d.discovered_nodes:(d.seed_nodes||[]).map(i=>({...i,role:"",status:"unknown"}));e.push({id:d.clustername,name:d.clustername,database_type:"Redis",location:d.location||"",nodes:y.map(i=>({id:`${i.host}:${i.port}`,name:`${i.host}:${i.port}`,hostname:i.host,role:(i.role||"unknown").toUpperCase(),status:i.status==="up"?"healthy":i.status==="down"?"critical":"unknown",agent_id:`redis_${i.host}:${i.port}`}))})})}catch{}return e}async getChangeById(e){return(await a.get(`${o}/api/v1/config-drift/changes/${e}`,{headers:this.getAuthHeaders()})).data}}const T=new D;export{T as configDriftService};
