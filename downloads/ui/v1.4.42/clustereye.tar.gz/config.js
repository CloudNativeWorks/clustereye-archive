// Runtime configuration for Clustereye
// This file can be overridden during Helm deployment
window.CLUSTEREYE_CONFIG = {
  API_URL: 'http://localhost:8080',
  APP_NAME: 'Clustereye',
  VERSION: '1.0.0',
  // Add other runtime configs here as needed
  FEATURES: {
    AI_ANALYSIS: true,
    ANOMALY_DETECTION: true,
    REAL_TIME_MONITORING: true
  },
  // Timeout configurations
  TIMEOUT: {
    API_REQUEST: 30000,
    WEBSOCKET: 5000
  }
};