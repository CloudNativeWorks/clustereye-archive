const a={healthy:"#52c41a",warning:"#faad14",critical:"#ff4d4f"},f={info:"#1890ff",warning:"#faad14",high:"#fa8c16",critical:"#ff4d4f"};export{f as S,a};
