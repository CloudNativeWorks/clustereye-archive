const s=new Set(["redis","elasticsearch","azuresql","azurepg"]),a=e=>s.has(e);export{a as i};
