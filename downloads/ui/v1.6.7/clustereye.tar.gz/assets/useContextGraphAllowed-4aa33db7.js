import{aZ as a,a as t,Y as n}from"./index-2cd31096.js";function r(){const{flags:e}=a(),{can:s}=t();return!!e.context_graph_enabled&&s(n.contextView)}export{r as u};
