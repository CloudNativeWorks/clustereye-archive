import{a$ as a,a as t,X as n}from"./index-1540519e.js";function r(){const{flags:e}=a(),{can:s}=t();return!!e.context_graph_enabled&&s(n.contextView)}export{r as u};
