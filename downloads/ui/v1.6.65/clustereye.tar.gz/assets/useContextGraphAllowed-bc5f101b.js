import{b8 as t,u as a,a1 as n}from"./index-fc695fd1.js";function r(){const{flags:e}=t(),{can:s}=a();return!!e.context_graph_enabled&&s(n.contextView)}export{r as u};
